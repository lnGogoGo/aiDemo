/**
 * 基础请求工具函数
 */
import { v4 as uuidv4 } from "uuid";

export const TOKEN_KEY = "auth_token";
export const TOKEN_EXPIRY_DAYS = 7;

// 请求配置类型
// 请求配置类型
export interface RequestOptions extends RequestInit {
  isFormData?: boolean; // 是否是FormData
  params?: Record<string, any>; // URL 查询参数
  responseType?: "json" | "blob"; // 响应类型
  timeout?: number; // 超时时间（毫秒）
}

// 响应结果类型
export interface ResponseResult<T = any> {
  code: string;
  data: T;
  message: string;
  success: boolean;
}

export type ResponseListResult<T = any> = ResponseResult<{
  records: T[];
  total: number;
  size: number;
  current: number;
  pages: number;
}>;

export const uuid = uuidv4();

// API 基础路径，从环境变量获取或使用默认值
export const API_BASE_URL = "/api"; // process.env.NEXT_PUBLIC_API_BASE_URL || "/api";

// 默认请求头
const DEFAULT_HEADERS = {
  "Content-Type": "application/json",
};

// 默认超时时间：15秒
const DEFAULT_TIMEOUT = 15000;

/**
 * 构建完整URL（添加查询参数）
 */
function buildUrl(url: string, params?: Record<string, any>): string {
  let fullUrl = url.startsWith("http") ? url : `${API_BASE_URL}${url}`;

  if (params) {
    const queryString = Object.entries(params)
      .filter(([, value]) => value !== undefined && value !== null)
      .map(
        ([key, value]) =>
          `${encodeURIComponent(key)}=${encodeURIComponent(value)}`
      )
      .join("&");

    if (queryString) {
      fullUrl += (fullUrl.includes("?") ? "&" : "?") + queryString;
    }
  }

  return fullUrl;
}

/**
 * 带有超时控制的fetch请求
 */
async function timeoutFetch(
  url: string,
  options: RequestOptions,
  timeout: number
): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  if (options.isFormData && options.headers) {
    delete (options.headers as any)["Content-Type"];
  }

  if (options.method === "DELETE") {
    delete (options.headers as any)["Content-Type"];
    delete options.body;
  }

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`请求超时: ${url}`);
    }
    throw error;
  }
}

/**
 * 处理响应数据
 */
async function handleResponse<T>(
  response: Response
): Promise<ResponseResult<T>> {
  // 检查HTTP状态码
  if (!response.ok) {
    const errorText = await response.text().catch(() => "未知错误");
    throw new Error(`HTTP错误 ${response.status}: ${errorText}`);
  }

  // 尝试解析为JSON
  try {
    const result = await response.json();

    if (result.code !== "00000") {
      throw new Error(`${result.data}`);
    }

    return result as ResponseResult<T>;
  } catch (error: any) {
    console.error(error);
    throw new Error(error);
  }
}

/**
 * 基础请求方法
 */
async function request<T = any, R = ResponseResult<T>>(
  url: string,
  options: RequestOptions = {}
): Promise<R> {
  const { params, timeout = DEFAULT_TIMEOUT, ...fetchOptions } = options;

  const token = localStorage.getItem(TOKEN_KEY);

  // 构建请求URL和最终选项
  const fullUrl = buildUrl(url, params);
  const finalOptions: any = {
    ...fetchOptions,
    headers: {
      ...DEFAULT_HEADERS,
      ...fetchOptions.headers,
    },
  };

  if (token) {
    finalOptions.headers["Authorization"] = `Bearer ${token}`;
  }

  try {
    const response = await timeoutFetch(fullUrl, finalOptions, timeout);

    if (options.responseType === "blob") {
      const isAttachment = response.headers.get("content-disposition")?.includes(
        "attachment"
      );

      if (!isAttachment) {
        throw new Error((await response.json()).data);
      }

      return response.blob() as unknown as R;
    }

    return (await handleResponse<T>(response)) as R;
  } catch (error) {
    console.error("请求出错:", error);
    throw error;
  }
}

/**
 * GET请求
 */
export function get<T = any>(
  url: string,
  options?: RequestOptions
): Promise<ResponseResult<T>> {
  return request<T>(url, {
    ...options,
    method: "GET",
  });
}

/**
 * POST请求
 */
export function post<T = any, R = ResponseResult<T>>(
  url: string,
  data?: any,
  options?: RequestOptions
) {
  return request<T, R>(url, {
    ...options,
    method: "POST",
    body: data ? JSON.stringify(data) : "{}",
  });
}

/**
 * PUT请求
 */
export function put<T = any>(
  url: string,
  data?: any,
  options?: RequestOptions
): Promise<ResponseResult<T>> {
  return request<T>(url, {
    ...options,
    method: "PUT",
    body: data ? JSON.stringify(data) : undefined,
  });
}

/**
 * DELETE请求
 */
export function del<T = any>(
  url: string,
  options?: RequestOptions
): Promise<ResponseResult<T>> {
  return request<T>(url, {
    ...options,
    method: "DELETE",
    headers: {
      ...options?.headers,
    },
  });
}

export function upload<T = any>(
  url: string,
  data?: FormData,
  options?: RequestOptions
): Promise<ResponseResult<T>> {
  return request<T>(url, {
    ...options,
    method: "POST",
    body: data,
    isFormData: true,
    headers: {
      ...options?.headers,
    },
  });
}

/**
 * PATCH请求
 */
export function patch<T = any>(
  url: string,
  data?: any,
  options?: RequestOptions
): Promise<ResponseResult<T>> {
  return request<T>(url, {
    ...options,
    method: "PATCH",
    body: data ? JSON.stringify(data) : undefined,
  });
}

export * from './operationLog';
