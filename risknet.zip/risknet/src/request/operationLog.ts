/**
 * 操作日志相关API
 */
import { get, post } from "./index";
import {
  SnOperationLogPageQuery,
  PageSnOperationLogVO,
  RMapStringString,
} from "@/types/operationLog";

/**
 * 分页查询操作日志
 */
export function requestOperationLogPage(params: SnOperationLogPageQuery) {
  return post<PageSnOperationLogVO>("/semanticNetwork/log/page", params);
}

/**
 * 获取操作类型列表
 */
export function requestOperationTypeList() {
  return get<RMapStringString>("/semanticNetwork/log/operationTypeList");
}
