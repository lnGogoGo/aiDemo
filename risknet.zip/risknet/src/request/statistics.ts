/**
 * 数据统计相关API
 */
import { get } from './index';

// 实体数量统计
export interface EntityCountStats {
  entityType: string;
  inspectedCount: number;
  totalCount: number;
  percentage: number;
}

// 错误类型统计
export interface ErrorTypeStats {
  errorType: string;
  count: number;
  percentage: number;
}

// 审核进度统计
export interface ReviewProgressStats {
  completed: number;
  total: number;
  percentage: number;
}

// 统计数据
export interface StatisticsData {
  entityStats: EntityCountStats[];
  errorStats: ErrorTypeStats[];
  reviewProgress: ReviewProgressStats;
}

/**
 * 获取统计数据
 */
export async function getStatistics() {
  return get<StatisticsData>('/statistics');
} 