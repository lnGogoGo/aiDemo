import { get, post, upload, del } from "./index";
import { RuleType, Operator, LlmModel, ConditionLogic, ConditionField } from '../types/metadata';

export const metadataApi = {
  clearCache() { 
    return post<string>('/riskAssessment/metadata/clearCache'); 
  },
  getRuleTypes() { 
    return get<RuleType[]>('/riskAssessment/metadata/ruleTypes'); 
  },
  getOperators(fieldType: string) { 
    return get<Operator[]>(`/riskAssessment/metadata/operators?fieldType=${fieldType}`); 
  },
  getLlmModels() { 
    return get<LlmModel[]>('/riskAssessment/metadata/llmModels'); 
  },
  getFieldOperators(field: string) { 
    return get<Operator[]>(`/riskAssessment/metadata/fieldOperators/${field}`); 
  },
  getDefaultLlmModel() { 
    return get<LlmModel>('/riskAssessment/metadata/defaultLlmModel'); 
  },
  getConditionLogics() { 
    return get<ConditionLogic[]>('/riskAssessment/metadata/conditionLogics'); 
  },
  getConditionFields() { 
    return get<ConditionField[]>('/riskAssessment/metadata/conditionFields'); 
  },
}; 