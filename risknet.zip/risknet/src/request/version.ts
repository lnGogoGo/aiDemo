import { post } from './index';
import type { RListSnVersionVO } from '@/types/version';

/**
 * 获取系统内版本号列表
 * @returns
 */
export function listVersions() {
  return post<RListSnVersionVO>('/semanticNetwork/version/list');
} 