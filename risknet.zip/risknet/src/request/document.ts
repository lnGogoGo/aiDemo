/**
 * 文档解析相关API
 */
import { get, post, upload, del } from "./index";
import { ResponseResult, ResponseListResult } from "./index";
import {
  Document,
  DocumentParseTask,
  DocumentParseConfig,
  DocumentParsePageResult,
  ParseExpandTask,
  SnExpandTaskBatchVO,
  ExpandTaskConfigVO,
  ImportTaskConfigVO,
  SnImportTaskVO,
} from "../types/document";

export const requestDocumentConfig = async () => {
  const res = await get<DocumentParseConfig>(
    "/semanticNetwork/parserTask/config"
  );

  return res.data;
};

/**
 * 更新解析任务页面结果
 * @param params 更新参数
 * @returns 是否成功
 */
export const requestUpdateTaskPageResult = (params: {
  id: string;
  results: { [key: string]: Record<string, string>[] };
}) => {
  return post<boolean>("/semanticNetwork/parserTask/updateResult", params);
};

/**
 * 提交解析任务
 * @param params 提交参数
 * @returns 解析任务id
 */
export const requestSubmitParseTask = (params: {
  categoryType: string;
  docId: string;
  endPage: number;
  modelName?: string;
  sourceName: string;
  sourceType: string;
  startPage: number;
}) => {
  return post<string>("/semanticNetwork/parserTask/submit", params);
};

/**
 * 恢复解析任务
 * @param taskId 任务ID
 * @returns 是否成功
 */
export const requestResumeTask = (params: {
  id: string;
  modelName?: string;
  startPage?: number;
}) => {
  return post<boolean>(`/semanticNetwork/parserTask/resume`, params);
};

/**
 * 分页查询解析任务
 * @param params 查询参数
 * @returns 解析任务列表
 */
export const requestPageTask = (params: {
  docId?: string;
  categoryType?: string;
  status?: string;
  current?: number;
  size?: number;
}) => {
  return post<DocumentParseTask, ResponseListResult>(
    "/semanticNetWork/parserTask/page",
    params
  );
};

/**
 * 分页查询解析任务每页面结果
 * @param params 查询参数
 * @returns 解析任务每页面结果列表
 */
export const requestPageTaskResult = (params: {
  id?: string;
  pageNum?: number;
  current?: number;
  size?: number;
}) => {
  return post<DocumentParsePageResult, ResponseListResult>(
    "/semanticNetwork/parserTask/pageResult",
    params
  );
};

/**
 * 获取特定页面的解析任务结果
 * @param taskId 任务ID
 * @param pageNum 页码
 * @returns 特定页面的解析任务结果
 */
export const requestGetTaskPageResult = (taskId: string, pageNum: number) => {
  return get<DocumentParsePageResult>(
    `/semanticNetWork/parserTask/taskPageResult/${taskId}/${pageNum}`
  );
};

/**
 * 获取解析任务状态
 * @param taskId 任务ID
 * @returns 解析任务状态
 */
export const requestGetTaskStatus = (taskId: string) => {
  return get<DocumentParseTask>(`/semanticNetWork/parserTask/status/${taskId}`);
};

/**
 * 文档上传
 * @param file 要上传的文件
 * @returns 上传后的文档id
 */
export const requestUploadDocument = (file: File) => {
  const formData = new FormData();
  formData.append("file", file, file.name);
  return upload<string>("/semanticNetWork/doc/upload", formData);
};

/**
 * 文档分页查询
 * @param params 查询参数
 * @returns 文档列表
 */
export const requestDocumentPage = (params: {
  filename?: string;
  parserTaskId?: string;
  haseParsed?: boolean;
  current?: number;
  size?: number;
}) => {
  return post<Document, ResponseListResult<Document>>(
    "/semanticNetWork/doc/page",
    params
  );
};

/**
 * 文档详情查询
 * @param id 文档ID
 * @returns 文档详情
 */
export const requestDocumentDetail = (id: string) => {
  return get<ResponseResult<Document>>(`/semanticNetWork/doc/${id}`);
};

/**
 * 删除文档
 * @param id 文档ID
 * @returns 是否成功
 */
export const requestDeleteDocument = (id: string) => {
  return del<string>(`/semanticNetWork/doc/${id}`);
};

/**
 * 下载文档
 * @param id 文档ID
 * @returns 文档流
 */
export const requestDownloadDocument = (id: string) => {
  return get(`/semanticNetWork/doc/download/${id}`, {
    responseType: "blob",
  });
};

/**
 * 获取扩展任务配置
 * @returns 扩展任务配置
 */
export const requestExpandTaskConfig = async () => {
  return await get<ExpandTaskConfigVO>("/semanticNetwork/expandTask/config");
};

/**
 * 提交扩展任务
 * @param params 提交参数
 * @returns 扩展任务id
 */
export const requestSubmitExpandTask = (params: {
  parserId: string;
  nodeType: string;
  modelName?: string;
  batchSize?: number;
}) => {
  return post<string>("/semanticNetwork/expandTask/submit", params);
};

/**
 * 恢复扩展任务
 * @param id 任务ID
 * @returns 是否成功
 */
export const requestResumeExpandTask = (params: {
  id: string;
  modelName?: string;
}) => {
  return post<boolean>(`/semanticNetwork/expandTask/resume`, params);
};

/**
 * 分页查询扩展任务
 * @param params 查询参数
 * @returns 扩展任务列表
 */
export const requestPageExpandTask = (params: {
  parserId?: string;
  nodeType?: string;
  status?: string;
  current?: number;
  size?: number;
}) => {
  return post<ParseExpandTask, ResponseListResult>(
    "/semanticNetwork/expandTask/page",
    params
  );
};

/**
 * 分页查询扩展任务批次结果
 * @param params 查询参数
 * @returns 扩展任务批次结果列表
 */
export const requestPageExpandTaskBatch = (params: {
  id: string;
  batchNum?: number;
  status?: string;
  current?: number;
  size?: number;
}) => {
  return post<SnExpandTaskBatchVO, ResponseListResult>(
    "/semanticNetwork/expandTask/pageBatch",
    params
  );
};

/**
 * 获取扩展任务状态
 * @param id 任务ID
 * @returns 扩展任务状态
 */
export const requestGetExpandTaskStatus = (id: string) => {
  return get<ParseExpandTask>(`/semanticNetwork/expandTask/status/${id}`);
};

/**
 * 更新扩展任务批次结果
 * @param params 更新参数
 * @returns 是否成功
 */
export const requestUpdateExpandTaskResult = (params: {
  id: string;
  results: Record<
    string,
    Array<{
      code: string;
      name: string;
      aliases?: Array<{ name: string; reason: string }>;
      metaphors?: Array<{ name: string; reason: string }>;
      slang?: Array<{ name: string; reason: string }>;
      locations?: Array<{ name: string; reason: string }>;
      description?: string;
    }>
  >;
}) => {
  return post<boolean>("/semanticNetwork/expandTask/updateResult", params);
};

/**
 * 获取导入任务配置
 * @returns 导入任务配置
 */
export const requestImportTaskConfig = async () => {
  return await get<ImportTaskConfigVO>("/semanticNetwork/importTask/config");
};

/**
 * 提交导入任务
 * @param params 提交参数
 * @returns 导入任务id
 */
export const requestSubmitImportTask = (params: {
  type: number;
  sourceId: string;
  nodeType: string;
  sourceType: string;
  sourceName: string;
}) => {
  return post<string>("/semanticNetwork/importTask/submit", params);
};

/**
 * 分页查询导入任务
 * @param params 查询参数
 * @returns 导入任务列表
 */
export const requestPageImportTask = (params: {
  parserId?: string;
  nodeType?: string;
  status?: string;
  current?: number;
  size?: number;
}) => {
  return post<SnImportTaskVO, ResponseListResult>(
    "/semanticNetwork/importTask/page",
    params
  );
};

/**
 * 获取导入任务状态
 * @param id 任务ID
 * @returns 导入任务状态
 */
export const requestGetImportTaskStatus = (id: string) => {
  return get<SnImportTaskVO>(`/semanticNetwork/importTask/status/${id}`);
};
