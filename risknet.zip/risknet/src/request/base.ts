import { get } from "./";

export const requestBaseConfig = async () => {
  const res = await get("/semanticNetwork/parserTask/page");
  return res.data;
};
