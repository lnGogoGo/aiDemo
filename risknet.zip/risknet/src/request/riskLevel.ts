import { get, post, upload, del } from "./index";
import { PaginatedResponse, RaRiskLevelQuery, RaRiskLevelPageQuery, RaRiskLevelVO } from '../types/riskLevel';

export const riskLevelApi = {
  create(data: RaRiskLevelQuery) { 
    return post<string>('/riskAssessment/riskLevel/create', data); 
  },
  update(data: RaRiskLevelQuery) { 
    return post<string>('/riskAssessment/riskLevel/update', data); 
  },
  page(data: RaRiskLevelPageQuery) { 
    return post<PaginatedResponse<RaRiskLevelVO>>('/riskAssessment/riskLevel/page', data); 
  },
  enable(id: string) { 
    return post<string>(`/riskAssessment/riskLevel/enable/${id}`); 
  },
  disable(id: string) { 
    return post<string>(`/riskAssessment/riskLevel/disable/${id}`); 
  },
  delete(id: string) { 
    return post<string>(`/riskAssessment/riskLevel/delete/${id}`); 
  },
  listAllActive() { 
    return get<RaRiskLevelVO[]>('/riskAssessment/riskLevel/listAllActive'); 
  },
  info(id: string) { 
    return get<RaRiskLevelVO>(`/riskAssessment/riskLevel/info/${id}`); 
  },
}; 