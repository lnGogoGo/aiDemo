import { get, post, upload, del } from "./index";
import { PaginatedResponse, RaRuleQuery, RaRulePageQuery, RaRuleVO } from '../types/rule';

export const ruleApi = {
    create(data: RaRuleQuery) {
        return post<string>('/riskAssessment/rule/create', data);
    },
    update(data: RaRuleQuery) {
        return post<string>('/riskAssessment/rule/update', data);
    },
    page(data: RaRulePageQuery) {
        return post<PaginatedResponse<RaRuleVO>>('/riskAssessment/rule/page', data);
    },
    enable(id: string) {
        return post<string>(`/riskAssessment/rule/enable/${id}`);
    },
    disable(id: string) {
        return post<string>(`/riskAssessment/rule/disable/${id}`);
    },
    delete(id: string) {
        return post<string>(`/riskAssessment/rule/delete/${id}`);
    },
    listAllActive() {
        return get<RaRuleVO[]>('/riskAssessment/rule/listAllActive');
    },
    info(id: string) {
        return get<RaRuleVO>(`/riskAssessment/rule/info/${id}`);
    },
}; 