import { get, post, upload } from "./index";
import type {
  SnInspectionTaskSubmitQuery,
  SnInspectionTaskPageQuery,
  PageSnInspectionTaskVO,
  SnInspectionNodePageQuery,
  PageSnInspectionNodeVO,
  SnInspectionNodeAuditQuery,
  SnInspectionTaskVO,
  SnInspectionTaskStatsVO,
} from "@/types/inspect";

/**
 * 提交抽检任务
 * @param data
 * @returns 抽检任务id
 */
export function requestSubmitInspectionTask(data: SnInspectionTaskSubmitQuery) {
  return post<string>("/semanticNetwork/inspectionTask/submit", data);
}

/**
 * 分页查询抽检任务
 * @param data
 * @returns 抽检任务列表
 */
export function requestInspectionTasks(data: SnInspectionTaskPageQuery) {
  return post<PageSnInspectionTaskVO>(
    "/semanticNetwork/inspectionTask/page",
    data
  );
}

/**
 * 分页查询抽检节点
 * @param data
 * @returns 抽检节点列表
 */
export function requestInspectionNodes(data: SnInspectionNodePageQuery) {
  return post<PageSnInspectionNodeVO>(
    "/semanticNetwork/inspectionTask/pageNodes",
    data
  );
}

/**
 * 导入修改后的节点关系数据
 * @param id
 * @param file
 * @returns
 */
export function requestImportNodeRelations(id: string, file: File) {
  const formData = new FormData();
  formData.append("file", file);
  return upload<string>(
    `/semanticNetwork/inspectionTask/importNodeRelations/${id}`,
    formData
  );
}

/**
 * 提交抽检节点审核意见
 * @param data
 * @returns
 */
export function requestAuditInspectionNode(data: SnInspectionNodeAuditQuery) {
  return post<string>("/semanticNetwork/inspectionTask/auditNode", data);
}

/**
 * 应用抽检节点反馈
 * @param id
 * @returns
 */
export function requestApplyNodeFixRelations(id: string) {
  return post<string>(
    `/semanticNetwork/inspectionTask/applyNodeFixRelations/${id}`
  );
}

/**
 * 获取抽检任务状态
 * @param id
 * @returns 抽检任务状态
 */
export function requestGetInspectionTaskStatus(id: string) {
  return get<SnInspectionTaskVO>(
    `/semanticNetwork/inspectionTask/status/${id}`
  );
}

/**
 * 获取抽检任务统计数据
 * @param id
 * @returns
 */
export function requestGetInspectionTaskStats(id: string) {
  return get<SnInspectionTaskStatsVO>(
    `/semanticNetwork/inspectionTask/stats/${id}`
  );
}

/**
 * 导出抽检节点关系数据
 * @param id
 * @returns Excel file
 */
export function requestExportNodeRelations(id: string, type: string) {
  let typeString = `exportAll=${type === "exportAll"}`;

  if (type === "exportCorrect") {
    typeString += `&exportCorrect=true&exportIncorrect=false&exportNeedAdjustment=false`;
  }

  if (type === "exportIncorrect") {
    typeString += `&exportCorrect=false&exportIncorrect=true&exportNeedAdjustment=false`;
  }

  if (type === "exportNeedAdjustment") {
    typeString += `&exportCorrect=false&exportIncorrect=false&exportNeedAdjustment=true`;
  }

  return get<Blob>(
    `/semanticNetwork/inspectionTask/exportNodeRelations/${id}?${typeString}`,
    { responseType: "blob" }
  );
}

export function requestGetNodeFixStatus(id: string) {
  return get<string>(
    `/semanticNetwork/inspectionTask/applyNodeFixRelationsStatus/${id}`
  );
}
