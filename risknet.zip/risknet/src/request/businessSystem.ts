import { get, post} from "./index";

import {  PaginatedResponse, RaBusinessSystemQuery, RaBusinessSystemPageQuery, RaBusinessSystemVO } from '../types/businessSystem';

export const businessSystemApi = {
  create(data: RaBusinessSystemQuery) {
    return post<string>('/riskAssessment/businessSystem/create', data);
  },
  update(data: RaBusinessSystemQuery) {
    return post<string>('/riskAssessment/businessSystem/update', data);
  },
  page(data: RaBusinessSystemPageQuery) {
    return post<PaginatedResponse<RaBusinessSystemVO>>('/riskAssessment/businessSystem/page', data);
  },
  enable(id: string) {
    return post<string>(`/riskAssessment/businessSystem/enable/${id}`);
  },
  disable(id: string) {
    return post<string>(`/riskAssessment/businessSystem/disable/${id}`);
  },
  delete(id: string) {
    return post<string>(`/riskAssessment/businessSystem/delete/${id}`);
  },
  listAllActive() {
    return get<RaBusinessSystemVO[]>('/riskAssessment/businessSystem/listAllActive');
  },
  info(id: string) {
    return get<RaBusinessSystemVO>(`/riskAssessment/businessSystem/info/${id}`);
  },
}; 