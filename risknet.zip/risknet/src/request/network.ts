/**
 * 语义网络相关API
 */
import { get, post } from "./index";

// 初始化任务状态
export enum InitTaskStatus {
  PENDING = "pending",
  PROCESSING = "processing",
  COMPLETED = "completed",
  FAILED = "failed",
}

// 创建初始化任务参数
export interface CreateInitTaskParams {
  createNewVersion: boolean;
  savePreviousVersion: boolean;
  dataSource: {
    type: "parseTask" | "skeleton";
    id?: string; // 解析任务ID
    data?: any; // 骨架实体JSON
  };
}

// 初始化任务类型
export interface InitTask {
  id: string;
  entityType: string;
  status: InitTaskStatus;
  documentImportProgress: number; // 0-100
  knowledgeExpansionProgress: number; // 0-100
  createdAt: string;
}

// 网络节点导入参数
export interface ImportNodeDataParams {
  nodeId: string;
  importType: "json" | "excel";
  data: File | object; // 文件或JSON对象
}

// 节点更新记录
export interface NodeUpdateRecord {
  id: string;
  nodeId: string;
  updateTime: string;
  operator: string;
  beforeData: any;
  afterData: any;
}

/**
 * 创建初始化任务
 */
export async function createInitTask(params: CreateInitTaskParams) {
  return post<{ taskId: string }>("/network/init/create", params);
}

/**
 * 获取初始化任务列表
 */
export async function getInitTaskList(page: number = 1, pageSize: number = 10) {
  return get<{
    list: InitTask[];
    total: number;
    page: number;
    pageSize: number;
  }>("/network/init/list", { params: { page, pageSize } });
}

/**
 * 获取初始化任务详情
 */
export async function getInitTaskDetail(taskId: string) {
  return get<InitTask>(`/network/init/detail/${taskId}`);
}

/**
 * 导入网络节点数据
 * 注意：当importType为excel时，使用FormData提交文件
 */
export async function importNodeData(params: ImportNodeDataParams) {
  if (params.importType === "excel" && params.data instanceof File) {
    const formData = new FormData();
    formData.append("file", params.data);
    formData.append("nodeId", params.nodeId);
    formData.append("importType", params.importType);

    return post<{ success: boolean }>("/network/nodes/import", formData, {
      // headers: {
      //   "Content-Type": undefined,
      // },
    });
  } else {
    return post<{ success: boolean }>("/network/nodes/import", {
      nodeId: params.nodeId,
      importType: params.importType,
      data: params.data,
    });
  }
}

/**
 * 导出网络节点数据
 */
export async function exportNodeData(
  nodeId: string,
  exportType: "json" | "excel"
) {
  // 对于文件下载类请求，需要定制化处理响应
  const url = `/network/nodes/export`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ nodeId, exportType }),
  });

  if (!response.ok) {
    throw new Error(`导出失败: ${response.statusText}`);
  }

  return await response.blob();
}

/**
 * 获取节点更新记录
 */
export async function getNodeUpdateRecords(nodeId: string) {
  return get<NodeUpdateRecord[]>(`/network/nodes/update-records/${nodeId}`);
}
