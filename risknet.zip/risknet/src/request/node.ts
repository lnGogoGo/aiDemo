/**
 * 节点相关API请求模块
 */
import { get, post, put, del } from './index';
import { Node, NodeStatus, NodeMark } from '@/types';

/**
 * 提交节点反馈请求参数类型
 */
export interface NodeFeedbackParams {
  nodeId: string;
  status: NodeStatus;
  mark: NodeMark;
  feedback: string;
}

/**
 * 节点列表查询参数
 */
export interface NodeListParams {
  page?: number;
  pageSize?: number;
  status?: NodeStatus;
  mark?: NodeMark;
  entityType?: string;
  keyword?: string;
}

/**
 * 获取节点列表
 */
export async function getNodeList(params: NodeListParams = {}) {
  return get<{
    list: Node[];
    total: number;
    page: number;
    pageSize: number;
  }>('/nodes', { params });
}

/**
 * 获取节点详情
 */
export async function getNodeDetail(nodeId: string) {
  return get<Node>(`/nodes/${nodeId}`);
}

/**
 * 提交节点反馈
 * @param nodeId 节点ID
 * @param status 节点状态
 * @param mark 节点标记
 * @param feedback 反馈内容
 */
export async function submitNodeFeedback(
  nodeId: string,
  status: NodeStatus,
  mark: NodeMark,
  feedback: string
) {
  return post<{ success: boolean }>('/nodes/feedback', {
    nodeId,
    status,
    mark,
    feedback,
  });
}

/**
 * 创建新节点
 */
export async function createNode(node: Omit<Node, 'id' | 'createdAt'>) {
  return post<Node>('/nodes', node);
}

/**
 * 更新节点
 */
export async function updateNode(nodeId: string, data: Partial<Node>) {
  return put<Node>(`/nodes/${nodeId}`, data);
}

/**
 * 删除节点
 */
export async function deleteNode(nodeId: string) {
  return del<{ success: boolean }>(`/nodes/${nodeId}`);
}

/**
 * 批量更新节点状态
 */
export async function batchUpdateNodeStatus(
  nodeIds: string[],
  status: NodeStatus,
  feedback?: string
) {
  return post<{ success: boolean; updated: number }>('/nodes/batch-status', {
    nodeIds,
    status,
    feedback,
  });
}

/**
 * 批量更新节点标记
 */
export async function batchUpdateNodeMark(
  nodeIds: string[],
  mark: NodeMark
) {
  return post<{ success: boolean; updated: number }>('/nodes/batch-mark', {
    nodeIds,
    mark,
  });
}

/**
 * 导出节点数据（返回blob）
 */
export async function exportNodeData(params: NodeListParams = {}) {
  // 对于文件下载类请求，需要定制化处理响应
  const url = `/nodes/export`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(params),
  });
  
  if (!response.ok) {
    throw new Error(`导出失败: ${response.statusText}`);
  }
  
  return await response.blob();
} 