import { get, post, upload, del } from "./index";
import { PaginatedResponse, RaEngineConfigQuery, RaEngineConfigPageQuery, RaEngineConfigVO } from '../types/engineConfig';

export const engineConfigApi = {
  create(data: RaEngineConfigQuery) { 
    return post<string>('/riskAssessment/engineConfig/create', data); 
  },
  update(data: RaEngineConfigQuery) { 
    return post<string>('/riskAssessment/engineConfig/update', data); 
  },
  page(data: RaEngineConfigPageQuery) { 
    return post<PaginatedResponse<RaEngineConfigVO>>('/riskAssessment/engineConfig/page', data); 
  },
  enable(id: string) { 
    return post<string>(`/riskAssessment/engineConfig/enable/${id}`); 
  },
  disable(id: string) { 
    return post<string>(`/riskAssessment/engineConfig/disable/${id}`); 
  },
  delete(id: string) { 
    return post<string>(`/riskAssessment/engineConfig/delete/${id}`); 
  },
  info(id: string) { 
    return get<RaEngineConfigVO>(`/riskAssessment/engineConfig/info/${id}`); 
  },
}; 