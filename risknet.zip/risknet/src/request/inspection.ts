/**
 * 抽检模块相关API
 */
import { get, post } from './index';
import { NodeStatus, NodeMark } from '@/types';

// 版本信息
export interface Version {
  id: string;
  name: string;
  entityType: string;
  createdAt: string;
}

// 抽检类型
export enum InspectionType {
  RANDOM = 'random',
  EXACT_MATCH = 'exactMatch',
  FUZZY_MATCH = 'fuzzyMatch'
}

// 查询节点参数
export interface QueryNodesParams {
  inspectionType: InspectionType;
  entityType: string;
  versionId: string;
  sampleRate?: number; // 抽检比例，随机抽检时使用
  name?: string; // 名称，精确和模糊匹配时使用
}

// 抽检结果提交参数
export interface SubmitInspectionParams {
  versionId: string;
  nodeId: string;
  status: NodeStatus;
  mark: NodeMark;
  comment: string;
}

// 抽检记录状态过滤类型
export type InspectionStatusFilter = 'all' | NodeStatus | 'adjusted';

// 抽检记录标记过滤类型
export type InspectionMarkFilter = 'all' | NodeMark;

// 抽检记录时间过滤类型
export type InspectionTimeFilter = 'all' | 'day' | 'week' | 'month' | 'quarter';

// 抽检记录查询参数
export interface QueryInspectionParams {
  status?: InspectionStatusFilter;
  mark?: InspectionMarkFilter;
  time?: InspectionTimeFilter;
  page?: number;
  pageSize?: number;
}

// 抽检记录
export interface InspectionRecord {
  id: string;
  nodeId: string;
  nodeName: string;
  status: NodeStatus;
  mark: NodeMark;
  comment: string;
  inspectedAt: string;
  operator: string;
}

/**
 * 获取版本列表
 */
export async function getVersionList(entityType?: string) {
  return get<Version[]>('/inspection/versions', { 
    params: entityType ? { entityType } : undefined 
  });
}

/**
 * 查询待抽检节点
 */
export async function queryNodes(params: QueryNodesParams) {
  return post<{
    list: {
      id: string;
      name: string;
      entityType: string;
      data: any;
      comment: string;
      createdAt: string;
      updatedAt: string;
    }[];
  }>('/inspection/query-nodes', params);
}

/**
 * 提交抽检结果
 */
export async function submitInspection(params: SubmitInspectionParams) {
  return post<{ success: boolean }>('/inspection/submit', params);
}

/**
 * 获取抽检记录列表
 */
export async function getInspectionList(params: QueryInspectionParams = {}) {
  return get<{
    list: InspectionRecord[];
    total: number;
    page: number;
    pageSize: number;
  }>('/inspection/list', { params });
}

/**
 * 获取抽检记录详情
 */
export async function getInspectionDetail(recordId: string) {
  return get<InspectionRecord>(`/inspection/detail/${recordId}`);
} 