/**
 * 用户认证与权限相关API
 */
import { get, post, put, ResponseListResult } from "./index";
import { UserParams, ChangePasswordParams } from "@/types/user";
import { LoginParams, UserInfo } from "@/types/user";

/**
 * 用户登录
 */
export async function requestLogin(params: LoginParams) {
  return post<{ accessToken: string }>("/login", params);
}

/**
 * 获取当前用户信息
 */
export async function requestCurrentUser() {
  return get<UserInfo>("/sys/user/me");
}

/**
 * 获取用户列表 (超管权限)
 */
export async function requestUserList() {
  return post<ResponseListResult<UserInfo>>("/sys/user/page");
}

/**
 * 创建用户 (超管权限)
 */
export async function requestCreateUser(params: UserParams) {
  return post<UserInfo>("/sys/user/create", params);
}

/**
 * 删除用户 (超管权限)
 */
export async function requestDeleteUser(userId: number) {
  return post<{ success: boolean }>(`/sys/user/delete/${userId}`);
}

/**
 * 修改用户 (超管权限)
 */
export async function requestUpdateUser(params: UserParams) {
  return put<UserInfo>(`/sys/user/update`, params);
}

/**
 * 修改当前用户密码
 */
export async function requestChangePassword(params: ChangePasswordParams) {
  return post<{ success: boolean }>("/sys/user/changePassword", params);
}

/**
 * 登出
 */
export async function requestLogout() {
  return post<{ success: boolean }>("/user/logout");
}
