import { create } from "zustand";
import { InspectionRecord, UpdateRecord, NodeStatus, NodeMark } from "@/types";

interface DataState {
  inspectionRecords: InspectionRecord[];
  updateRecords: UpdateRecord[];
  exportFormat: "JSON" | "Excel" | "CSV";
  importFormat: "JSON" | "Excel";
  isUploading: boolean;
  isUpdating: boolean;
  filterStatus: NodeStatus | "all";
  filterMark: NodeMark | "all";
  filterTimeRange: "all" | "day" | "week" | "month" | "threeMonths";

  // 操作方法
  setInspectionRecords: (records: InspectionRecord[]) => void;
  addInspectionRecord: (record: InspectionRecord) => void;
  setUpdateRecords: (records: UpdateRecord[]) => void;
  addUpdateRecord: (record: UpdateRecord) => void;
  setExportFormat: (format: "JSON" | "Excel" | "CSV") => void;
  setImportFormat: (format: "JSON" | "Excel") => void;
  setIsUploading: (isUploading: boolean) => void;
  setIsUpdating: (isUpdating: boolean) => void;
  setFilterStatus: (status: NodeStatus | "all") => void;
  setFilterMark: (mark: NodeMark | "all") => void;
  setFilterTimeRange: (
    range: "all" | "day" | "week" | "month" | "threeMonths"
  ) => void;
}

const useDataStore = create<DataState>((set) => ({
  inspectionRecords: [],
  updateRecords: [],
  exportFormat: "JSON",
  importFormat: "JSON",
  isUploading: false,
  isUpdating: false,
  filterStatus: "all",
  filterMark: "all",
  filterTimeRange: "all",

  setInspectionRecords: (records) => set({ inspectionRecords: records }),
  addInspectionRecord: (record) =>
    set((state) => ({
      inspectionRecords: [...state.inspectionRecords, record],
    })),
  setUpdateRecords: (records) => set({ updateRecords: records }),
  addUpdateRecord: (record) =>
    set((state) => ({
      updateRecords: [...state.updateRecords, record],
    })),
  setExportFormat: (format) => set({ exportFormat: format }),
  setImportFormat: (format) => set({ importFormat: format }),
  setIsUploading: (isUploading) => set({ isUploading }),
  setIsUpdating: (isUpdating) => set({ isUpdating }),
  setFilterStatus: (status) => set({ filterStatus: status }),
  setFilterMark: (mark) => set({ filterMark: mark }),
  setFilterTimeRange: (range) => set({ filterTimeRange: range }),
}));

export default useDataStore;
