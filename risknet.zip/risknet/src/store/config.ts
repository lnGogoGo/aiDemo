import { create } from "zustand";

interface ConfigState {
  categoryTypes: Record<string, string>;
  multimodalModels: Record<string, string>;
  sourceTypes: Record<string, string>;
  setCategoryTypes: (categoryTypes: Record<string, string>) => void;
  setMultimodalModels: (multimodalModels: Record<string, string>) => void;
  setSourceTypes: (sourceTypes: Record<string, string>) => void;
}

const useConfigStore = create<ConfigState>((set) => ({
  categoryTypes: {},
  multimodalModels: {},
  sourceTypes: {},
  setCategoryTypes: (categoryTypes) => set({ categoryTypes }),
  setMultimodalModels: (multimodalModels) => set({ multimodalModels }),
  setSourceTypes: (sourceTypes) => set({ sourceTypes }),
}));

export default useConfigStore;
