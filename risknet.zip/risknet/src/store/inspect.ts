import { create } from "zustand";
import { EntityType, InspectionMethod } from "@/types";

interface InspectState {
  inspectionMethod: InspectionMethod;
  selectedEntityType: EntityType | null;
  sampleRatio: number;
  searchName: string;
  isInspecting: boolean;

  // 操作方法
  setInspectionMethod: (method: InspectionMethod) => void;
  setSelectedEntityType: (type: EntityType | null) => void;
  setSampleRatio: (ratio: number) => void;
  setSearchName: (name: string) => void;
  startInspection: () => void;
  stopInspection: () => void;
  resetInspection: () => void;
}

const useInspectStore = create<InspectState>((set) => ({
  inspectionMethod: InspectionMethod.RANDOM,
  selectedEntityType: EntityType.INDUSTRY,
  sampleRatio: 0.1, // 默认抽检10%
  searchName: "",
  isInspecting: false,

  setInspectionMethod: (method) => set({ inspectionMethod: method }),
  setSelectedEntityType: (type) => set({ selectedEntityType: type }),
  setSampleRatio: (ratio) => set({ sampleRatio: ratio }),
  setSearchName: (name) => set({ searchName: name }),
  startInspection: () => set({ isInspecting: true }),
  stopInspection: () => set({ isInspecting: false }),
  resetInspection: () =>
    set({
      inspectionMethod: InspectionMethod.RANDOM,
      selectedEntityType: null,
      sampleRatio: 0.1,
      searchName: "",
      isInspecting: false,
    }),
}));

export default useInspectStore;
