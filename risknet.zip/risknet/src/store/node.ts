import { create } from "zustand";
import { Node, NodeStatus, NodeMark } from "@/types";

interface NodeState {
  nodes: Node[];
  selectedNode: Node | null;
  viewMode: "list" | "json" | "graph";

  // 操作方法
  setNodes: (nodes: Node[]) => void;
  selectNode: (node: Node | null) => void;
  updateNodeStatus: (
    nodeId: string,
    status: NodeStatus,
    feedback?: string
  ) => void;
  updateNodeMark: (nodeId: string, mark: NodeMark) => void;
  setViewMode: (mode: "list" | "json" | "graph") => void;
}

const useNodeStore = create<NodeState>((set, get) => ({
  nodes: [],
  selectedNode: null,
  viewMode: "list",

  setNodes: (nodes) => set({ nodes }),
  selectNode: (node) => set({ selectedNode: node }),
  updateNodeStatus: (nodeId, status, feedback) => {
    const nodes = get().nodes.map((node) =>
      node.id === nodeId
        ? { ...node, status, feedback: feedback || node.feedback }
        : node
    );
    set({ nodes });

    // 如果是选中的节点，也更新它
    const selectedNode = get().selectedNode;
    if (selectedNode && selectedNode.id === nodeId) {
      set({
        selectedNode: {
          ...selectedNode,
          status,
          feedback: feedback || selectedNode.feedback,
        },
      });
    }
  },
  updateNodeMark: (nodeId, mark) => {
    const nodes = get().nodes.map((node) =>
      node.id === nodeId ? { ...node, mark } : node
    );
    set({ nodes });

    // 如果是选中的节点，也更新它
    const selectedNode = get().selectedNode;
    if (selectedNode && selectedNode.id === nodeId) {
      set({ selectedNode: { ...selectedNode, mark } });
    }
  },
  setViewMode: (mode) => set({ viewMode: mode }),
}));

export default useNodeStore;
