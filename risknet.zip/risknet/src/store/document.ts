import { create } from "zustand";
import { DocumentParseConfig } from "@/types";
import { requestDocumentConfig } from "@/request/document";
import useConfigStore from './config';

interface DocumentState {
  config: DocumentParseConfig;
  setState: (state: DocumentState) => void;
}

const useDocumentStore = create<DocumentState>((set) => ({
  config: {},
  setState: (state) => set(state),
}));

export const initDocumentStore = async () => {
  const config = await requestDocumentConfig();
  useDocumentStore.setState({ config });
  
  // After fetching config, update the config store
  const configStore = useConfigStore.getState();
  configStore.setCategoryTypes(config.categoryTypes || {});
  configStore.setMultimodalModels(config.multimodalModels || {});
  configStore.setSourceTypes(config.sourceTypes || {});
};

export default useDocumentStore;
