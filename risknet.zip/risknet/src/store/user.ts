import { create } from "zustand";
import { requestLogin, requestCurrentUser } from "@/request/user";
import { UserInfo, LoginParams } from "@/types/user";
import { TOKEN_KEY } from "@/request/index";
import { initDocumentStore } from "./document";

if (typeof globalThis.localStorage === 'undefined') {
  globalThis.localStorage = { getItem: () => {}, setItem: () => {} }
}

export const ROLES = [
  {
    id: 1,
    name: "管理员",
    permissions: ["*"],
  },
  {
    id: 2,
    name: "用户",
    permissions: ["user"],
  },
];

interface UserState {
  isLoggedIn: boolean;
  userInfo: UserInfo | null;
  token: string | null;
  loading: boolean;
  error: string | null;
  authorized: boolean;
  initialized: boolean;

  // Actions
  login: (params: LoginParams) => Promise<boolean>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<boolean>;
  setUserInfo: (userInfo: UserInfo) => void;
  clearError: () => void;
  initialize: () => Promise<void>;
}

export const useUserStore = create<UserState>()((set) => ({
  isLoggedIn: !!globalThis.localStorage.getItem(TOKEN_KEY),
  userInfo: null,
  token: globalThis.localStorage.getItem(TOKEN_KEY) || null,
  loading: false,
  error: null,
  authorized: false,
  initialized: false,

  initialize: async () => {
    const token = globalThis.localStorage.getItem(TOKEN_KEY);

    if (!token) {
      set({
        authorized: false,
        initialized: true,
        isLoggedIn: false,
        userInfo: null,
        token: null,
      });
      return;
    }

    try {
      set({ loading: true });
      const response = await requestCurrentUser();

      if (response && response.data) {
        set({
          isLoggedIn: true,
          userInfo: response.data,
          authorized: true,
          initialized: true,
          loading: false,
        });

        initDocumentStore();
      } else {
        throw new Error("获取用户信息失败");
      }
    } catch (error) {
      console.error("初始化用户信息失败", error);
      localStorage.removeItem(TOKEN_KEY);
      set({
        isLoggedIn: false,
        userInfo: null,
        token: null,
        authorized: false,
        initialized: true,
        loading: false,
        error: "登录已过期，请重新登录",
      });
    }
  },

  login: async (params: LoginParams) => {
    try {
      set({ loading: true, error: null });
      const response = await requestLogin(params);

      if (response && response.data) {
        const { accessToken } = response.data;

        if (!accessToken) {
          throw new Error(`${response.data}`);
        }

        globalThis.localStorage.setItem(TOKEN_KEY, accessToken);

        await new Promise((resolve) => setTimeout(resolve, 100));

        const userInfo = await requestCurrentUser();
        initDocumentStore();

        set({
          isLoggedIn: true,
          loading: false,
          userInfo: userInfo.data,
          authorized: true,
          initialized: true,
        });

        return true;
      }

      throw new Error("登录失败，请检查用户名和密码");
    } catch (error) {
      set({
        loading: false,
        error: error instanceof Error ? error.message : "登录失败",
        authorized: false,
      });
      return false;
    }
  },

  logout: async () => {
    globalThis.localStorage.removeItem(TOKEN_KEY);
    set({
      isLoggedIn: false,
      userInfo: null,
      token: null,
      loading: false,
      authorized: false,
    });
  },

  checkAuth: async () => {
    const token = globalThis.localStorage.getItem(TOKEN_KEY);

    if (!token) {
      set({
        isLoggedIn: false,
        userInfo: null,
        token: null,
        authorized: false,
        initialized: true,
      });
      return false;
    }

    try {
      set({ loading: true });
      const response = await requestCurrentUser();
      initDocumentStore();

      if (response && response.data) {
        set({
          isLoggedIn: true,
          userInfo: response.data,
          loading: false,
          authorized: true,
          initialized: true,
        });
        return true;
      }

      throw new Error("获取用户信息失败");
    } catch (error) {
      console.error("检查用户信息失败", error);
      globalThis.localStorage.removeItem(TOKEN_KEY);

      set({
        isLoggedIn: false,
        userInfo: null,
        token: null,
        loading: false,
        error: "登录已过期，请重新登录",
        authorized: false,
        initialized: true,
      });
      return false;
    }
  },

  setUserInfo: (userInfo: UserInfo) => {
    set({ userInfo });
  },

  clearError: () => {
    set({ error: null });
  },
}));

// 帮助函数：检查用户是否有特定权限
export function hasPermission(permission: string): boolean {
  return true;
  const { userInfo } = useUserStore.getState();
  return userInfo?.permissions?.includes(permission) || false;
}

// 用于拦截API请求，添加认证令牌的函数
export function getAuthHeader() {
  const token = globalThis.localStorage.getItem(TOKEN_KEY);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

if (typeof window !== "undefined") {
  (window as any).useUserStore = useUserStore;
}
