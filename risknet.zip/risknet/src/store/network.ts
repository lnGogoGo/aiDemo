import { create } from "zustand";
import { EntityType, InitTaskStatus, Version } from "@/types";

interface NetworkState {
  currentVersion: Version | null;
  versions: Version[];
  entityTypes: EntityType[];
  initTaskStatus: InitTaskStatus;
  documentUploaded: boolean;
  pageRange: { start: number; end: number } | null;

  // 操作方法
  setCurrentVersion: (version: Version) => void;
  setVersions: (versions: Version[]) => void;
  startInitialization: () => void;
  completeInitialization: () => void;
  resetInitialization: () => void;
  setDocumentUploaded: (uploaded: boolean) => void;
  setPageRange: (range: { start: number; end: number } | null) => void;
}

const useNetworkStore = create<NetworkState>((set) => ({
  currentVersion: null,
  versions: [],
  entityTypes: [
    EntityType.INDUSTRY,
    EntityType.POPULATION,
    EntityType.RISK_TYPE,
    EntityType.LOCATION,
  ],
  initTaskStatus: InitTaskStatus.NOT_STARTED,
  documentUploaded: false,
  pageRange: null,

  setCurrentVersion: (version) => set({ currentVersion: version }),
  setVersions: (versions) => set({ versions }),
  startInitialization: () =>
    set({ initTaskStatus: InitTaskStatus.IN_PROGRESS }),
  completeInitialization: () =>
    set({ initTaskStatus: InitTaskStatus.COMPLETED }),
  resetInitialization: () =>
    set({
      initTaskStatus: InitTaskStatus.NOT_STARTED,
      documentUploaded: false,
      pageRange: null,
    }),
  setDocumentUploaded: (uploaded) => set({ documentUploaded: uploaded }),
  setPageRange: (range) => set({ pageRange: range }),
}));

export default useNetworkStore;
