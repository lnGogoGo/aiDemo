"use client";

import React from "react";
import { Switch, Tooltip } from "antd";
import StatusDot from "@/components/common/StatusDot";
import { formatDate } from "@/components/common/DetailDrawer";

// 创建基础列配置
export const createColumn = (label: string, key: string, options: any = {}) => {
  return {
    label,
    key,
    ...options,
  };
};

// 创建日期时间列
export const createDateTimeColumn = (label: string, key: string, options: any = {}) => {
  return createColumn(label, key, {
    dataRender: (row: any) => formatDate(row[key]),
    ...options,
  });
};

// 创建带截断和提示的文本列
export const createTooltipColumn = (label: string, key: string, maxWidth = 180, options: any = {}) => {
  return createColumn(label, key, {
    dataRender: (row: any) => (
      <Tooltip placement="topLeft" title={row[key]}>
        <span className={`truncate max-w-[${maxWidth}px] inline-block align-middle`}>
          {row[key]}
        </span>
      </Tooltip>
    ),
    ...options,
  });
};

// 创建状态列
export const createStatusColumn = (
  label: string, 
  hasActiveKey = "hasActive", 
  options: any = {}
) => {
  return createColumn(label, '_', {
    dataRender: (row: any) => <StatusDot active={row[hasActiveKey]} />,
    ...options,
  });
};

// 创建开关列
export const createSwitchColumn = (
  label: string,
  key = "hasActive",
  onChangeHandler: (record: any, checked: boolean, index?: number) => Promise<void> | void,
  options: any = {}
) => {
  return createColumn(label, key, {
    dataRender: (row: any, index?: number) => (
      <Switch
        checked={row[key]}
        onChange={(checked) => onChangeHandler(row, checked, index)}
      />
    ),
    ...options,
  });
};

// 创建操作列
export const createActionColumn = (actions: any, options: any = {}) => {
  return createColumn("操作", "action", {
    className:
      'sticky right-0 bg-white z-10 before:content-[""] before:absolute before:left-0 before:top-0 before:h-full before:w-4 before:shadow-[-4px_0_6px_-1px_rgba(0,0,0,0.1)]',
    headClassName: "bg-muted",
    dataRender: (row: any) => actions(row),
    ...options,
  });
}; 