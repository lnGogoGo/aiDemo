import { useEffect, useRef, useState, useCallback } from "react";

/**
 * 一个自定义 Hook，它在页面可见时，使用递归的 setTimeout 按指定间隔执行回调函数。
 * 当页面不可见时，定时器会暂停，并在页面再次可见时恢复。
 * 如果回调函数返回 false，则定时器会停止。
 *
 * @param callback 要定时执行的函数。可以返回 false 来停止后续的定时任务。
 * @param delay 两次执行回调函数之间的延迟时间（以毫秒为单位）。如果为 null，则定时器会停止。
 */
export const useIntervalWhenVisible = (
  callback: () => (Promise<boolean | void | undefined> | boolean | void | undefined),
  delay: number | null
): void => {
  const savedCallback = useRef<() => Promise<boolean | void | undefined> | boolean | void | undefined>(callback);
  const timeoutId = useRef<NodeJS.Timeout | null>(null);
  const isVisible = useRef<boolean>(!document.hidden); // 初始状态基于当前可见性
  const shouldContinue = useRef<boolean>(true); // 新增 ref 来控制是否继续

  // 保存最新的回调函数引用
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // 清除定时器的函数
  const clearExistingTimeout = useCallback(() => {
    if (timeoutId.current) {
      clearTimeout(timeoutId.current);
      timeoutId.current = null;
    }
  }, []);

  // 设置定时器的函数
  const scheduleTimeout = useCallback(() => {
    clearExistingTimeout(); // 清除任何现有的定时器
    // 只有在 delay 有效、页面可见且应该继续时才设置定时器
    if (delay !== null && isVisible.current && shouldContinue.current) {
      timeoutId.current = setTimeout(async () => {
        const result = await savedCallback.current(); // 执行回调并获取结果
        // 如果回调返回 false，则设置 shouldContinue 为 false
        if (result === false) {
          shouldContinue.current = false;
          console.log("Callback returned false, stopping interval.");
          clearExistingTimeout(); // 立即清除，避免最后一次延迟后还执行
        } else {
          // 否则，递归调用以安排下一次执行
          scheduleTimeout();
        }
      }, delay);
    }
  }, [delay, clearExistingTimeout]);

  // 处理可见性变化的函数
  const handleVisibilityChange = useCallback(() => {
    const becomingVisible = !document.hidden;
    isVisible.current = becomingVisible;

    if (becomingVisible) {
      // 页面变为可见，如果需要且应该继续，启动或恢复定时器
      console.log(
        "Page became visible, scheduling timeout if should continue."
      );
      // 重置 shouldContinue 为 true，除非它已经被 callback 设为 false
      // 如果希望页面隐藏再显示后总是重新开始，可以取消下面的注释
      // shouldContinue.current = true;
      scheduleTimeout();
    } else {
      // 页面变为不可见，清除定时器
      console.log("Page became hidden, clearing timeout.");
      clearExistingTimeout();
    }
  }, [scheduleTimeout, clearExistingTimeout]);

  // 设置和清除定时器的主 useEffect
  useEffect(() => {
    // 每次 delay 变化时，重置 shouldContinue 状态
    shouldContinue.current = true;
    // 初始调度
    scheduleTimeout();

    // 添加可见性变化事件监听器
    document.addEventListener("visibilitychange", handleVisibilityChange);

    // 清理函数：移除监听器并清除定时器
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      clearExistingTimeout();
    };
  }, [delay, scheduleTimeout, handleVisibilityChange, clearExistingTimeout]); // 依赖项包括 delay 和回调函数
};

export const useStateWithCallback = (
  initialState: any,
  callback: (state: any) => void
) => {
  const [state, setState] = useState(initialState);

  useEffect(() => {
    callback(state);
  }, [state]);

  return [state, setState];
};

export const useStateWithRef = (initialState: any) => {
  const [state, setState] = useState(initialState);
  const ref = useRef(initialState);

  useEffect(() => {
    ref.current = state;
  }, [state]);

  return [state, setState, ref];
};
