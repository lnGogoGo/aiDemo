import { useState, useCallback } from "react";
import { NoticeType } from "antd/es/message/interface";

export type EntityId = string;

export interface CrudOptions<T> {
  deleteApi: (id: EntityId) => Promise<any>;
  enableApi?: (id: EntityId) => Promise<any>;
  disableApi?: (id: EntityId) => Promise<any>;
  onSuccess?: () => void;
  deleteConfirmTitle?: string;
  deleteConfirmContent?: (record: T) => string;
  getEntityName?: (record: T) => string;
  showMessage: (type: NoticeType, content: string) => void;
}

export function useEntityCrud<T extends { id: EntityId; name?: string }>(
  options: CrudOptions<T>
) {
  const {
    deleteApi,
    enableApi,
    disableApi,
    onSuccess,
    deleteConfirmTitle = "确认删除",
    deleteConfirmContent = (record) => 
      `确定要删除"${record.name || record.id}"吗？`,
    getEntityName = (record) => record.name || String(record.id),
    showMessage,
  } = options;

  const [modalVisible, setModalVisible] = useState(false);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<T | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState<T | null>(null);

  const handleAdd = useCallback(() => {
    setSelectedRecord(null);
    setModalVisible(true);
  }, []);

  const handleEdit = useCallback((record: T) => {
    setSelectedRecord(record);
    setModalVisible(true);
  }, []);

  const handleView = useCallback((record: T) => {
    setSelectedRecord(record);
    setDrawerVisible(true);
  }, []);

  const handleDelete = useCallback((record: T) => {
    setRecordToDelete(record);
    setDeleteModalVisible(true);
  }, []);

  const confirmDelete = useCallback(async () => {
    if (!recordToDelete) return;
    
    setDeleteLoading(true);
    try {
      await deleteApi(recordToDelete.id);
      showMessage("success", "删除成功");
      if (onSuccess) onSuccess();
    } catch (e) {
      showMessage("error", "删除失败");
    } finally {
      setDeleteLoading(false);
      setDeleteModalVisible(false);
      setRecordToDelete(null);
    }
  }, [deleteApi, onSuccess, recordToDelete, showMessage]);

  const cancelDelete = useCallback(() => {
    setDeleteModalVisible(false);
    setRecordToDelete(null);
  }, []);

  const handleStatusChange = useCallback(
    async (record: T, checked: boolean) => {
      if (!enableApi || !disableApi) return;
      
      try {
        const api = checked ? enableApi : disableApi;
        await api(record.id);
        showMessage("success", `${checked ? "启用" : "禁用"}成功`);
        if (onSuccess) onSuccess();
      } catch (e) {
        showMessage("error", `${checked ? "启用" : "禁用"}失败`);
      }
    },
    [enableApi, disableApi, onSuccess, showMessage]
  );

  const handleModalSuccess = useCallback(
    (msg: string = "操作成功") => {
      showMessage("success", msg);
      setModalVisible(false);
      if (onSuccess) onSuccess();
    },
    [onSuccess, showMessage]
  );

  const closeModal = useCallback(() => {
    setModalVisible(false);
    setSelectedRecord(null);
  }, []);

  const closeDrawer = useCallback(() => {
    setDrawerVisible(false);
    setSelectedRecord(null);
  }, []);

  return {
    selectedRecord,
    modalVisible,
    drawerVisible,
    deleteLoading,
    deleteModalVisible,
    recordToDelete,
    deleteConfirmTitle,
    deleteConfirmContent,
    handleAdd,
    handleEdit,
    handleView,
    handleDelete,
    handleStatusChange,
    handleModalSuccess,
    closeModal,
    closeDrawer,
    confirmDelete,
    cancelDelete
  };
} 