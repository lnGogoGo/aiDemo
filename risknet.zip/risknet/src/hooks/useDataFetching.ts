import { useState, useEffect, useCallback } from "react";
import { NoticeType } from "antd/es/message/interface";

export interface UseDataFetchingOptions<T> {
  fetchApi: () => Promise<{data: T[] | T}>;
  defaultValue?: T[];
  errorMessage?: string;
  transformData?: (data: any) => T[];
  autoFetch?: boolean;
  onSuccess?: (data: T[]) => void;
  onError?: (error: any) => void;
  showMessage: (type: NoticeType, content: string) => void;
}

export function useDataFetching<T>(options: UseDataFetchingOptions<T>) {
  const {
    fetchApi,
    defaultValue = [],
    errorMessage = "获取数据失败",
    transformData,
    autoFetch = true,
    onSuccess,
    onError,
    showMessage,
  } = options;

  const [data, setData] = useState<T[]>(defaultValue);
  const [loading, setLoading] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetchApi();
      let responseData: T[] = [];
      
      if (Array.isArray(response.data)) {
        responseData = response.data;
      } else if (transformData) {
        responseData = transformData(response.data);
      } else {
        responseData = [response.data] as T[];
      }
      
      setData(responseData);
      if (onSuccess) onSuccess(responseData);
    } catch (error) {
      if (onError) {
        onError(error);
      } else {
        showMessage("error", errorMessage);
      }
    } finally {
      setLoading(false);
    }
  }, [fetchApi, transformData, errorMessage, onSuccess, onError, showMessage]);

  useEffect(() => {
    if (autoFetch) {
      fetchData();
    }
  }, [autoFetch, fetchData]);

  return {
    data,
    setData,
    loading,
    refresh: fetchData,
  };
} 