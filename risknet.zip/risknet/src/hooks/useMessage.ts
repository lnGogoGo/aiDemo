import { message as antdMessage } from "antd";
import { NoticeType } from "antd/es/message/interface";
import { useCallback } from "react";

/**
 * 消息通知hook
 * 
 * 使用方法:
 * ```tsx
 * const { showMessage, contextHolder } = useMessage();
 * 
 * // 在组件返回中包含contextHolder
 * return (
 *   <>
 *     {contextHolder}
 *     <Component />
 *   </>
 * )
 * ```
 * 
 * @returns {{ showMessage: (type: NoticeType, content: string) => void, contextHolder: React.ReactElement }}
 */
export const useMessage = () => {
  const [messageApi, contextHolder] = antdMessage.useMessage();
  
  const showMessage = useCallback(
    (type: NoticeType, content: string) => {
      messageApi.open({ 
        type, 
        content, 
        duration: 1.5 
      });
    }, 
    [messageApi]
  );
  
  return {
    showMessage,
    contextHolder
  };
}; 