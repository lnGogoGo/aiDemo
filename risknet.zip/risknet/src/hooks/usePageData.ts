import { useState, useCallback, useEffect } from "react";
import { FormInstance } from "antd/es/form";
import { NoticeType } from "antd/es/message/interface";

export interface PageQuery {
  current?: number;
  size?: number;
  [key: string]: any;
}

export interface PageResponse<T> {
  records: T[];
  total: number;
  size?: number;
  current?: number;
  pages?: number;
}

export interface UsePageDataOptions<T, Q extends PageQuery> {
  pageApi: (params: Q) => Promise<{data: PageResponse<T>}>;
  initialQuery?: Partial<Q>;
  pageSize?: number;
  onError?: (error: any) => void;
  showMessage?: (type: NoticeType, content: string) => void;
}

export function usePageData<T, Q extends PageQuery>(
  form: FormInstance,
  options: UsePageDataOptions<T, Q>
) {
  const { 
    pageApi, 
    initialQuery = {}, 
    pageSize = 10, 
    onError,
    showMessage 
  } = options;
  
  const [data, setData] = useState<T[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [loading, setLoading] = useState(false);
  const [searchParams, setSearchParams] = useState<Partial<Q>>(initialQuery);
  
  const fetchData = useCallback(async (page = 1, params = searchParams) => {
    setLoading(true);
    try {
      const query = {
        current: page,
        size: pageSize,
        ...params,
      } as Q;
      
      const response = await pageApi(query);
      setData(response?.data.records || []);
      setTotal(response?.data.total || 0);
    } catch (error) {
      if (onError) {
        onError(error);
      } else {
        showMessage?.("error", "获取数据失败");
      }
    } finally {
      setLoading(false);
    }
  }, [pageApi, pageSize, searchParams, onError, showMessage]);
  
  const handleSearch = useCallback(() => {
    const formValues = form.getFieldsValue();
    setSearchParams(formValues);
    setCurrent(1);
  }, [form]);
  
  const handleReset = useCallback(() => {
    form.resetFields();
    setSearchParams(initialQuery);
    setCurrent(1);
  }, [form, initialQuery]);
  
  const handlePageChange = useCallback((page: number) => {
    setCurrent(page);
  }, []);
  
  const refresh = useCallback(() => {
    fetchData(current, searchParams);
  }, [fetchData, current, searchParams]);
  
  useEffect(() => {
    fetchData(current, searchParams);
  }, [current, searchParams, fetchData]);
  
  return {
    data,
    total,
    current,
    loading,
    searchParams,
    setSearchParams,
    setData,
    fetchData,
    handleSearch,
    handleReset,
    handlePageChange,
    refresh,
  };
} 