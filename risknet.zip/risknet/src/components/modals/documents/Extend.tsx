import React, { useState, useMemo } from "react";
import Editor from "@monaco-editor/react";
import { SnExpandTaskBatchVO } from "@/types/document";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import ModalService from "@/helpers/modal";
import { requestUpdateExpandTaskResult } from "@/request/document";

interface ExpandTaskBatchResultModalProps {
  batchResult: SnExpandTaskBatchVO;
  onClose: () => void;
  onSubmit: () => void;
}

export const ExpandTaskBatchResultModal = ({
  batchResult,
  onClose,
  onSubmit,
}: ExpandTaskBatchResultModalProps) => {
  const [editorValue, setEditorValue] = useState<string>(
    JSON.stringify(batchResult.results || {}, null, 2)
  );

  const handleExport = () => {
    const blob = new Blob([editorValue], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `expand-${batchResult.expandId}-batch-${batchResult.batchNum}.json`;
    a.click();

    toast.success("导出成功");
  };

  const handleImport = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";

    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement)?.files?.[0];

      if (file) {
        const reader = new FileReader();

        reader.onload = () => {
          try {
            const json = JSON.parse(reader.result as string);
            setEditorValue(JSON.stringify(json, null, 2));
          } catch (error) {
            toast.error("无效的JSON文件");
          }
        };

        reader.readAsText(file);
      }
    };

    input.click();
  };

  const handleSubmit = async () => {
    try {
      if (!confirm("确定要提交修改吗？")) {
        return;
      }

      const parsedResults = JSON.parse(editorValue);

      await requestUpdateExpandTaskResult({
        id: batchResult.expandId!,
        results: {
          [batchResult.batchNum!.toString()]: parsedResults,
        },
      });

      toast.success("提交成功");
      onSubmit();
      onClose();
    } catch (error: any) {
      toast.error(error.message || "提交失败");
    }
  };

  const errorInfo = useMemo(() => {
    if (batchResult.errors && batchResult.errors.length > 0) {
      return batchResult.errors.join(", ");
    }

    return "无";
  }, [batchResult.errors]);

  return (
    <div className="flex flex-col items-stretch">
      <h2 className="text-sm font-semibold text-black/80 -mt-4">
        扩展任务ID：{batchResult.expandId}，批次号：{batchResult.batchNum}
      </h2>
      <div className="mt-1 mb-4 text-xs text-black/60">
        <div>状态：{batchResult.status}</div>
        <div>已处理术语：{batchResult.processedTerms?.join(", ") || "无"}</div>
        {errorInfo.length > 0 && (
          <div className="text-red-500">错误信息：{errorInfo}</div>
        )}
      </div>
      <Editor
        theme="vs-dark"
        defaultLanguage="json"
        value={editorValue}
        onChange={(value) => {
            setEditorValue(value || "");
        }}
        className="rounded-md overflow-hidden"
        height="40vh"
      />
      <div className="flex justify-end gap-2 mt-4">
        <Button variant="outline" onClick={handleExport}>
          导出为JSON文件
        </Button>
        <Button variant="outline" onClick={handleImport}>
          导入JSON文件
        </Button>
        <div className="flex-1" />
        <Button variant="outline" onClick={onClose}>
          关闭
        </Button>
        <Button onClick={handleSubmit}>提交修改</Button>
      </div>
    </div>
  );
};

export const showExpandTaskBatchResult = (batchResult: SnExpandTaskBatchVO) => {
  ModalService.showModal({
    maxWidth: "2xl",
    content: (closeModal) => (
      <ExpandTaskBatchResultModal
        batchResult={batchResult}
        onClose={closeModal}
        onSubmit={() => {}}
      />
    ),
  });
};
