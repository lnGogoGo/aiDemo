import React, { useMemo, useState } from "react";
import Editor from "@monaco-editor/react";
import {
  Document,
  DocumentParsePageResult,
  DocumentParseTask,
} from "@/types/document";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WrappedSelect } from "@/components/ui/select";
import ModalService from "@/helpers/modal";
import {
  requestResumeTask,
  requestSubmitParseTask,
  requestUpdateTaskPageResult,
} from "@/request/document";
import useConfigStore from "@/store/config";

interface DocumentParseModalProps {
  document: Document;
  onClose: () => void;
  onSubmit: () => void;
}

interface DocumentParsePageResultModalProps {
  parseId: string;
  pageResult: DocumentParsePageResult;
  onClose: () => void;
  onSubmit: () => void;
}

export const DocumentParseModal = ({
  document,
  onClose,
  onSubmit,
}: DocumentParseModalProps) => {
  const [categoryType, setCategoryType] = useState<string>("");
  const [startPage, setStartPage] = useState<number>(1);
  const [endPage, setEndPage] = useState<number>(10);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [modelName, setModelName] = useState<string>("");
  const [sourceName, setSourceName] = useState<string>("");
  const [sourceType, setSourceType] = useState<string>("");

  const { categoryTypes, multimodalModels, sourceTypes } = useConfigStore();

  const categoryTypeOptions = Object.entries(categoryTypes || {}).map(
    ([key, value]) => ({
      label: value,
      value: key,
    })
  );

  const modelOptions = Object.entries(multimodalModels || {}).map(
    ([key, value]) => ({
      label: value,
      value: key,
    })
  );

  const sourceTypeOptions = Object.entries(sourceTypes || {}).map(
    ([key, value]) => ({
      label: value,
      value: key,
    })
  );

  const allowSubmit = useMemo(() => {
    return (
      categoryType &&
      sourceType &&
      modelName &&
      sourceName &&
      startPage > 0 &&
      endPage > 0 &&
      startPage <= endPage
    );
  }, [categoryType, sourceType, modelName, sourceName, startPage, endPage]);

  const handleSubmit = async () => {
    setSubmitting(true);

    if (!categoryType || startPage > endPage) {
      alert("请检查输入信息是否正确");
      return;
    }

    try {
      const response = await requestSubmitParseTask({
        docId: document.id!,
        startPage,
        endPage,
        categoryType,
        sourceName,
        sourceType,
        modelName,
      });

      if (response) {
        toast.success("解析任务提交成功");
        onSubmit();
        onClose();
      }
    } catch (error: any) {
      toast.error(error.message || "提交解析任务失败");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      {document && (
        <>
          <div className="flex flex-col items-stretch mb-4 space-y-1 border p-3 bg-gray-50 rounded-md">
            <span className="font-medium text-sm">{document.filename}</span>
            <div className="flex items-center text-xs">
              <span className="text-black/60">创建时间:</span>
              <span className="font-medium text-black/60 ml-1">
                {document.taskUpdatedAt &&
                  new Date(document.taskUpdatedAt).toLocaleString()}
              </span>
            </div>
          </div>

          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">分类类型</label>
            <WrappedSelect
              value={categoryType}
              options={categoryTypeOptions}
              onChange={setCategoryType}
              className="w-full border p-2 rounded"
            />
          </div>

          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">模型选择</label>
            <WrappedSelect
              value={modelName}
              options={modelOptions}
              onChange={setModelName}
              className="w-full border p-2 rounded"
            />
          </div>

          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">数据来源</label>
            <WrappedSelect
              value={sourceType}
              options={sourceTypeOptions}
              onChange={setSourceType}
              className="w-full border p-2 rounded"
            />
          </div>

          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">来源名称</label>
            <Input
              type="text"
              className="w-full border p-2 rounded"
              value={sourceName}
              onChange={(e) => setSourceName(e.target.value)}
              required
            />
          </div>

          <div className="flex gap-2">
            <div className="flex-1">
              <label className="block text-sm font-medium mb-1">起始页码</label>
              <Input
                type="number"
                min="1"
                className="w-full border p-2 rounded"
                value={startPage}
                onChange={(e) => setStartPage(parseInt(e.target.value) || 1)}
                required
              />
            </div>

            <div className="flex-1">
              <label className="block text-sm font-medium mb-1">结束页码</label>
              <Input
                type="number"
                min={startPage}
                className="w-full border p-2 rounded"
                value={endPage}
                onChange={(e) =>
                  setEndPage(parseInt(e.target.value) || startPage)
                }
                required
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={onClose}>
              取消
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!allowSubmit || submitting}
            >
              {submitting ? "提交中..." : "提交解析任务"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export const DocumentParseResumeModal = ({
  parseTask,
  onClose,
  onSubmit,
}: {
  parseTask: DocumentParseTask;
  onClose: () => void;
  onSubmit: () => void;
}) => {
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [modelName, setModelName] = useState<string>("");
  const [startPage, setStartPage] = useState<string>("1");

  const { multimodalModels } = useConfigStore();

  const modelOptions = Object.entries(multimodalModels || {}).map(
    ([key, value]) => ({
      label: value,
      value: key,
    })
  );

  const allowSubmit = !!modelName;

  const handleSubmit = async () => {
    setSubmitting(true);

    try {
      const response = await requestResumeTask({
        id: parseTask.id!,
        modelName,
        startPage: startPage ? parseInt(startPage) : undefined,
      });

      if (response) {
        toast.success("解析任务恢复成功");
        onSubmit();
        onClose();
      }
    } catch (error: any) {
      toast.error(error.message || "恢复解析任务失败");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      {parseTask && (
        <>
          <div className="flex flex-col items-stretch mb-4 space-y-1 border p-3 bg-gray-50 rounded-md">
            <span className="font-medium text-sm">ID: {parseTask.id}</span>
            <div className="flex items-center text-xs">
              <span className="text-black/60">创建时间:</span>
              <span className="font-medium text-black/60 ml-1">
                {parseTask.taskUpdatedAt &&
                  new Date(parseTask.taskUpdatedAt).toLocaleString()}
              </span>
              <span className="ml-4 text-black/60">版本:</span>
              <span className="font-medium text-black/60 ml-1">
                {parseTask.version}
              </span>
            </div>
          </div>
          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">模型选择</label>
            <WrappedSelect
              value={modelName}
              options={modelOptions}
              onChange={setModelName}
              className="w-full border p-2 rounded"
            />
          </div>

          <div className="flex gap-2 items-center mb-4">
            <label className="block text-sm font-medium w-32">起始页码</label>
            <Input
              type="number"
              min="1"
              className="w-full border p-2 rounded"
              value={startPage}
              onChange={(e) => setStartPage(e.target.value)}
              required
            />
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={onClose}>
              取消
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!allowSubmit || submitting}
            >
              {submitting ? "恢复中..." : "恢复解析任务"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export const DocumentParsePageResultModal = ({
  parseId,
  pageResult,
  onClose,
  onSubmit,
}: DocumentParsePageResultModalProps) => {
  const [editorValue, setEditorValue] = useState<string>(
    JSON.stringify(
      pageResult.status === "failed"
        ? pageResult.originalResponse
        : pageResult.results || {},
      null,
      2
    )
  );

  const handleExport = () => {
    const blob = new Blob([editorValue], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `${pageResult.taskId}-${pageResult.pageNum}.json`;
    a.click();

    toast.success("导出成功");
  };

  const handleImport = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";

    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement)?.files?.[0];

      if (file) {
        const reader = new FileReader();

        reader.onload = (e) => {
          const json = JSON.parse(reader.result as string);

          console.log(json);
          setEditorValue(JSON.stringify(json, null, 2));
        };

        reader.readAsText(file);
      }
    };

    input.click();
  };

  const handleSubmit = async () => {
    try {
      if (!confirm("确定要提交修改吗？")) {
        return;
      }

      await requestUpdateTaskPageResult({
        id: parseId,
        results: { [pageResult.pageNum]: JSON.parse(editorValue) },
      });

      toast.success("提交成功");
      onSubmit();
      onClose();
    } catch (error: any) {
      toast.error(error.message || "提交失败");
    }
  };

  return (
    <div className="flex flex-col items-stretch">
      <h2 className="text-sm font-semibold text-black/80 -mt-4">
        任务ID：{pageResult.id}，页码：{pageResult.pageNum}
        {pageResult.status === "failed" && (
          <span className="text-red-500">解析失败，以下是原始结果</span>
        )}
      </h2>
      <Editor
        theme="vs-dark"
        defaultLanguage="json"
        value={editorValue}
        onChange={(value) => {
          setEditorValue(value || "");
        }}
        className="rounded-md overflow-hidden"
        height="40vh"
      />
      <div className="flex justify-end gap-2 mt-4">
        <Button variant="outline" onClick={handleExport}>
          导出为JSON文件
        </Button>
        <Button variant="outline" onClick={handleImport}>
          导入JSON文件
        </Button>
        <div className="flex-1" />
        <Button variant="outline" onClick={onClose}>
          关闭
        </Button>
        <Button onClick={handleSubmit}>提交修改</Button>
      </div>
    </div>
  );
};

export const showParseTaskPageResult = (
  parseId: string,
  pageResult: DocumentParsePageResult,
  callback: () => void
) => {
  ModalService.showModal({
    // isFullScreen: true,
    maxWidth: "2xl",
    content: (closeModal) => (
      <DocumentParsePageResultModal
        parseId={parseId}
        pageResult={pageResult}
        onClose={closeModal}
        onSubmit={callback}
      />
    ),
  });
};

export const showParseTaskResumeModal = (
  parseTask: DocumentParseTask,
  callback: () => void
) => {
  ModalService.showModal({
    content: (closeModal) => (
      <DocumentParseResumeModal
        parseTask={parseTask}
        onClose={closeModal}
        onSubmit={callback}
      />
    ),
  });
};

export const showParseForm = (document: Document, onSubmit: () => void) => {
  ModalService.showModal({
    title: "解析文档",
    maxWidth: "md",
    content: (closeModal) => (
      <DocumentParseModal
        document={document}
        onClose={closeModal}
        onSubmit={onSubmit}
      />
    ),
  });
};
