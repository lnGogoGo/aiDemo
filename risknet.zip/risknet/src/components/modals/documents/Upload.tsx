import React, { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ModalService from "@/helpers/modal";
import { requestUploadDocument } from "@/request/document";

interface DocumentUploadModalProps {
  onClose: () => void;
  onUpload: () => void;
}

export const DocumentUploadModal = ({
  onClose,
  onUpload,
}: DocumentUploadModalProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);

  const handleUpload = async () => {
    setUploading(true);
    if (!selectedFile) {
      toast.error("请选择要上传的文件");
      setUploading(false);
      return;
    }

    try {
      await requestUploadDocument(selectedFile);
      toast.success("上传成功");
      onClose();
      onUpload();
    } catch (error: any) {
      toast.error(error.message || "上传失败");
      console.error("上传失败", error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <Input
        type="file"
        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
        className="mb-4"
      />
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onClose}>
          取消
        </Button>
        <Button onClick={handleUpload} disabled={!selectedFile || uploading}>
          {uploading ? "上传中..." : "上传"}
        </Button>
      </div>
    </div>
  );
};

export const showDocumentUploader = (props: { onUpload: () => void }) => {
  ModalService.showModal({
    title: "上传文档",
    maxWidth: "sm",
    content: (closeModal) => (
      <DocumentUploadModal onClose={closeModal} onUpload={props.onUpload} />
    ),
  });
};
