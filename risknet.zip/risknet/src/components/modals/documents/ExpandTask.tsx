import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WrappedSelect } from "@/components/ui/select";
import { toast } from "sonner";
import {
  requestSubmitExpandTask,
  requestExpandTaskConfig,
  requestResumeExpandTask,
} from "@/request/document";
import ModalService from "@/helpers/modal";

interface ExpandTaskModalProps {
  parserId: string;
  onClose: () => void;
  onSubmit: () => void;
}

export const ExpandTaskModal = ({
  parserId,
  onClose,
  onSubmit,
}: ExpandTaskModalProps) => {
  const [nodeType, setNodeType] = useState<string>("");
  const [modelName, setModelName] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  // 选项数据
  const [nodeTypeOptions, setNodeTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);
  const [modelOptions, setModelOptions] = useState<
    { label: string; value: string }[]
  >([]);

  // 获取配置选项
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const response = await requestExpandTaskConfig();

        if (response?.data) {
          // 处理节点类型选项
          if (response.data.nodeTypes) {
            const options = Object.entries(response.data.nodeTypes).map(
              ([key, value]) => ({
                value: key,
                label: value as string,
              })
            );
            setNodeTypeOptions(options);
            if (options.length > 0) {
              setNodeType(options[0].value);
            }
          }

          // 处理模型选项
          if (response.data.languageModels) {
            const options = Object.entries(response.data.languageModels).map(
              ([key, value]) => ({
                value: key,
                label: value as string,
              })
            );
            setModelOptions(options);
            if (options.length > 0) {
              setModelName(options[0].value);
            }
          }
        }
      } catch (error) {
        console.error("获取扩展任务配置失败", error);
        toast.error("获取配置失败");
      }
    };

    fetchConfig();
  }, []);

  const handleSubmit = async () => {
    if (!nodeType) {
      toast.error("请选择节点类型");
      return;
    }

    setLoading(true);
    try {
      const response = await requestSubmitExpandTask({
        parserId,
        nodeType,
        modelName,
        batchSize: 5, // 默认批次大小
      });

      if (response) {
        toast.success("扩展任务提交成功");
        onSubmit();
        onClose();
      }
    } catch (error: any) {
      toast.error(error.message || "提交扩展任务失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm font-semibold text-primary/80 -mt-4">
        提交扩展任务
      </h2>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            解析任务ID
          </label>
          <Input value={parserId} disabled className="bg-gray-100" />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            节点类型
          </label>
          <WrappedSelect
            value={nodeType}
            options={nodeTypeOptions}
            onChange={setNodeType}
            className="w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            模型名称
          </label>
          <WrappedSelect
            value={modelName}
            options={modelOptions}
            onChange={setModelName}
            className="w-full"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-2">
        <Button variant="outline" onClick={onClose}>
          取消
        </Button>
        <Button onClick={handleSubmit} disabled={loading}>
          {loading ? "提交中..." : "提交"}
        </Button>
      </div>
    </div>
  );
};

export const ExpandTaskResumeModal = ({
  expandTaskId,
  onClose,
  onSubmit,
}: {
  expandTaskId: string;
  onClose: () => void;
  onSubmit: () => void;
}) => {
  const [modelName, setModelName] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const [modelOptions, setModelOptions] = useState<
    { label: string; value: string }[]
  >([]);

  // 获取配置选项
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const response = await requestExpandTaskConfig();

        if (response?.data) {
          // 处理模型选项
          if (response.data.languageModels) {
            const options = Object.entries(response.data.languageModels).map(
              ([key, value]) => ({
                value: key,
                label: value as string,
              })
            );
            setModelOptions(options);
            if (options.length > 0) {
              setModelName(options[0].value);
            }
          }
        }
      } catch (error) {
        console.error("获取扩展任务配置失败", error);
        toast.error("获取配置失败");
      }
    };

    fetchConfig();
  }, []);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const response = await requestResumeExpandTask({
        id: expandTaskId,
        modelName,
      });

      if (response) {
        toast.success("扩展任务恢复成功");
        onSubmit();
        onClose();
      }
    } catch (error: any) {
      toast.error(error.message || "恢复扩展任务失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-sm font-semibold text-primary/80 -mt-4">
        恢复扩展任务
      </h2>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            扩展任务ID
          </label>
          <Input value={expandTaskId} disabled className="bg-gray-100" />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            模型名称
          </label>
          <WrappedSelect
            value={modelName}
            options={modelOptions}
            onChange={setModelName}
            className="w-full"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-2">
        <Button variant="outline" onClick={onClose}>
          取消
        </Button>
        <Button onClick={handleSubmit} disabled={loading}>
          {loading ? "恢复中..." : "恢复"}
        </Button>
      </div>
    </div>
  );
};

export const showParseTaskExpandModal = (parserId: string) => {
  ModalService.showModal({
    maxWidth: "md",
    content: (closeModal) => (
      <ExpandTaskModal
        parserId={parserId}
        onClose={closeModal}
        onSubmit={() => {}}
      />
    ),
  });
};

export const showExpandTaskResumeModal = (
  expandTaskId: string,
  callback: () => void
) => {
  ModalService.showModal({
    maxWidth: "md",
    content: (closeModal) => (
      <ExpandTaskResumeModal
        expandTaskId={expandTaskId}
        onClose={closeModal}
        onSubmit={callback}
      />
    ),
  });
};
