import React, { useState, useEffect, useCallback } from "react";
import { toast } from "sonner";
import ModalService from "@/helpers/modal";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { WrappedSelect } from "@/components/ui/select";
import { type SnInspectionNodeVO } from "@/types/inspect";
import {
  requestAuditInspectionNode,
  requestExportNodeRelations,
} from "@/request/inspect";

interface InspectionNodeProps {
  taskId: string;
  node: SnInspectionNodeVO;
  onClose: () => void;
}

const exportTypeOptions = [
  {
    label: "全部节点",
    value: "exportAll",
  },
  {
    label: "正确节点",
    value: "exportCorrect",
  },
  {
    label: "错误节点",
    value: "exportIncorrect",
  },
  {
    label: "需要调整节点",
    value: "exportNeedAdjustment",
  },
];

const InspectionNode = ({ taskId, node, onClose }: InspectionNodeProps) => {
  const [status, setStatus] = useState<string | null>(node.auditStatus || null);
  const [auditSuggestion, setAuditSuggestion] = useState<string>(
    node.auditSuggestion || ""
  );
  const [exportType, setExportType] = useState<string>("exportAll");

  const handleSubmit = async () => {
    if (!status) {
      toast.error("请选择状态");
      return;
    }

    try {
      await requestAuditInspectionNode({
        inspection_node_id: node.id!,
        auditStatus: status,
        auditSuggestion: auditSuggestion,
      });

      onClose();
      toast.success("提交成功");
    } catch (error) {
      toast.error("提交失败");
    }
  };

  const handleExport = async () => {
    try {
      const response = await requestExportNodeRelations(taskId, exportType);

      const blob =
        response instanceof Blob
          ? response
          : new Blob([response.data || response]);

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", node.sname! + ".xlsx");
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("下载文档失败", error);
    }
  };

  return (
    <div className="flex flex-col items-stretch space-y-2">
      <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg s space-y-1">
        <h5 className="text-md font-medium">基本信息</h5>
        <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">节点ID</span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.sid}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">节点名称</span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.sname}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">节点类型</span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.snodeType}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">节点代码</span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.scode}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">节点级别</span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.slevel}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="w-20 flex-shrink-0 text-sm text-gray-400">
            节点说明
          </span>
          <span className="text-sm text-gray-500 font-semibold">
            {node.sdescription}
          </span>
        </div>
        {/* <div className="flex items-center gap-4">
          <span className="w-20 text-sm text-gray-400">创建时间</span>
          <span className="text-sm text-gray-500 font-semibold">{node.}</span>
        </div> */}
      </div>
      <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg space-y-1">
        <h5 className="text-md font-medium">关系信息</h5>
        {node.srelationships?.map((item, index) => {
          return (
            <div
              key={index}
              className="border-b border-gray-200 pb-2 last:border-b-0"
            >
              <div className="flex items-center gap-4">
                <span className="w-20 text-sm text-gray-400">关联实体</span>
                <span className="text-sm text-gray-500 font-semibold">
                  {item.targetNodeName}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <span className="w-20 text-sm text-gray-400">关系类型</span>
                <span className="text-sm text-gray-500 font-semibold">
                  {item.relationType}
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="p-3 bg-white border border-gray-200 rounded-lg space-y-1">
        <h5 className="text-md font-medium">审核操作</h5>
        <div className="flex items-center gap-4 mt-4">
          <span className="w-20 text-sm text-gray-400">状态</span>
          <span className="text-sm text-gray-500 font-semibold">
            {/* radio: 正确、错误、需要调整*/}
            <RadioGroup
              value={status}
              className="flex space-x-2"
              onValueChange={(value) => setStatus(value)}
            >
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="correct" id="correct" />
                <Label htmlFor="correct">正确</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="incorrect" id="incorrect" />
                <Label htmlFor="incorrect">错误</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="need_adjustment" id="need_adjustment" />
                <Label htmlFor="need_adjustment">需要调整</Label>
              </div>
            </RadioGroup>
          </span>
        </div>
        <div className="flex items-center gap-4 mt-4">
          <span className="w-20 text-sm text-gray-400">调整建议</span>
          <Input
            className="flex-1 mr-4"
            value={auditSuggestion}
            placeholder="请输入调整建议"
            onChange={(e) => setAuditSuggestion(e.target.value)}
          />
        </div>
      </div>
      <div className="flex items-center justify-center gap-4">
        <Button onClick={handleSubmit}>提交反馈</Button>
        <Button variant="outline" onClick={onClose}>
          关闭
        </Button>
      </div>
    </div>
  );
};

export const showInspecNodeModal = (
  taskId: string,
  node: SnInspectionNodeVO,
  onClose: () => void
) => {
  ModalService.showModal({
    title: "节点详情",
    maxWidth: "xl",
    content: (closeModal) => (
      <InspectionNode
        taskId={taskId}
        node={node}
        onClose={() => {
          onClose();
          closeModal();
        }}
      />
    ),
  });
};

export default InspectionNode;
