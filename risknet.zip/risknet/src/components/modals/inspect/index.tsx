import React, { useState, useEffect, useCallback } from "react";
import ModalService from "@/helpers/modal";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { WrappedSelect } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { requestExpandTaskConfig } from "@/request/document";
import { listVersions } from "@/request/version";
import { requestSubmitInspectionTask } from "@/request/inspect";
import type { SnVersionVO } from "@/types/version";
import type { SnInspectionTaskSubmitQuery, RString } from "@/types/inspect";
import { toast } from "sonner";

// Local SelectOption interface
interface SelectOption {
  label: string;
  value: string;
}

interface NewInspectTaskModalProps {
  onClose?: () => void;
  onSubmit?: (taskId?: string) => void;
}

const NewInspectTaskModal: React.FC<NewInspectTaskModalProps> = ({
  onClose,
  onSubmit,
}) => {
  const [inspectionMethod, setInspectionMethod] = useState<string>("random");
  const [keyword, setKeyword] = useState<string>("");
  const [entityType, setEntityType] = useState<string>("");
  const [version, setVersion] = useState<string>("");
  const [count, setCount] = useState<number>(50);
  const [nodeTypeOptions, setNodeTypeOptions] = useState<SelectOption[]>([]);
  const [versionOptions, setVersionOptions] = useState<SelectOption[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const inspectionMethodOptions: SelectOption[] = [
    { label: "随机抽检", value: "random" },
    { label: "精确匹配", value: "exact" },
    { label: "模糊匹配", value: "fuzzy" },
  ];

  // 获取节点类型选项
  const fetchNodeTypeOptions = useCallback(async () => {
    try {
      const response = await requestExpandTaskConfig();

      if (response?.data.nodeTypes) {
        const options = Object.entries(response.data.nodeTypes).map(
          ([key, value]) => ({
            value: key,
            label: value,
          })
        );

        console.log(options);
        setNodeTypeOptions([{ value: "0", label: "全部类型" }, ...options]);
      }
    } catch (error) {
      console.error("获取节点类型选项失败", error);
    }
  }, []);

  const fetchVersions = useCallback(async () => {
    try {
      const wrappedResponse = await listVersions();
      const versionPayload = wrappedResponse.data;

      console.log(wrappedResponse);

      if (Array.isArray(versionPayload)) {
        const fetchedVersions: SnVersionVO[] = versionPayload;

        setVersion(fetchedVersions[0].version!);
        setVersionOptions(
          fetchedVersions.map((v) => ({
            label: v.version!,
            value: v.version!,
          }))
        );
      }
    } catch (error) {
      console.error("获取版本列表失败", error);
    }
  }, []);

  useEffect(() => {
    fetchNodeTypeOptions();
    fetchVersions();
  }, []);

  const handleSubmit = async () => {
    if (
      (inspectionMethod === "exact" || inspectionMethod === "fuzzy") &&
      !keyword.trim()
    ) {
      toast.error("关键词匹配模式下，请输入关键词");
      return;
    }
    if (!entityType) {
      toast.error("请选择实体类型");
      return;
    }
    if (!version) {
      toast.error("请选择版本");
      return;
    }
    if (count <= 0 || count > 100) {
      toast.error("抽检数量必须在 1 到 100 之间");
      return;
    }

    setIsSubmitting(true);

    const payload: SnInspectionTaskSubmitQuery = {
      method: inspectionMethod,
      nodeType: entityType,
      version: version,
      count: count,
    };

    if (inspectionMethod === "keyword") {
      payload.keyword = keyword;
    }

    try {
      const response = await requestSubmitInspectionTask(payload);

      if (response && response.code === "00000") {
        toast.success(response.message || "抽检任务创建成功");
        const taskId = response.data;
        onSubmit?.(taskId);
        onClose?.();
      } else {
        toast.error(response.message || "抽检任务创建失败");
      }
    } catch (error: any) {
      toast.error(error.message || "提交抽检任务失败");
      console.error("提交抽检任务失败", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  console.log(versionOptions);

  return (
    <div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            抽检方式:
          </label>
          <RadioGroup
            value={inspectionMethod}
            onValueChange={(val) => setInspectionMethod(val)}
            className="flex space-x-2"
          >
            {inspectionMethodOptions.map((option) => (
              <div key={option.value} className="flex items-center space-x-1">
                <RadioGroupItem value={option.value} id={option.value} />
                <Label htmlFor={option.value}>{option.label}</Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        {(inspectionMethod === "exact" || inspectionMethod === "fuzzy") && (
          <div>
            <label
              htmlFor="keyword"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              关键词:
            </label>
            <Input
              id="keyword"
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="请输入关键词"
            />
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            实体类型:
          </label>
          <WrappedSelect
            options={nodeTypeOptions}
            value={entityType}
            className="w-full"
            onChange={(val) => setEntityType(val as string)}
          />
        </div>

        <div className="flex gap-4">
          <div className="flex flex-col items-stretch flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              版本:
            </label>
            <WrappedSelect
              options={versionOptions}
              value={version}
              className="w-full"
              onChange={(val) => setVersion(val as string)}
            />
          </div>
          <div className="flex flex-col items-stretch w-32">
            <label
              htmlFor="count"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              抽检数量:
            </label>
            <Input
              id="count"
              type="number"
              value={count}
              onChange={(e) => {
                const num = parseInt(e.target.value, 10);
                setCount(isNaN(num) ? 0 : num);
              }}
              placeholder="1-100"
              min="1"
              max="100"
            />
          </div>
        </div>
      </div>
      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          取消
        </Button>
        <Button type="submit" onClick={handleSubmit} disabled={isSubmitting}>
          {isSubmitting ? "提交中..." : "提交抽检任务"}
        </Button>
      </div>
    </div>
  );
};

export const showNewInspectTaskModal = (
  onSubmit: (taskId?: string) => void
) => {
  ModalService.showModal({
    title: "创建抽检任务",
    content: (closeModal) => (
      <NewInspectTaskModal onSubmit={onSubmit} onClose={closeModal} />
    ),
  });
};

export default NewInspectTaskModal;
