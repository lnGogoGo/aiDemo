import React, { useState, useEffect } from "react";
import ModalService from "@/helpers/modal";
import { Button } from "@/components/ui/button";
import { requestInspectionNodes } from "@/request/inspect";
import { type SnInspectionNodeVO, AuditStatusLabelMap } from "@/types/inspect";
import { useIntervalWhenVisible } from "@/hooks/base";
import { WrappedTable } from "@/components/ui/table";
import { Pagination } from "@/components/ui/pagination";
import { showInspecNodeModal } from "./Node";
import { showInspecStatModal } from "./Stat";

const InspectionNodes = ({
  id,
  onClose,
}: {
  id: string;
  onClose: () => void;
}) => {
  const [nodes, setNodes] = useState<SnInspectionNodeVO[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);

  const [loading, setLoading] = useState(false);

  const fetchNodes = async (page?: number) => {
    setLoading(true);
    try {
      const response = await requestInspectionNodes({
        inspectionId: id as string,
        current: page || current,
        size: 10,
      });

      if (response.data) {
        setNodes(response.data.records || []);
        setTotal(response.data.total || 0);
      }
    } catch (error) {
      console.error("获取导入任务列表失败", error);
    } finally {
      setLoading(false);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchNodes(page);
  };

  const handleShowStat = () => {
    showInspecStatModal(id, fetchNodes);
  };

  // 搜索
  const handleReload = () => {
    fetchNodes();
  };

  useEffect(() => {
    fetchNodes();
  }, []);

  useIntervalWhenVisible(fetchNodes, 10000);

  return (
    <>
      <div className="relative flex-1 container pt-2">
        <div className="flex gap-2 absolute -top-10 right-0">
          <Button variant="outline" onClick={handleReload}>
            刷新
          </Button>
          <Button variant="outline" onClick={handleShowStat}>
            修复数据
          </Button>
          <Button variant="outline" onClick={onClose}>
            关闭
          </Button>
        </div>
        <div className="border rounded-lg overflow-hidden">
          <WrappedTable
            loading={loading}
            columns={[
              { key: "id", label: "ID" },
              {
                key: "sname",
                label: "节点名称",
                dataRender: (record: SnInspectionNodeVO) => (
                  <div className="flex flex-col">
                    <span>{record.sname}</span>
                    <span className="text-sm text-gray-500">
                      {record.scode}
                    </span>
                  </div>
                ),
              },
              {
                key: "snodeTypeDesc",
                label: "节点类型",
              },
              {
                key: "srelationships",
                label: "关联实体",
                dataRender: (record: SnInspectionNodeVO) => (
                  <div className="flex flex-col whitespace-pre">
                    <span className="text-[11px]">
                      {record.srelationships
                        ?.map((relationship) => relationship.targetNodeName)
                        .join("\n")}
                    </span>
                  </div>
                ),
              },
              {
                key: "auditStatus",
                label: "审核状态",
                dataRender: (record: SnInspectionNodeVO) => (
                  <span>{AuditStatusLabelMap[record.auditStatus!] || "-"}</span>
                ),
              },
              {
                key: "operation",
                label: "操作",
                className: "w-48",
                dataRender: (record: SnInspectionNodeVO) => (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        showInspecNodeModal(id, record, fetchNodes)
                      }
                    >
                      查看
                    </Button>
                  </div>
                ),
              },
            ]}
            data={nodes}
          />
        </div>
        <div className="mt-4 flex justify-end gap-4">
          {total > 0 && (
            <Pagination
              current={current}
              pageSize={10}
              total={total}
              onChange={handlePageChange}
            />
          )}
          <Button variant="outline" onClick={onClose}>
            关闭
          </Button>
        </div>
      </div>
    </>
  );
};
export const showInspecNodesModal = (id: string, onClose: () => void) => {
  ModalService.showModal({
    title: "节点审核",
    isFullScreen: true,
    content: (closeModal) => (
      <InspectionNodes
        id={id}
        onClose={() => {
          onClose();
          closeModal();
        }}
      />
    ),
  });
};

export default InspectionNodes;
