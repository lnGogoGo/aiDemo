import React, { useState, useEffect, useMemo, useCallback } from "react";
import { toast } from "sonner";
import { Pie } from "react-chartjs-2";
import ModalService from "@/helpers/modal";
import { Button } from "@/components/ui/button";
import { WrappedSelect } from "@/components/ui/select";
import { SnInspectionTaskStatsVO } from "@/types/inspect";
import {
  requestExportNodeRelations,
  requestGetInspectionTaskStats,
  requestImportNodeRelations,
  requestApplyNodeFixRelations,
  requestGetNodeFixStatus,
} from "@/request/inspect";
import { pickLocalFile } from "@/lib/utils";

interface InspectionNodeProps {
  taskId: string;
  onClose: () => void;
}

const exportTypeOptions = [
  {
    label: "全部节点",
    value: "exportAll",
  },
  {
    label: "正确节点",
    value: "exportCorrect",
  },
  {
    label: "错误节点",
    value: "exportIncorrect",
  },
  {
    label: "需要调整节点",
    value: "exportNeedAdjustment",
  },
];

const pieOptions = {
  plugins: {
    legend: {
      display: false,
    },
  },
};

const InspectionStat = ({ taskId, onClose }: InspectionNodeProps) => {
  const [statData, setStatData] = useState<SnInspectionTaskStatsVO>({
    count: 0,
    correctCount: 0,
    incorrectCount: 0,
    needAdjustmentCount: 0,
  });
  const [exportType, setExportType] = useState<string>("exportAll");
  const [fixStatus, setFixStatus] = useState<string>("");

  const pieData = useMemo(() => {
    return {
      labels: ["正确", "错误", "需要调整", "未审核"],
      datasets: [
        {
          data: [
            statData.correctCount || 0,
            statData.incorrectCount || 0,
            statData.needAdjustmentCount || 0,
            (statData.count || 0) -
              (statData.correctCount || 0) -
              (statData.incorrectCount || 0) -
              (statData.needAdjustmentCount || 0),
          ],
          backgroundColor: ["#1abc9c", "#e74c3c", "#e67e22", "#dddddd"],
        },
      ],
    };
  }, [statData]);

  const handleExport = async () => {
    try {
      const response = await requestExportNodeRelations(taskId, exportType);

      const blob =
        response instanceof Blob
          ? response
          : new Blob([response.data || response]);

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      const typeName = exportTypeOptions.find(
        (option) => option.value === exportType
      )?.label;

      link.href = url;
      link.setAttribute("download", `${taskId}-${typeName}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error: any) {
      toast.error(error.message || "下载文档失败");
      console.error("下载文档失败", error);
    }
  };

  const handleImportFixData = async () => {
    const file = await pickLocalFile();

    if (file) {
      const response = await requestImportNodeRelations(taskId, file);
      if (response.code === "00000") {
        toast.success("导入修复数据成功");
      } else {
        toast.error(response.message || "导入修复数据失败");
      }
    }
  };

  const handleApplyFixData = async () => {
    try {
      const response = await requestApplyNodeFixRelations(taskId);

      if (response.code === "00000") {
        toast.success("已开始应用修复数据");
        pollingFixStatus();
      } else {
        toast.error(response.message || "应用修复数据失败");
      }
    } catch (error: any) {
      toast.error(error.message || "应用修复数据失败");
      console.error("应用修复数据失败", error);
    }
  };

  const loadStats = useCallback(async () => {
    const response = await requestGetInspectionTaskStats(taskId);
    if (response.data) {
      setStatData(response.data);
    }
  }, []);

  const loadFixStatus = useCallback(async () => {
    const response = await requestGetNodeFixStatus(taskId);
    if (response.code === "00000") {
      setFixStatus(response.data);
      return response.data;
    } else {
      return "-";
    }
  }, []);

  const pollingFixStatus = useCallback(async () => {
    const status = await loadFixStatus();
    if (status === "completed") {
      toast.success("应用修复数据成功");
    } else {
      setTimeout(() => {
        pollingFixStatus();
      }, 10000);
    }
  }, []);

  useEffect(() => {
    loadFixStatus();
    loadStats();
  }, []);

  return (
    <div className="flex flex-col items-stretch space-y-2">
      <div className="flex gap-4 items-stretch">
        <div className="flex flex-col items-center justify-center w-76 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <div className="self-stretch mb-6 grid grid-cols-2 gap-y-2">
            <div className="flex items-center gap-2">
              <div className="size-4 bg-[#dddddd] rounded-xs" />
              <span className="text-sm text-gray-400">抽检节点</span>
              <span className="text-sm text-gray-500 font-semibold">
                {statData.count}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-4 bg-[#1abc9c] rounded-xs" />
              <span className="text-sm text-gray-400">正确</span>
              <span className="text-sm text-gray-500 font-semibold">
                {statData.correctCount}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-4 bg-[#e74c3c] rounded-xs" />
              <span className="text-sm text-gray-400">错误</span>
              <span className="text-sm text-gray-500 font-semibold">
                {statData.incorrectCount}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-4 bg-[#e67e22] rounded-xs" />
              <span className="text-sm text-gray-400">需要调整</span>
              <span className="text-sm text-gray-500 font-semibold">
                {statData.needAdjustmentCount}
              </span>
            </div>
          </div>
          <div className="size-48">
            <Pie data={pieData} options={pieOptions} />
          </div>
        </div>
        <div className="flex flex-col flex-1">
          <div className="grid grid-cols-2 gap-x-2 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <span className="mb-3 col-span-2 text-sm text-gray-400">
              导出数据
            </span>
            <WrappedSelect
              className="w-32 bg-white"
              value={exportType}
              options={exportTypeOptions}
              onChange={(value) => setExportType(value)}
            />
            <Button className="w-32" variant="outline" onClick={handleExport}>
              导出节点数据
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-x-2 flex-1 mt-2 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <span className="flex col-span-2 mb-2 text-sm text-gray-400">
              修复数据
            </span>
            <Button variant="outline" onClick={handleImportFixData}>
              导入修复数据
            </Button>
            <Button variant="outline" onClick={handleApplyFixData}>
              应用修复数据
            </Button>
            <div className="flex-1"></div>
            <div className="flex col-span-2 mt-3">
              <span className="text-sm text-gray-400">修复状态：</span>
              <span className="text-sm text-gray-400">{fixStatus || "-"}</span>
            </div>
            <div className="flex col-span-2 mt-3">
              <span className="text-sm text-gray-400">错误信息：</span>
              <span className="text-sm text-gray-400">{"-"}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-end gap-4">
        <Button variant="outline" onClick={onClose}>
          关闭
        </Button>
      </div>
    </div>
  );
};

export const showInspecStatModal = (taskId: string, onClose: () => void) => {
  ModalService.showModal({
    title: "统计信息/数据修复",
    maxWidth: "2xl",
    content: (closeModal) => (
      <InspectionStat
        taskId={taskId}
        onClose={() => {
          onClose();
          closeModal();
        }}
      />
    ),
  });
};

export default InspectionStat;
