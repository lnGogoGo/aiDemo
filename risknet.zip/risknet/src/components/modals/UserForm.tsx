import React, { useState } from "react";
import { FaKey } from "react-icons/fa";
import { UserInfo, UserParams } from "@/types/user";
import { requestCreateUser, requestUpdateUser } from "@/request/user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { WrappedSelect } from "@/components/ui/select";
import ModalService from "@/helpers/modal";

interface UserFormModalProps {
  user?: UserInfo;
  isCreating: boolean;
  onComplete?: () => void;
  onCancel: () => void;
}

const UserFormModal: React.FC<UserFormModalProps> = ({
  user,
  isCreating,
  onComplete,
  onCancel,
}) => {
  const [formData, setFormData] = useState<UserParams>({
    id: user?.id,
    username: user?.username || "",
    realName: user?.realName || "",
    superAdmin: user?.superAdmin || false,
    roleId: user?.roleId || 2,
    password: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;

    if (type === "checkbox") {
      const checkbox = e.target as HTMLInputElement;
      setFormData({ ...formData, [name]: checkbox.checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }

    // Clear error when user types
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.username) {
      newErrors.username = "用户名不能为空";
    }

    if (!formData.realName) {
      newErrors.realName = "真实姓名不能为空";
    }

    if (isCreating && (!formData.password || formData.password.length < 6)) {
      newErrors.password = "密码不能少于6个字符";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);

    try {
      if (isCreating) {
        await requestCreateUser(formData);
      } else {
        await requestUpdateUser(formData);
      }

      onComplete?.();
    } catch (error: any) {
      console.error("Failed to save user:", error);
      setErrors({
        form: error.message || "保存用户失败，请稍后重试",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto">
      <div className="flex flex-col items-stretch gap-5 mb-4">
        {/* 基本信息区域 */}
        <div>
          <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-1">
            用户名
            {errors.username && (
              <span className="mt-1 text-xs text-red-600">
                {errors.username}
              </span>
            )}
          </label>
          <Input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md ${
              errors.username ? "border-red-500" : "border-gray-300"
            }`}
          />
        </div>

        <div>
          <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-1">
            真实姓名
            {errors.realName && (
              <span className="mt-1 text-xs text-red-600">
                {errors.realName}
              </span>
            )}
          </label>
          <Input
            type="text"
            name="realName"
            value={formData.realName}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md ${
              errors.realName ? "border-red-500" : "border-gray-300"
            }`}
          />
        </div>

        <div>
          <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-1">
            用户角色
          </label>
          <WrappedSelect
            options={[
              { value: "1", label: "管理员" },
              { value: "2", label: "普通用户" },
            ]}
            value={formData.roleId.toString()}
            className="w-full"
            onChange={(value) =>
              setFormData({ ...formData, roleId: parseInt(value) })
            }
          />
        </div>

        {isCreating && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              初始密码
            </label>
            <div className="relative rounded-md ">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FaKey className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="最少6个字符"
                className={`w-full pl-10 pr-3 py-2 border rounded-md ${
                  errors.password ? "border-red-500" : "border-gray-300"
                }`}
              />
            </div>
            {errors.password && (
              <p className="mt-1 text-sm text-red-500">{errors.password}</p>
            )}
          </div>
        )}
      </div>

      {errors.form && (
        <div className="mb-2 bg-red-50 border-l-4 border-red-500 text-red-700 p-3 rounded-md">
          {errors.form}
        </div>
      )}

      <div className="flex justify-end gap-2">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          取消
        </Button>
        <Button onClick={handleSubmit} disabled={loading}>
          {loading ? "保存中..." : "保存"}
        </Button>
      </div>
    </div>
  );
};

export const showCreateUserModal = (onComplete?: () => void) => {
  ModalService.showModal({
    maxWidth: "xs",
    content: (closeModal) => (
      <UserFormModal
        isCreating={true}
        onComplete={onComplete}
        onCancel={closeModal}
      />
    ),
  });
};

export const showEditUserModal = (user: UserInfo, onComplete?: () => void) => {
  ModalService.showModal({
    maxWidth: "xs",
    content: (closeModal) => (
      <UserFormModal
        user={user}
        isCreating={false}
        onComplete={onComplete}
        onCancel={closeModal}
      />
    ),
  });
};
