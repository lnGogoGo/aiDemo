import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import ModalService from "@/helpers/modal";
import { WrappedSelect } from "@/components/ui/select";
import { toast } from "sonner";
import {
  requestImportTaskConfig,
  requestSubmitImportTask,
} from "@/request/document";
import { ParseTaskSelect, ExtendTaskSelect } from "@/components/ui/task-select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { DocumentParseTask, ParseExpandTask } from "@/types";

interface NetworkInitBaseProps {
  onClose: () => void;
  onSubmit?: () => void;
}

type NetworkInitProps = NetworkInitBaseProps &
  (
    | { initialTaskType?: "parse"; initialTaskData?: DocumentParseTask }
    | { initialTaskType?: "extend"; initialTaskData?: ParseExpandTask }
  );

const taskTypeOptions = [
  { label: "解析任务", value: "parse" },
  { label: "扩展任务", value: "extend" },
];

// Helper to get display name for the initial task
const getInitialTaskDisplayName = (
  taskType?: "parse" | "extend",
  taskData?: DocumentParseTask | ParseExpandTask
): string => {
  if (!taskData) return "未提供任务";
  if (taskType === "parse") {
    return (
      (taskData as DocumentParseTask)?.docFileName ||
      (taskData as DocumentParseTask)?.id ||
      "解析任务"
    );
  }
  if (taskType === "extend") {
    // Assuming ExpandTaskConfigVO (or the actual task data type for extend) has a 'name' or 'id'
    // This might need adjustment based on the actual structure of extend task data
    return (taskData as any)?.name || (taskData as any)?.id || "扩展任务";
  }
  return "未知任务";
};

export function NetworkInitModal({
  initialTaskType,
  initialTaskData,
  onClose,
  onSubmit,
}: NetworkInitProps) {
  const [taskType, setTaskType] = useState<string>("parse");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [sourceId, setSourceId] = useState<string>("");
  const [nodeType, setNodeType] = useState<string>("");
  const [sourceType, setSourceType] = useState<string>("");
  const [sourceName, setSourceName] = useState<string>("");

  // 配置选项
  const [nodeTypeOptions, setNodeTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);
  const [sourceTypeOptions, setSourceTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);

  // 获取配置选项
  const fetchConfigOptions = async () => {
    try {
      const response = await requestImportTaskConfig();

      if (response?.data) {
        // 节点类型选项
        if (response.data.nodeTypes) {
          const options = Object.entries(response.data.nodeTypes).map(
            ([key, value]) => ({
              value: key,
              label: value,
            })
          );
          setNodeTypeOptions(options);
        }

        // 来源类型选项
        if (response.data.sourceTypes) {
          const options = Object.entries(response.data.sourceTypes).map(
            ([key, value]) => ({
              value: key,
              label: value,
            })
          );
          setSourceTypeOptions(options);
        }
      }
    } catch (error) {
      console.error("获取配置选项失败", error);
      toast.error("获取配置选项失败");
    }
  };

  const handleSelectTaskType = (value: string) => {
    setTaskType(value);
    setSourceId("");
    setNodeType("");
    setSourceType("");
    setSourceName("");
  };

  useEffect(() => {
    fetchConfigOptions();
  }, []);

  useEffect(() => {
    if (initialTaskType && initialTaskData) {
      setTaskType(initialTaskType);

      if (
        initialTaskType === "parse" &&
        (initialTaskData as DocumentParseTask)?.id
      ) {
        setSourceId((initialTaskData as DocumentParseTask).id!);
        setSourceType((initialTaskData as DocumentParseTask).sourceType!);
        setSourceName((initialTaskData as DocumentParseTask).sourceName!);
      } else if (
        initialTaskType === "extend" &&
        (initialTaskData as any)?.id
      ) {
        // Assuming the extend task data has an 'id'
        setSourceId((initialTaskData as any).id!);
        setSourceType("llm_expansion");
        setSourceName((initialTaskData as any).modelName!);
      }
      // Potentially set sourceName if it's part of initialTaskData and shouldn't be user-editable
      // For example: if (initialTaskData.name) setSourceName(initialTaskData.name);
    }
  }, [initialTaskType, initialTaskData]);

  const handleSubmit = async () => {
    console.log(
      "taskType",
      taskType,
      sourceId,
      nodeType,
      sourceType,
      sourceName
    );
    if (taskType === "parse") {
      if (!sourceId) {
        toast.error("请选择解析任务");
        return;
      }
    }

    if (taskType === "extend") {
      if (!sourceId) {
        toast.error("请选择扩展任务");
        return;
      }
    }

    if (!nodeType) {
      toast.error("请选择节点类型");
      return;
    }

    if (!sourceType) {
      toast.error("请选择数据来源类型");
      return;
    }

    if (!sourceName) {
      toast.error("请输入数据来源名称");
      return;
    }

    setIsLoading(true);

    try {
      const response = await requestSubmitImportTask({
        type: taskType === "parse" ? 1 : 2,
        sourceId: sourceId,
        nodeType,
        sourceType,
        sourceName,
      });

      if (response.data) {
        toast.success("导入任务提交成功");
        onSubmit?.();
        onClose();
      }
    } catch (error) {
      console.error("提交导入任务失败", error);
      toast.error("提交导入任务失败");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {!initialTaskType && (
        <div className="mt-2">
          <Label className="mb-3">任务类型</Label>
          <RadioGroup
            value={taskType}
            onValueChange={handleSelectTaskType}
            className="mt-1 flex space-x-4"
          >
            {taskTypeOptions.map((option) => (
              <div key={option.value} className="flex items-center space-x-2">
                <RadioGroupItem
                  value={option.value}
                  id={`taskType-${option.value}`}
                />
                <Label htmlFor={`taskType-${option.value}`}>
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      )}

      {initialTaskType && initialTaskData && (
        <div className="flex items-center gap-2 mt-2 p-3.5 border rounded-lg bg-gray-50">
          <Label className="text-sm">
            导入{initialTaskType === "parse" ? "解析任务" : "扩展任务"}:
          </Label>
          <p className="text-sm font-medium">{initialTaskData.id}</p>
        </div>
      )}

      {!initialTaskData && taskType === "parse" && (
        <div>
          <Label className="mb-1" htmlFor="parserId">
            解析任务
          </Label>
          <ParseTaskSelect
            value={sourceId}
            onChange={(value, data) => {
              setSourceId(value);
              setSourceType(data?.task?.sourceType || "");
              setSourceName(data?.task?.sourceName || "");
            }}
            className="mt-1"
          />
        </div>
      )}

      {!initialTaskData && taskType === "extend" && (
        <div>
          <Label className="mb-1" htmlFor="parserId">
            扩展任务
          </Label>
          <ExtendTaskSelect
            value={sourceId}
            onChange={(value, data) => {
              setSourceId(value);
              setSourceType("llm_expansion");
              setSourceName(data?.task?.modelName || "");
            }}
            className="mt-1"
          />
        </div>
      )}

      <div>
        <Label className="mb-1" htmlFor="nodeType">
          节点类型
        </Label>
        <WrappedSelect
          // id="nodeType"
          value={nodeType}
          options={nodeTypeOptions}
          onChange={setNodeType}
          className="mt-1 w-full"
          // placeholder="请选择节点类型"
          // required
        />
      </div>

      <div>
        <Label className="mb-1" htmlFor="sourceType">
          数据来源类型
        </Label>
        <WrappedSelect
          // id="sourceType"
          disabled={taskType === "extend"}
          value={sourceType}
          options={sourceTypeOptions}
          onChange={setSourceType}
          className="mt-1 w-full"
          // placeholder="请选择数据来源类型"
          // required
        />
      </div>

      <div>
        <Label className="mb-1" htmlFor="sourceName">
          数据来源名称
        </Label>
        <Input
          id="sourceName"
          value={sourceName}
          onChange={(e) => setSourceName(e.target.value)}
          placeholder="请输入数据来源名称"
          className="mt-1"
          required
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          取消
        </Button>
        <Button type="submit" onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? "提交中..." : "提交导入任务"}
        </Button>
      </div>
    </div>
  );
}

export const showNetworkImportModal = (
  props?: NetworkInitBaseProps &
    (
      | { initialTaskType?: "parse"; initialTaskData?: DocumentParseTask }
      | { initialTaskType?: "extend"; initialTaskData?: ParseExpandTask }
    )
) => {
  ModalService.showModal({
    title: "初始化语义网络",
    content: (closeModal) => (
      <NetworkInitModal
        {...props}
        onClose={closeModal}
        onSubmit={props?.onSubmit || (() => {})}
      />
    ),
  });
};
