"use client";

import { ReactNode } from "react";
import { ConfigProvider } from "antd";
import locale from "antd/es/locale/zh_CN";

interface PageLayoutProps {
  title: string;
  children: ReactNode;
}

const PageLayout: React.FC<PageLayoutProps> = ({ title, children }) => {
  return (
    <ConfigProvider locale={locale}>
      <div className="container mx-auto p-4">
        <h1 className="mb-4 text-lg font-medium text-gray-900">{title}</h1>
        {children}
      </div>
    </ConfigProvider>
  );
};

export default PageLayout; 