"use client";

import React, { ReactNode } from "react";
import { Form, Row, Col, Button, Space } from "antd";
import { FormInstance } from "antd/es/form";

interface FormFieldConfig {
  name: string;
  label: string;
  component: ReactNode;
  span?: number;
}

interface SearchFormProps {
  form: FormInstance;
  fields: FormFieldConfig[];
  onSearch: () => void;
  onReset: () => void;
}

const SearchForm: React.FC<SearchFormProps> = ({
  form,
  fields,
  onSearch,
  onReset,
}) => {
  return (
    <Form colon={false} form={form} onFinish={onSearch} className="mb-4">
      <Row gutter={24}>
        {fields.map((field) => (
          <Col key={field.name} span={field.span || 6}>
            <Form.Item  name={field.name} label={field.label}>
              {field.component}
            </Form.Item>
          </Col>
        ))}
        <Col span={6}>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button onClick={onReset}>重置</Button>
            </Space>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

export default SearchForm; 