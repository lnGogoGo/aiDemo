"use client";

import React from "react";
import { Button, Space } from "antd";

interface Action {
  key: string;
  text: string;
  onClick: (record: any) => void;
  danger?: boolean;
  disabled?: boolean;
}

interface TableActionsProps {
  record: any;
  actions: Action[];
}

const TableActions: React.FC<TableActionsProps> = ({ record, actions }) => {
  return (
    <Space size="middle">
      {actions.map((action) => (
        <Button
          key={action.key}
          type="link"
          size="small"
          danger={action.danger}
          disabled={action.disabled}
          onClick={() => action.onClick(record)}
        >
          {action.text}
        </Button>
      ))}
    </Space>
  );
};

export default TableActions; 