"use client";

import React from "react";
import { Drawer, Button, Space } from "antd";
import dayjs from "dayjs";

export interface DetailItem {
  label: string;
  key: string;
  render?: (value: any) => React.ReactNode;
}

interface DetailDrawerProps {
  open: boolean;
  onClose: () => void;
  title: string;
  data: Record<string, any> | null;
  items: DetailItem[];
  width?: number;
  onStatusChange?: (record: any, checked: boolean) => Promise<void>;
  hasActiveKey?: string;
}

export const formatDate = (date: string | Date | undefined) => {
  return date ? dayjs(date).format("YYYY-MM-DD HH:mm:ss") : "-";
};

const DetailDrawer: React.FC<DetailDrawerProps> = ({
  open,
  onClose,
  title,
  data,
  items,
  width = 700,
  onStatusChange,
  hasActiveKey = "hasActive",
}) => {
  if (!data) return null;

  const handleStatusToggle = async () => {
    if (onStatusChange && data) {
      await onStatusChange(data, !data[hasActiveKey]);
    }
  };

  return (
    <Drawer
      title={title}
      open={open}
      onClose={onClose}
      width={width}
      footer={
        <div style={{ textAlign: "right" }}>
          <Space>
            {onStatusChange && (
              <Button
                onClick={handleStatusToggle}
                type={data[hasActiveKey] ? "default" : "primary"}
              >
                {data[hasActiveKey] ? "禁用" : "启用"}
              </Button>
            )}
            <Button onClick={onClose} type="primary">
              关闭
            </Button>
          </Space>
        </div>
      }
    >
      <div className="grid grid-cols-24 gap-y-4">
        {items.map((item) => (
          <React.Fragment key={item.key}>
            <div className="col-span-4 text-gray-500">{item.label}：</div>
            <div className="col-span-20">
              {item.render ? item.render(data[item.key]) : data[item.key] || "-"}
            </div>
          </React.Fragment>
        ))}
      </div>
    </Drawer>
  );
};

export default DetailDrawer; 