"use client";

import React, { ReactNode } from "react";
import { Button, Space } from "antd";
import { PlusOutlined, ImportOutlined, ReloadOutlined } from "@ant-design/icons";

interface ButtonConfig {
  key: string;
  text: string;
  icon?: ReactNode;
  onClick: () => void;
  type?: "primary" | "default" | "dashed" | "link" | "text";
}

interface ToolbarButtonsProps {
  buttons: ButtonConfig[];
}

const ToolbarButtons: React.FC<ToolbarButtonsProps> = ({ buttons }) => {
  return (
    <div className="mb-4">
      <Space>
        {buttons.map((button) => (
          <Button
            key={button.key}
            type={button.type || "default"}
            icon={button.icon}
            onClick={button.onClick}
          >
            {button.text}
          </Button>
        ))}
      </Space>
    </div>
  );
};

// 预定义常用按钮配置
export const createAddButton = (onClick: () => void, text = "新增") => ({
  key: "add",
  text,
  icon: <PlusOutlined />,
  onClick,
  type: "primary" as const,
});

export const createImportButton = (onClick: () => void) => ({
  key: "import",
  text: "导入",
  icon: <ImportOutlined />,
  onClick,
});

export const createRefreshButton = (onClick: () => void) => ({
  key: "refresh",
  text: "刷新",
  icon: <ReloadOutlined />,
  onClick,
});

export default ToolbarButtons; 