"use client";

import React, { ReactNode } from "react";
import { FormInstance } from "antd/es/form";
import dayjs from "dayjs";
import "dayjs/locale/zh-cn";
import PageLayout from "./PageLayout";
import SearchForm from "./SearchForm";
import ToolbarButtons from "./ToolbarButtons";
import TableWithPagination from "./TableWithPagination";

// 设置dayjs中文语言环境
dayjs.locale("zh-cn");

interface PageContainerProps {
  title: string;
  form?: FormInstance;
  formFields?: any[];
  onSearch?: () => void;
  onReset?: () => void;
  toolbarButtons?: any[];
  columns: any[];
  data: any[];
  loading: boolean;
  current: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  children?: ReactNode;
}

const PageContainer: React.FC<PageContainerProps> = ({
  title,
  form,
  formFields,
  onSearch,
  onReset,
  toolbarButtons,
  columns,
  data,
  loading,
  current,
  pageSize,
  total,
  onPageChange,
  children,
}) => {
  return (
    <PageLayout title={title}>
      {form && formFields && onSearch && onReset && (
        <SearchForm
          form={form}
          fields={formFields}
          onSearch={onSearch}
          onReset={onReset}
        />
      )}

      {toolbarButtons && <ToolbarButtons buttons={toolbarButtons} />}

      <TableWithPagination
        columns={columns}
        data={data}
        loading={loading}
        current={current}
        pageSize={pageSize}
        total={total}
        onChange={onPageChange}
      />

      {children}
    </PageLayout>
  );
};

export default PageContainer; 