"use client";

import React from "react";
import { WrappedTable } from "@/components/ui/table";
import { Pagination } from "@/components/ui/pagination";

interface TableWithPaginationProps {
  columns: any[];
  data: any[];
  loading: boolean;
  current: number;
  pageSize: number;
  total: number;
  onChange: (page: number) => void;
}

const TableWithPagination: React.FC<TableWithPaginationProps> = ({
  columns,
  data,
  loading,
  current,
  pageSize,
  total,
  onChange,
}) => {
  return (
    <>
      <WrappedTable columns={columns} data={data} loading={loading} />
      <div className="mt-4 flex justify-end">
        <Pagination
          current={current}
          pageSize={pageSize}
          total={total}
          onChange={onChange}
        />
      </div>
    </>
  );
};

export default TableWithPagination; 