"use client";

import React from "react";

interface StatusDotProps {
  active: boolean;
  activeText?: string;
  inactiveText?: string;
}

const StatusDot: React.FC<StatusDotProps> = ({
  active,
  activeText = "已生效",
  inactiveText = "未生效",
}) => {
  return (
    <div className="flex items-center gap-[7px]">
      <div
        className={`w-[6px] h-[6px] rounded-full ${
          active ? "bg-[#2C68FF]" : "bg-[#BFBFBF]"
        }`}
      ></div>
      <span>{active ? activeText : inactiveText}</span>
    </div>
  );
};

export default StatusDot; 