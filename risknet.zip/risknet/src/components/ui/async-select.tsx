import React, { useState, useEffect, useCallback, useRef } from "react";
import { Check, ChevronsUpDown, Loader2, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { debounce } from "lodash";

export interface AsyncSelectOption {
  value: string;
  label: string;
  [key: string]: any; // 允许额外的属性
}

interface AsyncSelectProps {
  value: string;
  onChange: (value: string, option?: AsyncSelectOption) => void;
  loadOptions: (searchText: string) => Promise<AsyncSelectOption[]>;
  placeholder?: string;
  emptyMessage?: string;
  className?: string;
  disabled?: boolean;
  renderOption?: (option: AsyncSelectOption) => React.ReactNode;
  debounceTime?: number;
  triggerSearchLength?: number;
  initialOptions?: AsyncSelectOption[];
  searchOnEnter?: boolean; // 新增属性：是否在回车时触发搜索
}

export function AsyncSelect({
  value,
  onChange,
  loadOptions,
  placeholder = "选择选项...",
  emptyMessage = "没有找到匹配项",
  className,
  disabled = false,
  renderOption,
  debounceTime = 300,
  triggerSearchLength = 1,
  initialOptions = [],
  searchOnEnter = false, // 默认为false，保持向后兼容
}: AsyncSelectProps) {
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState<AsyncSelectOption[]>(initialOptions);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [selectedOption, setSelectedOption] = useState<
    AsyncSelectOption | undefined
  >(initialOptions.find((option) => option.value === value));

  // 添加一个ref来跟踪是否已经尝试加载过初始选项
  const initialLoadAttemptedRef = useRef(false);

  // 执行搜索的函数
  const executeSearch = useCallback(
    async (text: string) => {
      if (text.length < triggerSearchLength) {
        setOptions(initialOptions);
        return;
      }

      setLoading(true);
      try {
        const results = await loadOptions(text);
        setOptions(results);
      } catch (error) {
        console.error("Failed to load options:", error);
        setOptions([]);
      } finally {
        setLoading(false);
      }
    },
    [loadOptions, initialOptions, triggerSearchLength]
  );

  // 使用debounce来减少请求次数
  const debouncedSearch = useCallback(debounce(executeSearch, debounceTime), [
    executeSearch,
    debounceTime,
  ]);

  // 当搜索文本变化时，如果不是回车触发搜索模式，则自动触发搜索
  useEffect(() => {
    if (!searchOnEnter) {
      debouncedSearch(searchText);
    }

    return () => {
      debouncedSearch.cancel();
    };
  }, [searchText, debouncedSearch, searchOnEnter]);

  // 处理键盘事件，支持回车触发搜索
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (searchOnEnter && e.key === "Enter") {
      e.preventDefault();
      executeSearch(searchText);
    }
  };

  // 当下拉框打开时，如果没有搜索文本且没有选项，加载初始选项
  useEffect(() => {
    if (
      open &&
      options.length === 0 &&
      !searchText &&
      !initialLoadAttemptedRef.current
    ) {
      initialLoadAttemptedRef.current = true; // 标记已经尝试加载
      setLoading(true);

      loadOptions("")
        .then((results) => {
          setOptions(results);
          setLoading(false);
        })
        .catch((error) => {
          console.error("Failed to load initial options:", error);
          setLoading(false);
        });
    }
  }, [open, options.length, searchText, loadOptions]);

  // 当下拉框关闭时，重置初始加载标记
  useEffect(() => {
    if (!open) {
      initialLoadAttemptedRef.current = false;
    }
  }, [open]);

  const handleSelect = (currentValue: string) => {
    const option = options.find((opt) => opt.value === currentValue);
    setSelectedOption(option);
    onChange(currentValue, option);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "w-full justify-between",
            !value && "text-muted-foreground",
            className
          )}
          disabled={disabled}
        >
          {selectedOption
            ? renderOption
              ? renderOption(selectedOption)
              : selectedOption.label
            : placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[400px] min-w-[200px]" align="start">
        <Command shouldFilter={false}>
          <div className="hidden items-center border-b px-3">
            <CommandInput
              placeholder="搜索..."
              value={searchText}
              onValueChange={setSearchText}
              onKeyDown={handleKeyDown}
              className="flex-1"
            />
            {searchOnEnter && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => executeSearch(searchText)}
                disabled={loading}
                className="h-8 w-8"
              >
                <Search className="h-4 w-4" />
              </Button>
            )}
          </div>
          <CommandList>
            {loading && (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            )}
            {!loading && (
              <>
                <CommandEmpty>{emptyMessage}</CommandEmpty>
                <CommandGroup>
                  <ScrollArea className="h-[200px]">
                    {options.map((option) => (
                      <CommandItem
                        key={option.value}
                        value={option.value}
                        onSelect={handleSelect}
                      >
                        {renderOption ? renderOption(option) : option.label}
                        <div className="flex-1" />
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            value === option.value ? "opacity-100" : "opacity-0"
                          )}
                        />
                      </CommandItem>
                    ))}
                  </ScrollArea>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
