import React from "react";
import { AsyncSelect, AsyncSelectOption } from "./async-select";
import { requestPageTask, requestPageExpandTask } from "@/request/document";
import { formatDate } from "@/lib/utils";

interface TaskSelectProps {
  value: string;
  onChange: (value: string, option?: AsyncSelectOption) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

export function ParseTaskSelect({
  value,
  onChange,
  placeholder = "选择解析任务...",
  className,
  disabled = false,
}: TaskSelectProps) {
  // 加载解析任务的函数
  const loadTasks = async (searchText: string) => {
    try {
      const response = await requestPageTask({
        docId: searchText || undefined,
        status: "completed",
        current: 1,
        size: 20,
      });

      if (response.data && response.data.records) {
        return response.data.records.map((task) => ({
          value: task.id || "",
          label: `${task.id} (${task.categoryType})`,
          task: task, // 保存完整的任务对象，以便需要时使用
        }));
      }
      return [];
    } catch (error) {
      console.error("Failed to load tasks:", error);
      return [];
    }
  };

  // 自定义渲染选项
  const renderTaskOption = (option: AsyncSelectOption) => {
    const task = option.task;
    if (!task) return option.label;

    return (
      <div className="flex items-center gap-2">
        <span className="font-medium">
          {task.docFileName}
          <small className="text-xs text-muted-foreground">[{task.id}]</small>
        </span>
        {/* <span className="text-xs text-muted-foreground">
          {formatDate(task.taskUpdatedAt, "MM-dd HH:mm")}
        </span> */}
      </div>
    );
  };

  return (
    <AsyncSelect
      value={value}
      onChange={onChange}
      loadOptions={loadTasks}
      placeholder={placeholder}
      className={className}
      disabled={disabled}
      renderOption={renderTaskOption}
      emptyMessage="没有找到匹配的解析任务"
      triggerSearchLength={0} // 允许空搜索加载所有任务
      searchOnEnter={true} // 使用回车触发搜索
    />
  );
}

export function ExtendTaskSelect({
  value,
  onChange,
  placeholder = "选择扩展任务...",
  className,
  disabled = false,
}: TaskSelectProps) {
  // 加载扩展任务的函数
  const loadTasks = async (searchText: string) => {
    try {
      const response = await requestPageExpandTask({
        parserId: searchText || undefined,
        status: "completed",
        current: 1,
        size: 20,
      });

      if (response.data && response.data.records) {
        return response.data.records.map((task) => ({
          value: task.id || "",
          label: `${task.id} (${task.nodeType})`,
          task: task, // 保存完整的任务对象，以便需要时使用
        }));
      }
      return [];
    } catch (error) {
      console.error("Failed to load expand tasks:", error);
      return [];
    }
  };

  // 自定义渲染选项
  const renderTaskOption = (option: AsyncSelectOption) => {
    const task = option.task;
    if (!task) return option.label;

    return (
      <div className="flex items-center gap-2">
        <span className="font-medium">
          {task.docFileName || task.parserId}
          <small className="text-xs text-muted-foreground">[{task.id}]</small>
        </span>
        {/* <span className="text-xs text-muted-foreground">
          {formatDate(task.taskUpdatedAt, "MM-dd HH:mm")}
        </span> */}
      </div>
    );
  };

  return (
    <AsyncSelect
      value={value}
      onChange={onChange}
      loadOptions={loadTasks}
      placeholder={placeholder}
      className={className}
      disabled={disabled}
      renderOption={renderTaskOption}
      emptyMessage="没有找到匹配的扩展任务"
      triggerSearchLength={0} // 允许空搜索加载所有任务
      searchOnEnter={true} // 使用回车触发搜索
    />
  );
}
