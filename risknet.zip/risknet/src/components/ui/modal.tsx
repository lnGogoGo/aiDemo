import React, { Fragment } from "react";
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import { FiX } from "react-icons/fi";

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  maxWidth?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "full";
  isFullScreen?: boolean;
}

const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  maxWidth = "md",
  isFullScreen = false,
}) => {
  const maxWidthClasses = {
    xs: "sm:max-w-xs",
    sm: "sm:max-w-sm",
    md: "sm:max-w-md",
    lg: "sm:max-w-lg",
    xl: "sm:max-w-xl",
    "2xl": "sm:max-w-2xl",
    full: "sm:max-w-full",
  };

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        open={isOpen}
        className="relative z-50"
        onClose={console.log}
      >
        <TransitionChild
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/30 bg-opacity-25" />
        </TransitionChild>
        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <TransitionChild
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <DialogPanel
                className={`flex flex-col w-full ${
                  isFullScreen
                    ? "flex-1 self-stretch container"
                    : maxWidthClasses[maxWidth]
                } transform overflow-hidden rounded-lg bg-white p-6 pt-8 text-left align-middle shadow-xl transition-all`}
              >
                {title && (
                  <DialogTitle
                    as="h3"
                    className="mb-3 text-md font-medium -mt-4 text-gray-900 pr-8"
                  >
                    {title}
                  </DialogTitle>
                )}
                {/* <button
                  type="button"
                  className="absolute top-1 right-1 bg-gray-100 rounded-full p-1 cursor-pointer hover:bg-gray-200 text-gray-400 hover:text-gray-500"
                  onClick={onClose}
                >
                  <FiX className="h-4 w-4" aria-hidden="true" />
                </button> */}
                {children}
              </DialogPanel>
            </TransitionChild>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

export default Modal;
