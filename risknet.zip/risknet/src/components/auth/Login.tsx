"use client";

import React, { useState, FormEvent, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FiGlobe } from "react-icons/fi";
import { useUserStore } from "@/store/user";
import { LoginParams } from "@/types/user";

export default function Login() {
  const { login, loading, error, clearError } = useUserStore();

  const [formData, setFormData] = useState<LoginParams>({
    uuid: "",
    username: "",
    password: "",
    captcha: "xxx",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // 当用户开始输入时清除错误信息
    if (error) clearError();
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await login(formData);
  };

  const handleCaptcha = async () => {
    const uuid = uuidv4();
    setFormData((prev) => ({ ...prev, uuid }));
  };

  useEffect(() => {
    setFormData((prev) => ({ ...prev, uuid: uuidv4() }));
  }, []);

  return (
    <div className="flex flex-col justify-center flex-1 w-[380px] mx-auto py-12 px-6 bg-gray-100">
      <div className="flex flex-col items-center mt-8 mx-auto w-full max-w-md">
        <div className="space-y-2 p-5 flex flex-col items-center">
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center">
            <FiGlobe size={32} color="white" />
          </div>
          <h1 className="text-lg font-black text-slate-800">
            风险语义网络管理
          </h1>
        </div>
        <div className="w-full bg-white border pt-8 pb-12 px-10 rounded-lg">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label
                htmlFor="username"
                className="block text-sm font-medium text-gray-700"
              >
                用户名
              </label>
              <div className="mt-1">
                <Input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  required
                  value={formData.username}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                密码
              </label>
              <div className="mt-1">
                <Input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="hidden">
              {/*手动输入的验证码*/}
              <label
                htmlFor="captcha"
                className="block text-sm font-medium text-gray-700"
              >
                验证码
              </label>
              <div className="flex items-center mt-1 gap-3">
                <Input
                  // required
                  id="captcha"
                  name="captcha"
                  type="text"
                  autoComplete="captcha"
                  maxLength={4}
                  value={formData.captcha}
                  onChange={handleChange}
                />
                {formData.uuid && (
                  <img
                    alt="验证码"
                    onClick={handleCaptcha}
                    src={`${process.env.NEXT_PUBLIC_API_BASE_URL}/captcha?uuid=${formData.uuid}`}
                    className="w-32 h-9 p-1 border rounded-md cursor-pointer"
                  />
                )}
              </div>
            </div>

            {error && (
              <div className="text-red-500 text-sm py-3 px-3 bg-red-50 rounded-md">
                {error}
              </div>
            )}

            <Button type="submit" disabled={loading} className="w-full h-10">
              {loading ? "登录中..." : "登录"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
