"use client";

import React from "react";
import Link from "next/link";
import { FiGlobe } from "react-icons/fi";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { FiDatabase, FiSearch, FiFileText } from "react-icons/fi";
import { showNetworkImportModal } from "@/components/modals/network/Import";
import { showNewInspectTaskModal } from "@/components/modals/inspect";

export default function Home() {
  const router = useRouter();

  const handleInspectComplete = () => {
    router.push("/inspects");
  };

  return (
    <div className="flex pt-[25vh] flex-col items-center justify-center px-6">
      <div className="space-y-3 flex flex-col items-center">
        <div className="w-24 h-24 bg-blue-600 rounded-[24px] flex items-center justify-center">
          <FiGlobe size={72} color="white" />
        </div>
        <h1 className="text-3xl font-black text-black">风险语义网络管理</h1>
      </div>
      <span className="mt-8 text-sm font-medium text-black/60">
        欢迎使用节点抽检系统，请选择您的操作操作
      </span>
      <div className="flex gap-4 mt-4">
        <Button
          variant="outline"
          size="lg"
          onClick={() => showNewInspectTaskModal(handleInspectComplete)}
          className="w-48 flex items-center justify-center cursor-pointer"
        >
          <FiSearch className="mr-2" />
          节点抽检
        </Button>
        <Button
          variant="outline"
          size="lg"
          onClick={() => showNetworkImportModal()}
          className="w-48 flex items-center justify-center cursor-pointer"
        >
          <FiDatabase className="mr-2" />
          导入语义网络
        </Button>

        <Button
          variant="outline"
          size="lg"
          onClick={() => router.push("/operation-logs")}
          className="w-48 flex items-center justify-center cursor-pointer"
        >
          <FiFileText className="mr-2" />
          操作日志
        </Button>
      </div>
    </div>
  );
}
