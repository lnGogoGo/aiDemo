"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { FaPlus } from "react-icons/fa";
import { requestUserList, requestDeleteUser } from "@/request/user";
import { useUserStore, hasPermission } from "@/store/user";
import { UserInfo } from "@/types/user";
import {
  showCreateUserModal,
  showEditUserModal,
} from "@/components/modals/UserForm";
import { Button } from "@/components/ui/button";
import { WrappedTable } from "@/components/ui/table";

const UserManagementPage = () => {
  const router = useRouter();
  const { initialized } = useUserStore();
  const [users, setUsers] = useState<UserInfo[]>([]);
  const [loading, setLoading] = useState(true);

  // Check if user has admin permissions, redirect if not
  useEffect(() => {
    if (initialized && !hasPermission("*")) {
      router.push("/");
    }
  }, [initialized, router]);

  // Fetch user list
  useEffect(() => {
    if (initialized && hasPermission("*")) {
      fetchUsers();
    }
  }, [initialized]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await requestUserList();
      setUsers(response.data.records || []);
    } catch (error) {
      console.error("Failed to fetch users:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = () => {
    showCreateUserModal(fetchUsers);
  };

  const handleEditUser = (user: UserInfo) => {
    showEditUserModal(user, fetchUsers);
  };

  const handleDeleteUser = async (userId: number) => {
    if (window.confirm("确定要删除这个用户吗？")) {
      setLoading(true);

      try {
        await requestDeleteUser(userId);
        fetchUsers();
      } catch (error) {
        console.error("Failed to delete user:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  if (!initialized || loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-lg font-medium text-gray-900">用户管理</h1>
        <Button onClick={handleCreateUser} className="flex items-center">
          添加用户
        </Button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "ID" },
            { key: "username", label: "用户名" },
            { key: "realName", label: "真实姓名" },
            {
              key: "role",
              label: "角色",
              dataRender: (user) => (user.roleId === 1 ? "管理员" : "普通用户"),
            },
            {
              key: "operation",
              label: "操作",
              className: "w-32",
              dataRender: (user) => (
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditUser(user)}
                  >
                    编辑
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteUser(user.id)}
                  >
                    删除
                  </Button>
                </div>
              ),
            },
          ]}
          data={users}
        />
      </div>
    </div>
  );
};

export default UserManagementPage;
