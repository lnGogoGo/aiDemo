"use client";

import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { WrappedTable } from "@/components/ui/table";
import { WrappedSelect } from "@/components/ui/select";
import {
  requestOperationLogPage,
  requestOperationTypeList,
} from "@/request/operationLog";
import { SnOperationLogPageQuery, SnOperationLogVO } from "@/types/operationLog";
import { formatDate } from "@/lib/utils";

const pageSize = 10;

const OperationLogs = () => {
  const [logs, setLogs] = useState<SnOperationLogVO[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [userId, setUserId] = useState("");
  const [operationType, setOperationType] = useState("0");
  const [operationTypeOptions, setOperationTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [loading, setLoading] = useState(false);

  // 获取操作类型选项
  const fetchOperationTypeOptions = async () => {
    try {
      const response = await requestOperationTypeList();
      if (response.data) {
        const options = Object.entries(response.data).map(([key, value]) => ({
          value: key,
          label: value,
        }));
        setOperationTypeOptions([{ value: "0", label: "全部类型" }, ...options]);
      }
    } catch (error) {
      setOperationTypeOptions([{ value: "0", label: "全部类型" }]);
    }
  };

  // 获取日志列表
  const fetchLogs = async (page?: number) => {
    setLoading(true);
    try {
      const params: SnOperationLogPageQuery = {
        userId: userId || undefined,
        operationType: operationType === "0" ? undefined : operationType,
        startTime: startTime || undefined,
        endTime: endTime || undefined,
        current: page || current,
        size: pageSize,
      };
      const response = await requestOperationLogPage(params);
      if (response.data) {
        setLogs(response.data?.records || []);
        setTotal(response.data?.total || 0);
      }
    } catch (error) {
      setLogs([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchLogs(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchLogs(1);
  };

  useEffect(() => {
    fetchOperationTypeOptions();
    fetchLogs(1);
    // eslint-disable-next-line
  }, []);

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-4 text-lg font-medium text-gray-900">操作日志管理</h1>
      <div className="flex flex-nowrap gap-4 mb-4">
        <Input
          type="text"
          placeholder="用户ID"
          className="w-48 bg-white"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
        />
        <WrappedSelect
          value={operationType}
          options={operationTypeOptions}
          onChange={setOperationType}
          className="w-36 bg-white"
        />
        <Input
          type="datetime-local"
          className="w-56 bg-white"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
        />
        <Input
          type="datetime-local"
          className="w-56 bg-white"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
        />
        <Button onClick={handleSearch}>搜索</Button>
        <div className="flex-1" />
      </div>
      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "日志ID" },
            { key: "userId", label: "用户ID" },
            { key: "userName", label: "用户名" },
            { key: "operationType", label: "操作类型" },
            { key: "moduleName", label: "模块" },
            { key: "operationName", label: "操作名称" },
            { key: "operationCount", label: "数量" },
            { key: "targetType", label: "目标类型" },
            { key: "targetId", label: "目标ID" },
            { key: "operationIp", label: "IP" },
            { key: "errorMessage", label: "错误信息" },
            {
              key: "operationTime",
              label: "操作时间",
              dataRender: (record: SnOperationLogVO) => (
                <span>{formatDate(record.operationTime)}</span>
              ),
            },
            {
              key: "createDate",
              label: "创建时间",
              dataRender: (record: SnOperationLogVO) => (
                <span>{formatDate(record.createDate)}</span>
              ),
            },
          ]}
          data={logs}
        />
      </div>
      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={pageSize}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </div>
  );
};

export default OperationLogs; 