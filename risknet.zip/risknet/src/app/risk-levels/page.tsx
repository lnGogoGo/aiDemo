"use client";

import React from "react";
import { Form, Modal, Input } from "antd";
import { useMessage } from "@/hooks/useMessage";
import { usePageData } from "@/hooks/usePageData";
import { useEntityCrud } from "@/hooks/useEntityCrud";
import { riskLevelApi } from "@/request/riskLevel";
import { RaRiskLevelVO, RaRiskLevelPageQuery } from "@/types/riskLevel";
import { DEFAULT_PAGE_SIZE } from "./constants";
import { 
  createColumn, 
  createSwitchColumn, 
  createStatusColumn, 
  createDateTimeColumn, 
  createActionColumn 
} from "@/utils/tableColumns";
import { 
  createAddButton, 
  createRefreshButton 
} from "@/components/common/ToolbarButtons";
import PageContainer from "@/components/common/PageContainer";
import TableActions from "@/components/common/TableActions";
import RiskLevelModal from "./components/riskLevelModal";
import DetailDrawer from "./components/detailDrawer";

/**
 * 风险级别管理页面
 */
export default function RiskLevelsPage() {
  const [form] = Form.useForm();
  
  // 使用message hook
  const { showMessage, contextHolder } = useMessage();
  
  // 使用分页数据hook处理分页和搜索
  const {
    data,
    total,
    current,
    loading,
    handleSearch,
    handleReset,
    handlePageChange,
    refresh,
  } = usePageData<RaRiskLevelVO, RaRiskLevelPageQuery>(form, {
    pageApi: riskLevelApi.page,
    pageSize: DEFAULT_PAGE_SIZE,
    showMessage,
  });

  // 使用实体CRUD hook处理添加、编辑、查看和删除
  const {
    selectedRecord,
    modalVisible,
    drawerVisible,
    deleteModalVisible,
    deleteLoading,
    recordToDelete,
    deleteConfirmTitle,
    deleteConfirmContent,
    handleAdd,
    handleEdit,
    handleView,
    handleDelete,
    handleStatusChange,
    handleModalSuccess,
    closeModal,
    closeDrawer,
    confirmDelete,
    cancelDelete,
  } = useEntityCrud<RaRiskLevelVO>({
    deleteApi: riskLevelApi.delete,
    enableApi: riskLevelApi.enable,
    disableApi: riskLevelApi.disable,
    onSuccess: refresh,
    deleteConfirmContent: (record) => `删除此风险分级规则后不可恢复，是否确认？`,
    showMessage
  });

  // 表单字段配置
  const formFields = [
    {
      name: "name",
      label: "风险级别名称",
      component: <Input placeholder="请输入" />
    }
  ];

  // 工具栏按钮配置
  const toolbarButtons = [
    createAddButton(handleAdd),
    createRefreshButton(refresh)
  ];

  // 表格列配置
  const columns = [
    createColumn("名称", "name"),
    createColumn("级别ID", "id"),
    createColumn("分数范围", "minScore", {
      dataRender: ({ minScore, maxScore }: RaRiskLevelVO) =>
        `${minScore}-${maxScore}`,
    }),
    createColumn("业务系统", "businessSystemName"),
    createSwitchColumn("启用/禁用", "hasActive", handleStatusChange),
    createStatusColumn("状态", "hasActive"),
    createColumn("处置建议", "treatmentAdvice"),
    createColumn("风险描述", "description"),
    createDateTimeColumn("创建时间", "createdAt"),
    createDateTimeColumn("修改时间", "updatedAt"),
    createActionColumn((record: RaRiskLevelVO) => (
      <TableActions
        record={record}
        actions={[
          { key: 'view', text: '查看', onClick: handleView },
          { key: 'edit', text: '编辑', onClick: handleEdit },
          { key: 'delete', text: '删除', onClick: handleDelete, danger: true }
        ]}
      />
    ))
  ];

  return (
    <>
      {contextHolder}
      <PageContainer
        title="风险级别管理"
        form={form}
        formFields={formFields}
        onSearch={handleSearch}
        onReset={handleReset}
        toolbarButtons={toolbarButtons}
        columns={columns}
        data={data}
        loading={loading}
        current={current}
        pageSize={DEFAULT_PAGE_SIZE}
        total={total}
        onPageChange={handlePageChange}
      >
        {/* 编辑弹窗 */}
        <RiskLevelModal
          visible={modalVisible}
          initialValues={selectedRecord}
          onClose={closeModal}
          onSuccess={(msg) => handleModalSuccess(msg)}
          showMessage={showMessage}
        />

        {/* 删除确认弹窗 */}
        <Modal
          open={deleteModalVisible}
          title={deleteConfirmTitle}
          onCancel={cancelDelete}
          onOk={confirmDelete}
          okText="确定"
          cancelText="取消"
          confirmLoading={deleteLoading}
          maskClosable={false}
          destroyOnHidden
        >
          {recordToDelete && deleteConfirmContent(recordToDelete)}
        </Modal>

        {/* 详情抽屉 */}
        <DetailDrawer
          open={drawerVisible}
          onClose={closeDrawer}
          data={selectedRecord}
        />
      </PageContainer>
    </>
  );
}
