"use client";

import { useEffect, useMemo, useState } from "react";
import { Modal, Form, Input, Select, Button, InputNumber } from "antd";
import { RaRiskLevelVO, RaRiskLevelQuery } from "@/types/riskLevel";
import { businessSystemApi } from "@/request/businessSystem";
import { riskLevelApi } from "@/request/riskLevel";
import { RaBusinessSystemVO } from "@/types/businessSystem";
import { NoticeType } from "antd/es/message/interface";

const { TextArea } = Input;
const { Option } = Select;

interface RiskLevelModalProps {
  visible: boolean;
  initialValues?: RaRiskLevelVO | null;
  onClose: () => void;
  onSuccess: (msg: string) => void;
  showMessage: (type: NoticeType, message: string) => void;
}

const formItemStyle = { marginBottom: 20 };

const RiskLevelModal: React.FC<RiskLevelModalProps> = ({
  visible,
  initialValues,
  onClose,
  onSuccess,
  showMessage,
}) => {
  const [form] = Form.useForm();
  const [businessSystem, setBusinessSystem] = useState<RaBusinessSystemVO[]>(
    []
  );
  const isEdit = !!initialValues?.id;

  useEffect(() => {
    businessSystemApi.listAllActive().then((res) => {
      setBusinessSystem(res?.data || []);
    });
  }, []);

  useEffect(() => {
    if (visible) {
      form.resetFields();
      if (initialValues) {
        form.setFieldsValue({
          ...initialValues,
          scoreRangeMin: initialValues.minScore,
          scoreRangeMax: initialValues.maxScore,
        });
      }
    }
  }, [visible, initialValues, form]);

  const title = useMemo(() => (isEdit ? "编辑" : "新建"), [isEdit]);

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      const data: RaRiskLevelQuery = {
        id: initialValues?.id || "",
        businessSystemId: values.businessSystemId,
        name: values.name,
        description: values.description,
        minScore: values.scoreRangeMin,
        maxScore: values.scoreRangeMax,
        colorCode: values.colorCode,
        treatmentAdvice: values.treatmentAdvice,
        priority: 1,
        hasActive: true,
      };
      await riskLevelApi[isEdit ? "update" : "create"](data)
        .then(() => {
          onSuccess(`${title}成功`);
          onClose();
        })
        .catch((err) => {
          showMessage("error", err.message || `${title}异常`);
        });
    } catch (e) {
      console.error("Validation failed:", e);
    }
  };

  return (
    <Modal
      title={title}
      open={visible}
      onCancel={onClose}
      onOk={handleOk}
      width={720}
      okText={isEdit ? "保存" : "确定"}
      cancelText="取消"
      destroyOnHidden
      maskClosable={false}
    >
      <Form
        form={form}
        layout="horizontal"
        labelAlign="left"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
        initialValues={initialValues || undefined}
      >
        {isEdit && (
          <Form.Item label="级别ID" name="id" style={formItemStyle}>
            <Input disabled />
          </Form.Item>
        )}
        <Form.Item
          label="风险级别名称"
          name="name"
          style={formItemStyle}
          rules={[
            { required: true, message: "请输入风险级别名称" },
            { max: 63, message: "名称最长为63个字符" },
          ]}
        >
          <Input placeholder="风险名称，名称长度为1-63个字符" maxLength={63} />
        </Form.Item>
        <Form.Item
          label="业务系统"
          name="businessSystemId"
          style={formItemStyle}
          rules={[{ required: true, message: "请选择业务系统" }]}
        >
          <Select placeholder="请选择业务系统">
            {businessSystem.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item label="分数范围" required style={formItemStyle}>
          <div className="flex align-center">
            <Form.Item
              name="scoreRangeMin"
              noStyle
              rules={[{ required: true, message: "请输入分数下限" }]}
            >
              <InputNumber
                min={0}
                style={{ width: 120 }}
                placeholder="分数下限"
                onBlur={() => {
                  const min = form.getFieldValue('scoreRangeMin');
                  const max = form.getFieldValue('scoreRangeMax');
                  if (min !== undefined && max !== undefined && min > max) {
                    form.setFieldsValue({ scoreRangeMin: max, scoreRangeMax: min });
                  }
                }}
              />
            </Form.Item>
            <div
              className="w-[30] bg-white text-center"
              style={{
                width: 30,
                pointerEvents: "none",
                background: "#fff",
                borderLeft: 0,
                borderRight: 0,
              }}
            >
              -
            </div>
            <Form.Item
              name="scoreRangeMax"
              noStyle
              rules={[{ required: true, message: "请输入分数上限" }]}
            >
              <InputNumber
                min={0}
                style={{ width: 120 }}
                placeholder="分数上限"
                onBlur={() => {
                  const min = form.getFieldValue('scoreRangeMin');
                  const max = form.getFieldValue('scoreRangeMax');
                  if (min !== undefined && max !== undefined && min > max) {
                    form.setFieldsValue({ scoreRangeMin: max, scoreRangeMax: min });
                  }
                }}
              />
            </Form.Item>
          </div>
        </Form.Item>
        <Form.Item
          label="风险描述"
          name="description"
          style={formItemStyle}
          rules={[{ max: 255, message: "不超过255个字符" }]}
        >
          <TextArea
            rows={2}
            placeholder="请输入风险描述信息，不超过255个字符"
            maxLength={255}
          />
        </Form.Item>
        <Form.Item
          label="处置建议"
          name="treatmentAdvice"
          style={formItemStyle}
          rules={[{ max: 255, message: "不超过255个字符" }]}
        >
          <TextArea
            rows={2}
            placeholder="请输入处置建议，不超过255个字符"
            maxLength={255}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default RiskLevelModal;
