"use client";

import { Drawer, Button } from "antd";
import { RaRiskLevelVO } from "@/types/riskLevel";
import { formatDate } from "../utils";

interface DetailDrawerProps {
  open: boolean;
  onClose: () => void;
  data?: RaRiskLevelVO | null;
}

const DetailDrawer: React.FC<DetailDrawerProps> = ({ open, onClose, data }) => {
  if (!data) return null;
  return (
    <Drawer
      title="查看详情"
      open={open}
      onClose={onClose}
      width={700}
      footer={
        <div style={{ textAlign: "right" }}>
          <Button onClick={onClose} type="primary">
            关闭
          </Button>
        </div>
      }
    >
      <div className="grid grid-cols-24 gap-y-4">
        <div className="col-span-4 text-gray-500">风险级别名称：</div>
        <div className="col-span-20">{data.name}</div>
        <div className="col-span-4 text-gray-500">级别ID：</div>
        <div className="col-span-20">{data.id}</div>
        <div className="col-span-4 text-gray-500">业务系统：</div>
        <div className="col-span-20">{data.businessSystemName}</div>
        <div className="col-span-4 text-gray-500">状态：</div>
        <div className="col-span-20">
          <span style={{ color: "#1677ff", marginRight: 8 }}>●</span>
          {data.hasActive ? "已生效" : "未生效"}
        </div>
        <div className="col-span-4 text-gray-500">分数范围：</div>
        <div className="col-span-20">
          {data.minScore}-{data.maxScore}
        </div>
        <div className="col-span-4 text-gray-500">风险描述：</div>
        <div className="col-span-20">{data.description}</div>
        <div className="col-span-4 text-gray-500">处置建议：</div>
        <div className="col-span-20">{data.treatmentAdvice}</div>
        <div className="col-span-4 text-gray-500">创建时间：</div>
        <div className="col-span-20">{formatDate(data.createdAt || "")}</div>
        <div className="col-span-4 text-gray-500">修改时间：</div>
        <div className="col-span-20">{formatDate(data.updatedAt || "")}</div>
      </div>
    </Drawer>
  );
};

export default DetailDrawer;
