"use client"
import { useState } from "react"
import { Modal, Input, Select, Radio, Button, Upload, Progress, Form } from "antd"
import { UploadOutlined, CloseCircleOutlined } from "@ant-design/icons"
import type { RadioChangeEvent } from "antd"
import type { UploadFile, UploadProps } from "antd/es/upload/interface"
import { cn } from "@/lib/utils"
import { RaRuleVO } from "@/types/rule"

const { TextArea } = Input
const { Option } = Select

interface RuleTestModalProps {
  open: boolean
  onClose: () => void
  onTest: (data: any) => Promise<any>
  rule?: RaRuleVO | null
}

type EvaluationMethod = "single" | "batch"

export default function RuleTestModal({ open, onClose, onTest, rule }: RuleTestModalProps) {
  const [form] = Form.useForm()
  const [evaluationMethod, setEvaluationMethod] = useState<EvaluationMethod>("single")
  const [fileList, setFileList] = useState<UploadFile[]>([])
  const [uploadProgress, setUploadProgress] = useState<number>(0)
  const [testResults, setTestResults] = useState<any>(null)
  const [loading, setLoading] = useState<boolean>(false)

  const handleEvaluationMethodChange = (e: RadioChangeEvent) => {
    setEvaluationMethod(e.target.value)
    setTestResults(null)
  }

  const handleFileChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList)
    if (newFileList.length > 0) {
      // Simulate upload progress
      setUploadProgress(0)
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            return 100
          }
          return prev + 10
        })
      }, 300)
    } else {
      setUploadProgress(0)
    }
  }

  const handleTest = async () => {
    try {
      const values = await form.validateFields()
      setLoading(true)

      // For single evaluation, use the JSON data
      if (evaluationMethod === "single") {
        const jsonData = JSON.parse(values.testData)
        const results = await onTest({
          ...values,
          testData: jsonData,
          ruleId: rule?.id
        })
        setTestResults(results)
      } else {
        // For batch evaluation, use the uploaded file
        if (fileList.length === 0) {
          throw new Error("请先上传文件")
        }

        // Simulate API call with a delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock results for batch evaluation
        setTestResults({
          riskDistribution: {
            high: { count: 18, percentage: "23%" },
            medium: { count: 45, percentage: "58%" },
            low: { count: 15, percentage: "19%" },
          },
          sampleResult: {
            id: rule?.id,
            name: rule?.name,
            version: rule?.version,
            type: rule?.typeDesc,
            conditions: rule?.conditions?.length,
            riskLevel: "高风险",
          },
        })
      }
    } catch (error) {
      console.error("Test error:", error)
      // Handle error
    } finally {
      setLoading(false)
    }
  }

  const handleCustomRequest = ({ onSuccess }: any) => {
    // Simulate success after a short delay
    setTimeout(() => {
      onSuccess("ok")
    }, 0)
  }

  const handleReset = () => {
    form.resetFields()
    setFileList([])
    setUploadProgress(0)
    setTestResults(null)
    setEvaluationMethod("single")
  }

  const renderSingleEvaluationContent = () => (
    <Form.Item
      label="测试数据"
      name="testData"
      rules={[{ required: true, message: "请输入测试数据" }]}
      initialValue={`{
  "finalScore": 76,
  "riskLevel": "高风险",
  "ruleScore": 82,
  "modelScore": 62,
  "triggeredRules": [
    {
      "ruleId": "${rule?.id}",
      "ruleName": "${rule?.name}",
      "score": 30,
      "conditionsMet": [
        {
          "field": "public_opinion_count_30days",
          "actualValue": 2000
        }
      ]
    }
  ]
}`}
    >
      <TextArea rows={12} placeholder="请输入JSON格式的测试数据" className="font-mono text-sm" />
    </Form.Item>
  )

  const renderBatchEvaluationContent = () => (
    <>
      <Form.Item
        label="条件逻辑"
        name="conditionLogic"
        rules={[{ required: true, message: "请选择条件逻辑" }]}
        initialValue={rule?.conditionLogic || "AND"}
      >
        <Radio.Group>
          <Radio value="AND">需全部满足</Radio>
          <Radio value="OR">只需满足任意一条</Radio>
        </Radio.Group>
      </Form.Item>

      <Form.Item
        label="选择文件"
        name="file"
        rules={[{ required: true, message: "请选择文件" }]}
        valuePropName="fileList"
        getValueFromEvent={(e) => {
          if (Array.isArray(e)) {
            return e
          }
          return e?.fileList
        }}
      >
        <Upload
          accept=".xlsx,.xls,.csv"
          maxCount={1}
          fileList={fileList}
          onChange={handleFileChange}
          customRequest={handleCustomRequest}
          onRemove={() => setFileList([])}
        >
          <Button icon={<UploadOutlined />} className="bg-blue-600 text-white hover:bg-blue-700">
            选择文件
          </Button>
        </Upload>
      </Form.Item>

      {fileList.length > 0 && (
        <Form.Item label=" " colon={false}>
          <div className="mt-2">
            <div className="text-sm text-gray-500 mb-1">{fileList[0].name}</div>
            <Progress percent={uploadProgress} size="small" status="active" />
            <div className="text-xs text-gray-400 mt-1">
              {uploadProgress === 100
                ? "上传完成"
                : `${uploadProgress}% [ ${Math.floor((108 * uploadProgress) / 100)} / 120 ]`}
            </div>
          </div>
        </Form.Item>
      )}
    </>
  )

  const renderTestResults = () => {
    if (!testResults) return null

    if (evaluationMethod === "single") {
      return (
        <div className="mt-6 border-t pt-4">
          <h3 className="text-lg font-medium mb-4">评估结果</h3>
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50">
                <th className="border px-4 py-2 text-left">名称</th>
                <th className="border px-4 py-2 text-left">规则名称</th>
                <th className="border px-4 py-2 text-left">版本</th>
                <th className="border px-4 py-2 text-left">规则类型</th>
                <th className="border px-4 py-2 text-left">条件数量</th>
                <th className="border px-4 py-2 text-left">风险等级</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border px-4 py-2">{rule?.id}</td>
                <td className="border px-4 py-2">{rule?.name}</td>
                <td className="border px-4 py-2">{rule?.version}</td>
                <td className="border px-4 py-2">{rule?.typeDesc}</td>
                <td className="border px-4 py-2">{rule?.conditions?.length}</td>
                <td className="border px-4 py-2">高风险</td>
              </tr>
            </tbody>
          </table>
        </div>
      )
    } else {
      return (
        <div className="mt-6 border border-[#E9E9E9]">
          <div className="py-[10] px-[16] bg-[#FAFAFA] mb-3">风险分布</div>
          <div className="py-[10] px-[16]">
            <div className="flex items-center">
              <span className="w-20">高风险:</span>
              <span>
                {testResults.riskDistribution.high.count}条 ({testResults.riskDistribution.high.percentage})
              </span>
            </div>
            <div className="flex items-center">
              <span className="w-20">中风险:</span>
              <span>
                {testResults.riskDistribution.medium.count}条 ({testResults.riskDistribution.medium.percentage})
              </span>
            </div>
            <div className="flex items-center">
              <span className="w-20">低风险:</span>
              <span>
                {testResults.riskDistribution.low.count}条 ({testResults.riskDistribution.low.percentage})
              </span>
            </div>
          </div>
        </div>
      )
    }
  }

  return (
    <Modal
      title="规则测试"
      open={open}
      onCancel={onClose}
      width={720}
      classNames={{
        content: 'p-[20]!',
        body: 'h-[450] p-[0] overflow-y-auto'
      }}
      footer={[
        <Button key="reset" onClick={handleReset}>
          重置
        </Button>,
        <Button key="test" type="primary" onClick={handleTest} loading={loading}>
          开始测试
        </Button>,
      ]}
    >
      <Form form={form} initialValues={rule ?? undefined} layout="horizontal"
        labelAlign="left"
        className="pr-2"
        labelCol={{ span: 3 }}
        wrapperCol={{ span: 21 }}
      >
        <Form.Item
          label="规则名称"
          name="name"
          initialValue={evaluationMethod}
        >
          <Input type="text" disabled />
        </Form.Item>
        <Form.Item
          label="业务系统"
          name="businessSystemId"
          initialValue={evaluationMethod}
        >
          <Select disabled placeholder="请选择业务系统">

          </Select>
        </Form.Item>
        <Form.Item
          label="评估方式"
          name="evaluationMethod"
          initialValue={evaluationMethod}
        >
          <Radio.Group onChange={handleEvaluationMethodChange}>
            <Radio value="single">单条评估</Radio>
            <Radio value="batch">批量评估</Radio>
          </Radio.Group>
        </Form.Item>

        {evaluationMethod === "single" ? renderSingleEvaluationContent() : renderBatchEvaluationContent()}

        {renderTestResults()}
      </Form>
    </Modal>
  )
}
