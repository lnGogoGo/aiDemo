"use client";
import { useState, useRef } from "react";
import { Modal, Button, Upload, Checkbox, Spin, Form } from "antd";
import {
  FileExcelOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import type { UploadFile, UploadProps } from "antd/es/upload/interface";
import { NoticeType } from "antd/es/message/interface";

interface ImportRulesModalProps {
  open: boolean;
  onClose: () => void;
  showMessage: (type: NoticeType, content: string) => void;
  onImport: (
    fileList: UploadFile[]
  ) => Promise<{ success: boolean; message: string; data?: any }>;
}

type ValidationStatus = "idle" | "validating" | "success" | "error";

export default function ImportRulesModal({
  open,
  onClose,
  onImport,
  showMessage,
}: ImportRulesModalProps) {
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [validationStatus, setValidationStatus] =
    useState<ValidationStatus>("idle");
  const [validationMessage, setValidationMessage] = useState("");
  const [isNewRules, setIsNewRules] = useState(true);
  const [updateExisting, setUpdateExisting] = useState(false);
  const uploadRef = useRef<any>(null);

  const handleFileChange: UploadProps["onChange"] = ({
    fileList: newFileList,
  }) => {
    // Only keep the latest file
    const latestFile =
      newFileList.length > 0 ? [newFileList[newFileList.length - 1]] : [];
    setFileList(latestFile);
    // Reset validation status when file changes
    setValidationStatus("idle");
    setValidationMessage("");
  };

  const handleDownloadTemplate = () => {
    // In a real app, this would be a link to download the template file
    showMessage("success", "模板下载成功");
    // Simulate download
    const link = document.createElement("a");
    link.href = "/规则导入模板.xlsx"; // This would be the actual template file path
    link.download = "规则导入模板.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImport = async () => {
    if (fileList.length === 0) {
      showMessage("error", "请先上传文件");
      return;
    }

    try {
      setValidationStatus("validating");
      setValidationMessage("校验中，请耐心等待...");

      // Simulate API call for validation with a delay
      const response = await new Promise<{
        success: boolean;
        message: string;
        data?: any;
      }>((resolve) => {
        setTimeout(() => {
          // Randomly simulate success or failure for demo purposes
          const isSuccess = Math.random() > 0.3;
          if (isSuccess) {
            resolve({
              success: true,
              message: "成功导入 5 条规则，0 条错误",
              data: {
                total: 5,
                errors: 0,
              },
            });
          } else {
            resolve({
              success: false,
              message: "验证失败，请按模板填写。",
            });
          }
        }, 2000);
      });

      if (response.success) {
        setValidationStatus("success");
        setValidationMessage(response.message);
      } else {
        setValidationStatus("error");
        setValidationMessage(response.message);
      }
    } catch (error) {
      setValidationStatus("error");
      setValidationMessage("文件校验失败，请重新上传");
    }
  };

  const handleConfirmImport = async () => {
    if (validationStatus !== "success") {
      showMessage("error", "请先上传并校验文件");
      return;
    }

    try {
      const result = await onImport(fileList);
      if (result.success) {
        showMessage("success", "规则导入成功");
        handleReset();
        onClose();
      } else {
        showMessage("error", result.message || "导入失败");
      }
    } catch (error) {
      showMessage("error", "导入过程中发生错误");
    }
  };

  const handleReset = () => {
    setFileList([]);
    setValidationStatus("idle");
    setValidationMessage("");
    setIsNewRules(true);
    setUpdateExisting(false);
  };

  const beforeUpload = (file: File) => {
    const isExcel =
      file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      file.type === "application/vnd.ms-excel";
    if (!isExcel) {
      showMessage("error", "只能上传Excel文件！");
    }
    return isExcel || Upload.LIST_IGNORE;
  };

  const handleCustomRequest = ({ onSuccess }: any) => {
    // Simulate success after a short delay
    setTimeout(() => {
      onSuccess("ok");
    }, 0);
  };

  const renderUploadButton = () => (
    <>
      <Form.Item
        name="file"
        label="上传文件"
        required
        labelAlign="left"
        labelCol={{ span: 5 }}
        wrapperCol={{ span: 19 }}
        className="mb-[10]!"
      >
        <div className="flex items-center">
          <Upload
            ref={uploadRef}
            accept=".xlsx,.xls"
            maxCount={1}
            fileList={fileList}
            onChange={handleFileChange}
            beforeUpload={beforeUpload}
            customRequest={handleCustomRequest}
            showUploadList={false}
          >
            <div className="flex items-center">
              <input
                type="text"
                placeholder="文件的名称最大字符超出限示..xls"
                value={fileList.length > 0 ? fileList[0].name : ""}
                className="w-64 border border-gray-300 rounded py-1 px-2 mr-2"
                readOnly
              />
              <Button className="bg-blue-600 text-white hover:bg-blue-700">
                选择
              </Button>
            </div>
          </Upload>
        </div>
      </Form.Item>
      <Form.Item
        label=" "
        colon={false}
        className="mb-[10]!"
        labelCol={{ span: 5 }}
        wrapperCol={{ span: 19 }}
      >
        <Button
          className="p-0!"
          type="link"
          icon={<FileExcelOutlined />}
          onClick={handleDownloadTemplate}
        >
          下载Excel模板
        </Button>
        {validationStatus !== "idle" ? (
          <div className="flex items-center">
            {validationStatus === "validating" ? (
              <Spin
                indicator={<LoadingOutlined style={{ fontSize: 16 }} spin />}
                className="mr-2"
              />
            ) : (
              <CheckCircleOutlined className="mr-2 text-green-600!" />
            )}
            <span>
              {validationStatus === "validating"
                ? "文件校验中..."
                : "文件校验成功"}
            </span>
          </div>
        ) : null}
      </Form.Item>
    </>
  );

  const renderValidationStatus = () => {
    if (validationStatus === "idle" && fileList.length === 0) return null;
    if (validationStatus === "success") {
      return (
        <>
          <div className="mt-[20]">
            <div className="mt-2 bg-[#F6F7F8] p-[10] flex items-center">
              <span className="mr-2">验证状态:</span>
              <span>{validationMessage}</span>
            </div>
            <div className="mt-4 pt-4">
              <Form.Item
                label="导入选项"
                name="new"
                colon={false}
                className="mb-0!"
                labelAlign="left"
                labelCol={{ span: 5 }}
                wrapperCol={{ span: 19 }}
              >
                <Checkbox
                  checked={isNewRules}
                  onChange={(e) => setIsNewRules(e.target.checked)}
                >
                  导入为新规则
                </Checkbox>
              </Form.Item>
              <Form.Item
                name="reply"
                label=" "
                colon={false}
                className="mb-0!"
                labelCol={{ span: 5 }}
                wrapperCol={{ span: 19 }}
              >
                <Checkbox
                  checked={updateExisting}
                  onChange={(e) => setUpdateExisting(e.target.checked)}
                >
                  更新已存在的同名规则
                </Checkbox>
              </Form.Item>
            </div>
          </div>
        </>
      );
    }

    if (validationStatus === "error") {
      return (
        <div className="mt-[20]">
          <div className="flex items-center text-red-600">
            <CloseCircleOutlined className="mr-2" />
            <span>文件校验失败，请重新上传</span>
          </div>
          <div className="mt-2 flex items-center">
            <span className="mr-2">验证状态:</span>
            <span className="text-red-600">{validationMessage}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Modal
      title="导入规则"
      open={open}
      onCancel={onClose}
      width={720}
      footer={[
        <Button key="reset" onClick={handleReset}>
          重置
        </Button>,
        <Button
          key="validate"
          onClick={handleImport}
          disabled={fileList.length === 0}
        >
          校验文件
        </Button>,
        <Button
          key="import"
          type="primary"
          onClick={handleConfirmImport}
          disabled={validationStatus !== "success"}
        >
          确认导入
        </Button>,
      ]}
    >
      <Form layout="vertical">
        {renderUploadButton()}
        {renderValidationStatus()}
      </Form>
    </Modal>
  );
}
