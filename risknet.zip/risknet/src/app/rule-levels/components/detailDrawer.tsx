"use client";
import { RaRuleVO } from "@/types/rule";
import { Drawer, Button, Radio, Divider } from "antd";

interface DetailDrawerProps {
  open: boolean;
  onClose: () => void;
  data?: RaRuleVO;
}

export default function DetailDrawer({
  open,
  onClose,
  data,
}: DetailDrawerProps) {
  if (!data) return null;

  return (
    <Drawer
      title="详情"
      placement="right"
      onClose={onClose}
      open={open}
      width={700}
      className="custom-drawer"
      styles={{
        header: {
          padding: "16px 24px",
          borderBottom: "1px solid #f0f0f0",
        },
        body: {
          padding: "16px 24px",
        },
        footer: {
          borderTop: "1px solid #f0f0f0",
          padding: "12px 24px",
        },
      }}
      footer={
        <div className="flex justify-end gap-2">
          <Button
            type="primary"
            className="bg-blue-600 hover:bg-blue-700"
            onClick={onClose}
          >
            关闭
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-24 gap-y-4">
          <div className="col-span-3 text-gray-500">规则名称：</div>
          <div className="col-span-21">{data.name}</div>

          <div className="col-span-3 text-gray-500">规则ID:</div>
          <div className="col-span-21">{data.id}</div>

          <div className="col-span-3 text-gray-500">业务系统:</div>
          <div className="col-span-21">{data.businessSystemName}</div>

          <div className="col-span-3 text-gray-500">状态:</div>
          <div className="col-span-21">
            <Radio checked={data.hasActive} className="text-blue-600">
              {data.hasActive ? "已启用" : "已禁用"}
            </Radio>
          </div>

          <div className="col-span-3 text-gray-500">规则类型:</div>
          <div className="col-span-21">{data.typeDesc}</div>

          <div className="col-span-3 text-gray-500">条件逻辑:</div>
          <div className="col-span-21">{data.conditionLogicDesc}</div>

          <div className="col-span-3 text-gray-500">条件数量:</div>
          <div className="col-span-21">{data.conditions?.length || 0}</div>

          <div className="col-span-3 text-gray-500">版本:</div>
          <div className="col-span-21">{data.version}</div>

          <div className="col-span-3 text-gray-500">创建人:</div>
          <div className="col-span-21">{data.creatorName}</div>

          <div className="col-span-3 text-gray-500">创建时间:</div>
          <div className="col-span-21">{data.createdAt}</div>

          <div className="col-span-3 text-gray-500">更新时间:</div>
          <div className="col-span-21">{data.updatedAt}</div>

          <div className="col-span-3 text-gray-500">描述:</div>
          <div className="col-span-21 break-words">{data.description}</div>

          <div className="col-span-3 text-gray-500">模型名称:</div>
          <div className="col-span-21">{data.modelNameDesc}</div>

          <div className="col-span-3 text-gray-500">权重:</div>
          <div className="col-span-21">{data.weight}</div>
        </div>

        {/* <Divider className="my-4" />

        <div className="border border-gray-200 rounded">
          <div className="p-3 bg-gray-50 font-medium mb-2 flex justify-between">
            风险分布
            <div className="flex">
              <Button type="link" size="small" icon="">
                查看详细结果
              </Button>
              <Button type="link" size="small" icon="">
                导出结果
              </Button>
            </div>
          </div>
          <div className="p-3">
            <div className="space-y-2">
              <div className="flex">
                <span className="text-gray-500">高风险:</span>
                <span>10条(20%)</span>
              </div>
              <div className="flex">
                <span className="text-gray-500">中风险:</span>
                <span>10条(20%)</span>
              </div>
              <div className="flex">
                <span className="text-gray-500">低风险:</span>
                <span>10条(20%) </span>
              </div>
            </div>
          </div>
        </div> */}
      </div>
    </Drawer>
  );
}
