"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Modal,
  Form,
  Input,
  Select,
  Radio,
  Button,
  Space,
  InputNumber,
} from "antd";
import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { RaRuleVO, RaRuleQuery } from "@/types/rule";
import { businessSystemApi } from "@/request/businessSystem";
import { metadataApi } from "@/request/metadata";
import { ruleApi } from "@/request/rule";
import { RaBusinessSystemVO } from "@/types/businessSystem";
import {
  ConditionField,
  ConditionLogic,
  Operator,
  RuleType,
} from "@/types/metadata";
import { NoticeType } from "antd/es/message/interface";

const { TextArea } = Input;
const { Option } = Select;

interface RuleFormData {
  name: string;
  description: string;
  type: "CONDITION" | "NATURAL_LANGUAGE";
  businessSystemId: string;
  conditionLogic: "AND" | "OR";
  conditions: {
    id: string;
    type: string;
    fieldType: string;
    field: string;
    operator: string;
    value: any;
    weight: number;
  }[];
  weight: number;
  hasActive: boolean;
}

interface RuleModalProps {
  visible: boolean;
  initialValues?: RaRuleVO | null;
  onClose: () => void;
  showMessage: (type: NoticeType, messgae: string) => void;
  onSuccess: (res: string) => void;
}

const formItemStyle = {
  marginBottom: "20px",
};

enum DefaultRuleType {
  CONDITION = "condition_rule",
  LLM = "llm_prompt_rule",
}

const RuleModal: React.FC<RuleModalProps> = ({
  visible,
  onClose,
  initialValues,
  onSuccess,
  showMessage,
}) => {
  const [form] = Form.useForm();
  const ruleType = Form.useWatch("type", form);
  const [businessSystem, setBusinessSystem] = useState<RaBusinessSystemVO[]>(
    []
  );
  const [ruleTypes, setRuleTypes] = useState<RuleType[]>([]);
  const [conditionFields, setConditionFields] = useState<ConditionField[]>([]);
  const [operatorsList, setOperatorsList] = useState<Operator[][]>([]);
  const [conditionLogics, setConditionLogics] = useState<ConditionLogic[]>([]);
  const isInitialMount = useRef(true);

  const getConfig = useCallback(() => {
    businessSystemApi.listAllActive().then((res) => {
      setBusinessSystem(res?.data || []);
    });
    metadataApi.getRuleTypes().then((res) => {
      setRuleTypes(res?.data || []);
    });
    metadataApi.getConditionFields().then((res) => {
      setConditionFields(res?.data || []);
    });
    metadataApi.getConditionLogics().then((res) => {
      setConditionLogics(res?.data || []);
    });
  }, []);

  useEffect(() => {
    if (!isInitialMount.current) {
      form.setFieldsValue({
        conditions: [{}],
      });
      setOperatorsList([]);
    }
    ruleType ? (isInitialMount.current = false) : "";
  }, [ruleType]);

  const searchOperator = async (fieldType: string, index: number) => {
    const operators = await metadataApi.getOperators(fieldType);
    const current: Operator[][] = JSON.parse(JSON.stringify(operatorsList));
    current[index] = operators?.data;
    setOperatorsList(current);
  };

  useEffect(() => {
    getConfig();
  }, []);

  const handleCancel = () => {
    form.resetFields();
    onClose();
  };

  const title = useMemo(() => {
    return initialValues?.id ? "编辑规则" : "新建规则";
  }, [initialValues]);

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      const data: RaRuleQuery = {
        ...values,
        id: initialValues?.id || "1",
        businessSystemId: values.businessSystemId,
        type: values.type,
        name: values.name,
        description: values.description,
        conditionLogic: values.conditionLogic,
        conditions: values.conditions,
        weight: values.weight,
        hasActive: !!initialValues?.hasActive,
      };

      await ruleApi[initialValues?.id ? "update" : "create"](data)
        .then((res) => {
          debugger
          console.log("res", res);
          onSuccess(`${title}成功`);
        })
        .catch((err) => {
          debugger
          showMessage("error", err.message || `${title}}异常`);
        });
    } catch (error) {
      console.error("Validation failed:", error);
    }
  };

  return (
    <>
      <Modal
        title={title}
        open={visible}
        width={720}
        classNames={{
          content: "p-[20]!",
          body: "h-[450] p-[0] overflow-y-auto",
        }}
        centered
        okText="保存"
        onOk={handleSave}
        onCancel={handleCancel}
        maskClosable={false}
        destroyOnHidden
      >
        <Form
          name="ruleModal"
          form={form}
          colon={false}
          layout="horizontal"
          scrollToFirstError={{
            behavior: "instant",
            block: "end",
            focus: true,
          }}
          initialValues={
            initialValues || {
              type: DefaultRuleType.CONDITION,
              conditions: [{}],
            }
          }
          labelAlign="left"
          className="pr-2"
          labelCol={{ span: 3 }}
          wrapperCol={{ span: 21 }}
        >
          <div className="border-b border-gray-200 mb-[20]">
            <h3 className="text-base  my-2">基本信息</h3>
          </div>

          <Form.Item
            style={{ marginBottom: 0 }}
            label={<span className="text-black">规则名称</span>}
            name="name"
            rules={[{ required: true, message: "请输入规则名称" }]}
            required
            extra="名称长度为1-63个字符"
          >
            <Input maxLength={63} placeholder="请输入规则名称" />
          </Form.Item>

          <Form.Item
            style={formItemStyle}
            label={<span className="text-black">业务系统</span>}
            name="businessSystemId"
            rules={[{ required: true, message: "请选择业务系统" }]}
            required
          >
            <Select placeholder="请选择业务系统">
              {businessSystem.map((option) => (
                <Option key={option.id} value={option.id}>
                  {option.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item style={formItemStyle} label="描述" name="description">
            <TextArea
              rows={4}
              placeholder="请输入描述信息，不超过255个字符"
              maxLength={255}
            />
          </Form.Item>

          <div className="border-b border-gray-200 mb-[20]">
            <h3 className="text-base  my-2">条件设置</h3>
          </div>

          <Form.Item
            style={formItemStyle}
            label={<span className="text-black">规则类型</span>}
            name="type"
            rules={[{ required: true, message: "请选择规则类型" }]}
            required
          >
            <Radio.Group>
              {ruleTypes.map((item) => (
                <Radio key={item.value} value={item.value}>
                  {item.label}
                </Radio>
              ))}
            </Radio.Group>
          </Form.Item>

          <Form.Item
            style={formItemStyle}
            label={<span className="text-black">条件逻辑</span>}
            name="conditionLogic"
            rules={[{ required: true, message: "请选择条件逻辑" }]}
            required
          >
            <Radio.Group>
              {conditionLogics.map((item) => (
                <Radio key={item.value} value={item.value}>
                  {item.label}
                </Radio>
              ))}
            </Radio.Group>
          </Form.Item>

          <div className="mt-[-2]">
            <Form.List
              name="conditions"
            >
              {(fields, { add, remove }) => {
                return (
                  <div className="space-y-3">
                    <Button
                      type="dashed"
                      onClick={() => add()}
                      block
                      icon={<PlusOutlined />}
                      className="mb-[20]"
                    >
                      添加条件
                    </Button>
                    {fields.map((field, index) =>
                      ruleType === DefaultRuleType.CONDITION ? (
                        <div key={field.key}>
                          <Form.Item
                            style={formItemStyle}
                            label={
                              <span className="text-black">
                                条件{index + 1}
                              </span>
                            }
                            required
                            labelAlign="left"
                            className="mb-1"
                            labelCol={{ span: 3 }}
                            wrapperCol={{ span: 21 }}
                          >
                            <Space className="flex w-full">
                              <Form.Item
                                style={formItemStyle}
                                name={[field.name, "field"]}
                                noStyle
                                rules={[
                                  { required: true, message: "请选择字段" },
                                ]}
                              >
                                <Select
                                  onChange={(newValue, item: any) => {
                                    searchOperator(
                                      item?.info?.fieldType,
                                      index
                                    );
                                  }}
                                  style={{ width: 150 }}
                                  placeholder="请选择字段"
                                >
                                  {conditionFields.map((option) => (
                                    <Option
                                      key={option.value}
                                      value={option.value}
                                      info={option}
                                    >
                                      {option.label}
                                    </Option>
                                  ))}
                                </Select>
                              </Form.Item>

                              <Form.Item
                                style={formItemStyle}
                                name={[field.name, "operator"]}
                                noStyle
                                rules={[
                                  { required: true, message: "请选择操作符" },
                                ]}
                              >
                                <Select
                                  style={{ width: 100 }}
                                  placeholder="请选择"
                                >
                                  {operatorsList[index]?.map((option) => (
                                    <Option
                                      key={option.value}
                                      value={option.value}
                                    >
                                      {option.label}
                                    </Option>
                                  ))}
                                </Select>
                              </Form.Item>

                              <Form.Item
                                style={formItemStyle}
                                name={[field.name, "value"]}
                                noStyle
                                rules={[
                                  { required: true, message: "请输入值" },
                                ]}
                              >
                                <Input
                                  style={{ width: 150 }}
                                  placeholder="请输入值"
                                />
                              </Form.Item>

                              {fields.length > 1 ? <Button
                                type="text"
                                icon={<DeleteOutlined />}
                                onClick={() => { remove(field.name) }}
                                className="flex items-center justify-center"
                              >
                                删除
                              </Button> : null}
                            </Space>
                          </Form.Item>
                        </div>
                      ) : ruleType === DefaultRuleType.LLM ? (
                        <div key={field.key}>
                          <Form.Item
                            label={<span className="text-black">规则内容</span>}
                            required={index < 2} // 前两项为必填
                            className="mb-1"
                            labelCol={{ span: 3 }}
                            wrapperCol={{ span: 21 }}
                          >
                            <div className="flex items-center space-x-2">
                              <Form.Item
                                name={[field.name, "content"]}
                                className="mr-[10]"
                                noStyle
                                rules={[
                                  {
                                    required: index < 2,
                                    message: "请输入规则内容",
                                  },
                                ]}
                              >
                                <Input
                                  className="mr-[10]! w-[280]!"
                                  placeholder="请输入规则内容"
                                />
                              </Form.Item>

                              <Form.Item
                                name={[field.name, "weight"]}
                                noStyle
                                rules={[
                                  {
                                    required: index < 2,
                                    message: "请输入规则权重",
                                  },
                                ]}
                              >
                                <InputNumber
                                  className="mr-[10]! w-[172]!"
                                  placeholder="请输入规则权重"
                                  min={0}
                                  max={100}
                                />
                              </Form.Item>

                              {fields.length > 1 ? <Button
                                type="text"
                                icon={<DeleteOutlined />}
                                onClick={() => { remove(field.name) }}
                                className="flex items-center justify-center"
                              >
                                删除
                              </Button> : null}
                            </div>
                          </Form.Item>
                        </div>
                      ) : null
                    )}
                  </div>
                );
              }}
            </Form.List>
          </div>

          <Form.Item
            style={formItemStyle}
            label={<span className="text-black">规则分数</span>}
            name="weight"
            rules={[{ required: true, message: "请输入规则分数" }]}
            required
          >
            <InputNumber
              max={100}
              style={{ width: 400 }}
              placeholder="请输入规则名称"
            />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default RuleModal;
