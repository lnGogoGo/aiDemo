"use client";

import React, { useState } from "react";
import { Form, Select, UploadFile } from "antd";
import { useMessage } from "@/hooks/useMessage";
import { usePageData } from "@/hooks/usePageData";
import { useDataFetching } from "@/hooks/useDataFetching";
import { ruleApi } from "@/request/rule";
import { businessSystemApi } from "@/request/businessSystem";
import { RaRuleVO, RaRulePageQuery } from "@/types/rule";
import { RaBusinessSystemVO } from "@/types/businessSystem";
import { DEFAULT_PAGE_SIZE } from "./constants";
import { 
  createColumn, 
  createSwitchColumn, 
  createStatusColumn, 
  createDateTimeColumn, 
  createActionColumn 
} from "@/utils/tableColumns";
import { 
  createAddButton, 
  createImportButton,
  createRefreshButton 
} from "@/components/common/ToolbarButtons";
import PageContainer from "@/components/common/PageContainer";
import TableActions from "@/components/common/TableActions";
import RuleModal from "./components/ruleModal";
import DetailDrawer from "./components/detailDrawer";
import ImportRulesModal from "./components/importRulesModal";
import RuleTestModal from "./components/ruleTest";

export default function RuleLevelsPage() {
  const [form] = Form.useForm();
  const { showMessage, contextHolder } = useMessage();
  
  // 状态管理
  const [visible, setVisible] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<RaRuleVO | null>(null);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [testModalOpen, setTestModalOpen] = useState(false);

  // 获取业务系统列表
  const { data: systemsList = [] } = useDataFetching<RaBusinessSystemVO>({
    fetchApi: businessSystemApi.listAllActive,
    errorMessage: "加载业务系统失败",
    showMessage
  });

  // 使用分页数据hook处理分页和搜索
  const {
    data: rules,
    setData: setRules,
    total,
    current,
    loading,
    handleSearch,
    handleReset,
    handlePageChange,
    refresh,
  } = usePageData<RaRuleVO, RaRulePageQuery>(form, {
    pageApi: ruleApi.page,
    pageSize: DEFAULT_PAGE_SIZE,
    showMessage
  });

  // 处理规则状态变更
  const handleRuleStatusChange = async (record: RaRuleVO, checked: boolean, index?: number) => {
    try {
      await ruleApi[checked ? "enable" : "disable"](record.id);
      showMessage("success", `${checked ? "启用" : "禁用"}成功`);
      
      if (index !== undefined) {
        const updatedRules = [...rules];
        updatedRules[index] = {
          ...updatedRules[index],
          hasActive: checked,
        };
        setRules(updatedRules);
      }
    } catch (error: any) {
      showMessage(
        "error",
        error?.message || `${checked ? "启用" : "禁用"}失败`
      );
    }
  };

  // 规则操作处理函数
  const handleShow = (record: RaRuleVO) => {
    setSelectedRecord(record);
    setDrawerOpen(true);
  };

  const handleEdit = (record: RaRuleVO) => {
    setSelectedRecord(record);
    setVisible(true);
  };

  const handleExperiment = (record: RaRuleVO) => {
    setSelectedRecord(record);
    setTestModalOpen(true);
  };

  const handleModalClose = () => {
    setVisible(false);
    setSelectedRecord(null);
  };

  const handleDrawerClose = () => {
    setDrawerOpen(false);
    setSelectedRecord(null);
  };

  // 导入规则处理
  const handleImport = async (fileList: UploadFile<any>[]) => {
    try {
      // TODO: 实现导入逻辑
      showMessage("success", "导入成功");
      setImportModalOpen(false);
      refresh();
      return { success: true, message: "导入成功" };
    } catch (error) {
      showMessage("error", "导入失败");
      return { success: false, message: "导入失败" };
    }
  };

  // 规则测试处理
  const handleTest = async (testData: any) => {
    console.log("Testing with data:", testData);
    // 模拟API调用延迟
    await new Promise((resolve) => setTimeout(resolve, 1000));
    return {
      success: true,
      data: {
        id: "542459",
        name: "高频次投诉风险规则",
        version: "1.0",
        type: "条件逻辑规则",
        conditions: 2,
        riskLevel: "高风险",
      },
    };
  };

  // 表单字段配置
  const formFields = [
    {
      name: "businessSystem",
      label: "业务系统",
      component: (
        <Select placeholder="请选择" allowClear>
          {systemsList?.map((option) => (
            <Select.Option key={option.id} value={option.name}>
              {option.name}
            </Select.Option>
          ))}
        </Select>
      )
    },
    {
      name: "hasActive",
      label: "状态",
      component: (
        <Select placeholder="请选择" allowClear>
          <Select.Option value={true}>已生效</Select.Option>
          <Select.Option value={false}>未生效</Select.Option>
        </Select>
      )
    }
  ];

  // 工具栏按钮配置
  const toolbarButtons = [
    createAddButton(() => {
      setSelectedRecord(null);
      setVisible(true);
    }, "新增规则"),
    createImportButton(() => setImportModalOpen(true)),
    createRefreshButton(refresh)
  ];

  // 表格列配置
  const columns = [
    createColumn("规则ID", "id"),
    createColumn("规则名称", "name"),
    createColumn("规则类型", "typeDesc"),
    createColumn("业务系统", "businessSystemName"),
    createColumn("条件数量", "conditions", {
      dataRender: ({ conditions }: RaRuleVO) => conditions?.length || 0,
    }),
    createColumn("版本", "version"),
    createColumn("创建人", "creatorName"),
    createSwitchColumn("启用/禁用", "hasActive", handleRuleStatusChange),
    createStatusColumn("状态", "hasActive"),
    createDateTimeColumn("创建时间", "createdAt"),
    createDateTimeColumn("更新时间", "updatedAt"),
    createActionColumn((record: RaRuleVO) => (
      <TableActions
        record={record}
        actions={[
          { key: 'view', text: '查看', onClick: handleShow },
          { key: 'edit', text: '编辑', onClick: handleEdit },
          { key: 'test', text: '测试', onClick: handleExperiment }
        ]}
      />
    ))
  ];

  return (
    <>
      {contextHolder}
      <PageContainer
        title="规则分级管理"
        form={form}
        formFields={formFields}
        onSearch={handleSearch}
        onReset={handleReset}
        toolbarButtons={toolbarButtons}
        columns={columns}
        data={rules}
        loading={loading}
        current={current}
        pageSize={DEFAULT_PAGE_SIZE}
        total={total}
        onPageChange={handlePageChange}
      >
        {/* 规则弹窗 */}
        {visible && (
          <RuleModal
            visible={visible}
            initialValues={selectedRecord}
            onClose={handleModalClose}
            showMessage={showMessage}
            onSuccess={(res) => {
              showMessage("success", res);
              handleModalClose();
              refresh();
            }}
          />
        )}

        {/* 详情抽屉 */}
        {drawerOpen && (
          <DetailDrawer
            open={drawerOpen}
            onClose={handleDrawerClose}
            data={selectedRecord || undefined}
          />
        )}
        
        {/* 导入规则弹窗 */}
        {importModalOpen && (
          <ImportRulesModal
            open={importModalOpen}
            onClose={() => setImportModalOpen(false)}
            onImport={handleImport}
            showMessage={showMessage}
          />
        )}
        
        {/* 规则测试弹窗 */}
        {testModalOpen && (
          <RuleTestModal
            open={testModalOpen}
            rule={selectedRecord}
            onClose={() => setTestModalOpen(false)}
            onTest={handleTest}
          />
        )}
      </PageContainer>
    </>
  );
}
