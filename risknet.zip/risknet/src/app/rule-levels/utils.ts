import { formatDate as formatDateUtil } from "@/components/common/DetailDrawer";

export const formatDate = formatDateUtil;
