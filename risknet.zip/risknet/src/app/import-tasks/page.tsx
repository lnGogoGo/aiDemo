"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { WrappedTable } from "@/components/ui/table";
import { WrappedSelect } from "@/components/ui/select";
import {
  requestPageImportTask,
  requestImportTaskConfig,
  requestGetImportTaskStatus,
} from "@/request/document";
import { SnImportTaskVO } from "@/types/document";
import { showNetworkImportModal } from "@/components/modals/network/Import";
import { useIntervalWhenVisible } from "@/hooks/base";
import { formatDate } from "@/lib/utils";
const pageSize = 10;

const fetchPendingParseTasksStatus = async (
  taskIds: string[],
  onStatusUpdate: (id: string, data: SnImportTaskVO) => void
) => {
  for (const taskId of taskIds) {
    requestGetImportTaskStatus(taskId).then((response) => {
      if (response.data) {
        onStatusUpdate(taskId, response.data);
      }
    });
  }
};

const ImportTasks = () => {
  const [tasks, setTasks] = useState<SnImportTaskVO[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [parserId, setParserId] = useState("");
  const [nodeType, setNodeType] = useState("");
  const [status, setStatus] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [nodeTypeOptions, setNodeTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);
  const [statusOptions, setStatusOptions] = useState<
    { label: string; value: string }[]
  >([]);

  // 获取导入任务列表
  const fetchTasks = async (page?: number) => {
    setLoading(true);
    try {
      const response = await requestPageImportTask({
        parserId: parserId || undefined,
        nodeType: nodeType === "0" ? undefined : nodeType,
        status: status === "0" ? undefined : status,
        current: page || current,
        size: pageSize,
      });

      if (response.data) {
        setTasks(response.data.records || []);
        setTotal(response.data.total || 0);

        const pendingTasks = response.data.records!.filter(
          (task) => task.status !== "completed" && task.status !== "failed"
        );

        if (pendingTasks.length > 0) {
          fetchPendingParseTasksStatus(
            pendingTasks.map((task) => task.id!),
            (id, data) => {
              setTasks((prev) =>
                prev.map((task) => (task.id === id ? data : task))
              );
            }
          );
        }
      }
    } catch (error) {
      console.error("获取导入任务列表失败", error);
    } finally {
      setLoading(false);
    }
  };

  // 获取配置选项
  const fetchConfigOptions = async () => {
    try {
      const response = await requestImportTaskConfig();

      if (response?.data) {
        // 节点类型选项
        if (response.data.nodeTypes) {
          const options = Object.entries(response.data.nodeTypes).map(
            ([key, value]) => ({
              value: key,
              label: value,
            })
          );
          setNodeTypeOptions([{ value: "0", label: "全部类型" }, ...options]);
        }

        // 状态选项
        if (response.data.taskStatus) {
          const options = Object.entries(response.data.taskStatus).map(
            ([key, value]) => ({
              value: key,
              label: value,
            })
          );
          setStatusOptions([{ value: "0", label: "全部状态" }, ...options]);
        }
      }
    } catch (error) {
      console.error("获取配置选项失败", error);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchTasks(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchTasks();
  };

  const handleShowImportModal = () => {
    showNetworkImportModal({
      onSubmit: handleSearch,
      onClose: () => {},
    });
  };

  useEffect(() => {
    fetchConfigOptions();
    fetchTasks();
  }, []);

  useIntervalWhenVisible(fetchTasks, 10000);

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-4 text-lg font-medium text-gray-900">
        语义网络导入任务管理
      </h1>
      <div className="flex flex-nowrap gap-4 mb-4">
        <Input
          type="text"
          placeholder="解析任务ID"
          className="w-48 bg-white"
          value={parserId}
          onChange={(e) => setParserId(e.target.value)}
        />
        <WrappedSelect
          value={nodeType}
          options={nodeTypeOptions}
          onChange={setNodeType}
          className="w-36 bg-white"
        />

        <WrappedSelect
          value={status}
          options={statusOptions}
          className="w-32 bg-white"
          onChange={setStatus}
        />

        <Button onClick={handleSearch}>搜索</Button>
        <div className="flex-1" />
        <Button onClick={handleShowImportModal}>新建导入任务</Button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "任务ID" },
            {
              key: "task",
              label: "源任务",
              dataRender: (record: SnImportTaskVO) => (
                <div className="flex flex-col">
                  <span className="text-xs text-gray-500">
                    {record.type === 1 ? "解析任务" : "扩展任务"}
                  </span>
                  <Link
                    href={`/parse-tasks/${
                      record.type === 1 ? "parse" : "extend"
                    }/${record.sourceId}`}
                  >
                    {record.sourceId}
                  </Link>
                </div>
              ),
            },
            { key: "nodeTypeDesc", label: "节点类型" },
            {
              key: "sourceType",
              label: "数据来源",
              dataRender: (record: SnImportTaskVO) => (
                <div className="flex flex-col">
                  <span>{record.sourceType}</span>
                  <span className="text-xs text-gray-500">
                    {record.sourceName}
                  </span>
                </div>
              ),
            },
            {
              key: "statusDesc",
              label: "状态",
            },
            {
              key: "progress",
              label: "进度",
              dataRender: (record: SnImportTaskVO) => (
                <div className="flex flex-col">
                  <span>
                    {record.progress
                      ? `${(record.progress * 100)?.toFixed(0)}%`
                      : "0%"}
                  </span>
                  <span className="text-xs text-gray-500">
                    {record.currentStep || 0} / {record.totalSteps || 0}
                  </span>
                </div>
              ),
            },
            { key: "errorMessage", label: "错误信息" },
            {
              key: "taskCreatedAt",
              label: "时间",
              dataRender: (record: SnImportTaskVO) => (
                <div className="flex flex-col">
                  <span>{formatDate(record.taskCreatedAt)}</span>
                  <span>{formatDate(record.taskUpdatedAt)}</span>
                </div>
              ),
            },
          ]}
          data={tasks}
        />
      </div>

      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={pageSize}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </div>
  );
};

export default ImportTasks;
