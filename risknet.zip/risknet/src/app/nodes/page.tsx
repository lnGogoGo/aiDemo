"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Node, NodeStatus, NodeMark } from "@/types";
import useNodeStore from "@/store/node";
import useDataStore from "@/store/data";
import {
  formatDateTime,
  getStatusStyle,
  getMarkStyle,
  formatNodesToJson,
} from "@/helpers/formatters";
import { submitNodeFeedback } from "@/helpers/api";
import { exportToJson } from "@/helpers/exporters";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function NodesPage() {
  const {
    nodes,
    selectedNode,
    viewMode,
    selectNode,
    updateNodeStatus,
    updateNodeMark,
    setViewMode,
  } = useNodeStore();

  const { addInspectionRecord } = useDataStore();

  const [feedback, setFeedback] = useState<string>("");
  const [selectedStatus, setSelectedStatus] = useState<NodeStatus | null>(null);
  const [selectedMark, setSelectedMark] = useState<NodeMark>(NodeMark.NORMAL);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 10;

  // 计算总页数
  const totalPages = Math.ceil(nodes.length / itemsPerPage);

  // 获取当前页的节点
  const currentNodes = nodes.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleNodeClick = (node: Node) => {
    if (node) {
      selectNode(node);
      if (node.status) {
        setSelectedStatus(node.status);
      }
      if (node.mark) {
        setSelectedMark(node.mark);
      } else {
        setSelectedMark(NodeMark.NORMAL);
      }

      setFeedback(node.feedback || "");
    }
  };

  const handleStatusChange = (status: NodeStatus) => {
    setSelectedStatus(status);
  };

  const handleMarkChange = (mark: NodeMark) => {
    setSelectedMark(mark);
  };

  const handleSubmit = async () => {
    if (!selectedNode || !selectedStatus) return;

    setIsSubmitting(true);

    try {
      // 更新节点状态
      updateNodeStatus(selectedNode.id, selectedStatus, feedback);
      updateNodeMark(selectedNode.id, selectedMark);

      // 记录抽检结果
      const record = {
        id: Date.now().toString(),
        nodeId: selectedNode.id,
        operator: "current-user", // 实际项目中应当从用户认证系统获取
        inspectedAt: new Date().toISOString(),
        status: selectedStatus,
        mark: selectedMark,
        feedback: feedback,
      };

      // addInspectionRecord(record);

      // 提交到后端
      await submitNodeFeedback(
        selectedNode.id,
        selectedStatus,
        selectedMark,
        feedback
      );

      // 重置表单
      selectNode(null);
      setSelectedStatus(null);
      setFeedback("");
    } catch (error) {
      console.error("提交反馈失败", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExport = () => {
    exportToJson(nodes, `nodes-export-${new Date().toISOString()}.json`);
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-lg font-medium">节点展示区</h1>
        <div className="flex space-x-3">
          <div className="flex border rounded-md overflow-hidden">
            <button
              className={`px-4 py-2 ${
                viewMode === "list"
                  ? "bg-blue-100 text-blue-800"
                  : "bg-white text-gray-700"
              }`}
              onClick={() => setViewMode("list")}
            >
              列表视图
            </button>
            <button
              className={`px-4 py-2 ${
                viewMode === "json"
                  ? "bg-blue-100 text-blue-800"
                  : "bg-white text-gray-700"
              }`}
              onClick={() => setViewMode("json")}
            >
              JSON视图
            </button>
            <button
              className={`px-4 py-2 ${
                viewMode === "graph"
                  ? "bg-blue-100 text-blue-800"
                  : "bg-white text-gray-700"
              }`}
              onClick={() => setViewMode("graph")}
            >
              关系图视图
            </button>
          </div>
          <Button onClick={handleExport}>导出</Button>
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 mb-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* 节点列表 */}
          <div className={`w-full ${selectedNode ? "lg:w-2/3" : "lg:w-full"}`}>
            <Tabs
              defaultValue="list"
              onValueChange={(value) =>
                setViewMode(value as "list" | "json" | "graph")
              }
            >
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="list">列表视图</TabsTrigger>
                <TabsTrigger value="json">JSON视图</TabsTrigger>
                <TabsTrigger value="graph">关系图视图</TabsTrigger>
              </TabsList>

              <TabsContent value="list">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          名称
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          实体类型
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          状态
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          标记
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {currentNodes.map((node) => {
                        const statusStyle = node.status
                          ? getStatusStyle(node.status)
                          : { color: "", bgColor: "" };
                        const markStyle = node.mark
                          ? getMarkStyle(node.mark)
                          : { color: "", bgColor: "" };

                        return (
                          <tr
                            key={node.id}
                            className={`hover:bg-gray-50 cursor-pointer ${
                              selectedNode?.id === node.id ? "bg-blue-50" : ""
                            }`}
                            onClick={() => handleNodeClick(node)}
                          >
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {node.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {node.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {node.entityType}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {node.status && (
                                <span
                                  className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusStyle.bgColor} ${statusStyle.color}`}
                                >
                                  {node.status}
                                </span>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {node.mark && (
                                <span
                                  className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${markStyle.bgColor} ${markStyle.color}`}
                                >
                                  {node.mark}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  {/* 分页控制 */}
                  {totalPages > 1 && (
                    <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                      <div className="flex-1 flex justify-between items-center">
                        <Button
                          variant="outline"
                          onClick={handlePreviousPage}
                          disabled={currentPage === 1}
                          size="sm"
                        >
                          上一页
                        </Button>
                        <span className="text-sm text-gray-700">
                          第 {currentPage} 页，共 {totalPages} 页
                        </span>
                        <Button
                          variant="outline"
                          onClick={handleNextPage}
                          disabled={currentPage === totalPages}
                          size="sm"
                        >
                          下一页
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="json">
                <ScrollArea className="h-[500px] rounded-md border">
                  <div className="p-4 bg-gray-50">
                    <pre className="text-sm overflow-x-auto text-gray-900">
                      {formatNodesToJson(nodes)}
                    </pre>
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="graph">
                <div className="border rounded-lg p-4 flex items-center justify-center h-80 bg-gray-50">
                  <p className="text-gray-500">图形视图正在开发中...</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* 节点详情和反馈表单 */}
          {selectedNode && (
            <div className="w-full lg:w-1/3 bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                节点详情
              </h2>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">ID</p>
                    <p className="text-base text-gray-900">{selectedNode.id}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-1">名称</p>
                    <p className="text-base text-gray-900">
                      {selectedNode.name}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-1">描述</p>
                    <p className="text-base text-gray-900">
                      {selectedNode.description}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-1">实体类型</p>
                    <p className="text-base text-gray-900">
                      {selectedNode.entityType}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-1">创建时间</p>
                    <p className="text-base text-gray-900">
                      {formatDateTime(selectedNode.createdAt)}
                    </p>
                  </div>

                  <h3 className="text-lg font-medium text-gray-900 mt-6 mb-4">
                    反馈信息
                  </h3>

                  <div>
                    <p className="text-sm text-gray-500 mb-2">状态</p>
                    <div className="flex flex-wrap gap-2">
                      {Object.values(NodeStatus).map((status) => (
                        <button
                          key={status}
                          type="button"
                          className={`px-3 py-1 rounded-md text-sm ${
                            selectedStatus === status
                              ? "bg-blue-100 text-blue-800 border border-blue-300"
                              : "bg-white text-gray-800 border border-gray-300 hover:bg-gray-50"
                          }`}
                          onClick={() => handleStatusChange(status)}
                        >
                          {status}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-2">标记</p>
                    <div className="flex flex-wrap gap-2">
                      {Object.values(NodeMark).map((mark) => (
                        <button
                          key={mark}
                          type="button"
                          className={`px-3 py-1 rounded-md text-sm ${
                            selectedMark === mark
                              ? "bg-blue-100 text-blue-800 border border-blue-300"
                              : "bg-white text-gray-800 border border-gray-300 hover:bg-gray-50"
                          }`}
                          onClick={() => handleMarkChange(mark)}
                        >
                          {mark}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-2">反馈意见</p>
                    <textarea
                      className="w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      rows={4}
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                      placeholder="请输入反馈意见..."
                    ></textarea>
                  </div>
                </div>
              </ScrollArea>

              <div className="flex justify-end mt-6">
                <Button
                  variant="outline"
                  onClick={() => selectNode(null)}
                  className="mr-3"
                >
                  取消
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={!selectedStatus || isSubmitting}
                >
                  {isSubmitting ? "提交中..." : "提交反馈"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
