"use client";

import { loader } from "@monaco-editor/react";

import React, { useEffect } from "react";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { useUserStore } from "@/store/user";
import LoginPage from "@/components/auth/Login";
import { Button } from "@/components/ui/button";
import { Toaster } from "sonner";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  FiFileText,
  FiHome,
  FiUser,
  FiGlobe,
  FiLogOut,
  FiUsers,
  FiCheckSquare,
  FiBarChart2,
  FiCpu,
  FiPlusSquare,
  FiUpload,
} from "react-icons/fi";
import "./globals.css";

ChartJS.register(ArcElement, Tooltip, Legend);

loader.config({
  paths: {
    vs: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs",
  },
});

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { initialized, authorized, initialize, logout, userInfo } =
    useUserStore();
  const pathname = usePathname();

  console.log("authorized", authorized);
  console.log("initialized", initialized);

  useEffect(() => {
    // 在应用启动时初始化用户状态
    if (!initialized) {
      initialize();
    }
  }, [initialized, initialize]);

  // 导航菜单项
  const menuItems = [
    { path: "/", label: "开始", icon: <FiHome size={20} /> },
    { path: "/rule-levels", label: "规则分级管理", icon: <FiFileText size={20} /> },
    { path: "/risk-levels", label: "风险级别管理", icon: <FiFileText size={20} /> },
    { path: "/risk-analysis", label: "风险统计分析", icon: <FiFileText size={20} /> },
    { path: "/business-systems", label: "业务系统管理", icon: <FiFileText size={20} /> },
    { path: "/engine-config", label: "引擎配置管理", icon: <FiFileText size={20} /> },
    { path: "/documents", label: "文档管理", icon: <FiFileText size={20} /> },
    {
      path: "/parse-tasks/parse",
      label: "解析任务",
      icon: <FiCpu size={20} />,
    },
    {
      path: "/parse-tasks/extend",
      label: "扩展任务",
      icon: <FiPlusSquare size={20} />,
    },
    {
      path: "/import-tasks",
      label: "导入任务",
      icon: <FiUpload size={20} />,
    },
    { path: "/inspects", label: "抽检任务", icon: <FiCheckSquare size={20} /> },
    { path: "/operation-logs", label: "操作日志", icon: <FiFileText size={20} /> },
    // { path: "/statistics", label: "数据统计", icon: <FiBarChart2 size={20} /> },
    { path: "/users", label: "用户管理", icon: <FiUsers size={20} /> },
  ];

  let content = children;

  // 如果还没初始化完成，显示加载中
  if (!initialized) {
    content = <div>应用加载中...</div>;
  } else if (!authorized) {
    content = <LoginPage />;
  }

  // 已初始化且已授权，显示主应用
  return (
    <html lang="zh-CN">
      <head>
        <title>劳动风险语义网络人工抽检和反馈优化系统</title>
        <meta
          name="description"
          content="劳动风险语义网络人工抽检和反馈优化系统"
        />
      </head>
      <body>
        <div className="flex h-screen bg-gray-100">
          {/* 侧边栏 */}
          {authorized && (
            <aside className="w-52 h-full border-r bg-white flex flex-col">
              {/* 侧边栏标题 */}
              <div className="space-x-2 p-5 flex items-center">
                <div className="w-7 h-7 bg-blue-600 rounded-md flex items-center justify-center">
                  <FiGlobe size={16} color="white" />
                </div>
                <h1 className="text-sm font-black text-slate-800">
                  风险语义网络管理
                </h1>
              </div>

              {/* 导航菜单 */}
              <nav className="flex-grow p-5 overflow-y-auto tiny-scrollbar">
                <ul className="space-y-2">
                  {menuItems.map((item) => (
                    <li key={item.path}>
                      <Link
                        href={item.path}
                        className={`flex items-center px-4 py-3 rounded-md text-sm font-medium transition-colors ${pathname === item.path
                            ? "bg-primary/5"
                            : "hover:bg-primary/5"
                          }`}
                      >
                        <span className="mr-3">{item.icon}</span>
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>

              {/* 用户信息和操作 - 放在底部 */}
              <div className="p-5 mt-auto">
                <div className="flex items-center mb-4">
                  <div className="border border-slate-300 text-slate-500 p-2 rounded-lg mr-3">
                    <FiUser size={20} />
                  </div>
                  <div className="flex flex-col space-y-1">
                    <span className="leading-none text-sm font-bold">
                      {userInfo?.realName || "用户"}
                    </span>
                    <span className="leading-none text-xs text-slate-500">
                      @{userInfo?.username}
                    </span>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={logout}
                  className="w-full flex items-center justify-center cursor-pointer"
                >
                  <FiLogOut size={14} className="mr-2" />
                  <span className="text-xs">退出登录</span>
                </Button>
              </div>
            </aside>
          )}

          {/* 主内容区域 */}
          <div className="flex-1 flex flex-col overflow-y-auto ">
            {/* 内容区 */}
            <main className="flex-1 p-6">{content}</main>
            {/* 页脚 */}
            <footer className="bg-gray-100 p-4 text-center text-xs text-gray-400">
              © {new Date().getFullYear()}{" "}
              劳动风险语义网络人工抽检和反馈优化系统
            </footer>
          </div>
        </div>
        <Toaster position="top-center" />
      </body>
    </html>
  );
}
