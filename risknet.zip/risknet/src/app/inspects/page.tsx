"use client";

import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { WrappedTable } from "@/components/ui/table";
import {
  requestGetInspectionTaskStatus,
  requestInspectionTasks,
} from "@/request/inspect";
import { showNewInspectTaskModal } from "@/components/modals/inspect";
import { useIntervalWhenVisible } from "@/hooks/base";
import { formatDate } from "@/lib/utils";
import {
  SnInspectionTaskVO,
  InspectionMethodLabelMap,
  InspectionStatusLabelMap,
} from "@/types/inspect";
import { showInspecNodesModal } from "@/components/modals/inspect/Nodes";
import { showInspecStatModal } from "@/components/modals/inspect/Stat";

const pageSize = 10;

const fetchPendingTasksStatus = async (
  taskIds: string[],
  onStatusUpdate: (id: string, data: SnInspectionTaskVO) => void
) => {
  for (const taskId of taskIds) {
    requestGetInspectionTaskStatus(taskId).then((response) => {
      if (response.data) {
        onStatusUpdate(taskId, response.data);
      }
    });
  }
};

const InspectTasks = () => {
  const [tasks, setTasks] = useState<SnInspectionTaskVO[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [loading, setLoading] = useState(false);

  const fetchTasks = async (page?: number) => {
    setLoading(true);
    try {
      const response = await requestInspectionTasks({
        current: page || current,
        size: pageSize,
      });

      if (response.data) {
        setTasks(response.data.records || []);
        setTotal(response.data.total || 0);

        const pendingTasks = response.data.records!.filter(
          (task) => task.status === 0 || task.status === 1
        );

        if (pendingTasks.length > 0) {
          fetchPendingTasksStatus(
            pendingTasks.map((task) => task.id!),
            (id, data) => {
              setTasks((prevTasks) =>
                prevTasks.map((task) =>
                  task.id === id ? { ...task, ...data } : task
                )
              );
            }
          );
        }
      }
    } catch (error) {
      console.error("获取导入任务列表失败", error);
    } finally {
      setLoading(false);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchTasks(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchTasks();
  };

  const handleShowNewInspectTaskModal = () => {
    showNewInspectTaskModal(handleSearch);
  };

  const handleShowInspecNodesModal = (id: string) => {
    showInspecNodesModal(id, fetchTasks);
  };

  const handleShowInspecStatModal = (id: string) => {
    showInspecStatModal(id, fetchTasks);
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  useIntervalWhenVisible(fetchTasks, 10000);

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-4 text-lg font-medium text-gray-900">抽检任务管理</h1>
      <div className="flex flex-nowrap gap-4 mb-4">
        {/* <Button onClick={handleSearch}>搜索</Button> */}
        <div className="flex-1" />
        <Button onClick={handleShowNewInspectTaskModal}>新建抽检任务</Button>
      </div>
      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "任务ID" },
            {
              key: "method",
              label: "抽检方式",
              dataRender: (record: SnInspectionTaskVO) => (
                <span>{InspectionMethodLabelMap[record.method!]}</span>
              ),
            },
            {
              key: "time",
              label: "时间",
              dataRender: (record: SnInspectionTaskVO) => (
                <div className="flex flex-col">
                  <span>{formatDate(record.taskCreatedAt)}</span>
                  <span>{formatDate(record.taskUpdatedAt)}</span>
                </div>
              ),
            },
            { key: "count", label: "数量" },
            { key: "operatorName", label: "操作人" },
            {
              key: "statusDesc",
              label: "状态",
              // dataRender: (record: SnInspectionTaskVO) =>
              //   record.status === 2 && !record.auditCount ? (
              //     "未开始"
              //   ) : (
              //     <span>{InspectionStatusLabelMap[record.status!]}</span>
              //   ),
            },
            {
              key: "progress",
              label: "审核进度",
              dataRender: (record: SnInspectionTaskVO) => (
                <span>
                  {Math.round(
                    ((record.auditCount || 0) / (record.count || 1)) * 100
                  )}
                  %
                  <span className="ml-2 text-gray-400">
                    ({record.auditCount || 0} / {record.count || 0})
                  </span>
                </span>
              ),
            },
            {
              key: "errorMessage",
              label: "信息",
              dataRender: (record: SnInspectionTaskVO) => (
                <span>{record.errorMessage}</span>
              ),
            },
            {
              key: "operation",
              label: "操作",
              className: "w-48",
              dataRender: (record: SnInspectionTaskVO) => (
                <div className="flex gap-2">
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleShowInspecNodesModal(record.id!)}
                    >
                      审核
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleShowInspecStatModal(record.id!)}
                  >
                    修复
                  </Button>
                </div>
              ),
            },
          ]}
          data={tasks}
        />
      </div>
      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={pageSize}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </div>
  );
};

export default InspectTasks;
