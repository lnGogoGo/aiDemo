"use client";

import React, { useState, useEffect } from "react";
import { NodeStatus, NodeMark } from "@/types";
import useDataStore from "@/store/data";
import { fetchStatistics } from "@/helpers/api";
import {
  PieChart,
  Pie,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ResponsiveContainer,
} from "recharts";
import { StatisticData } from "@/types";

// 定义图表颜色
const COLORS = {
  [NodeStatus.CORRECT]: "#10B981", // green
  [NodeStatus.INCORRECT]: "#EF4444", // red
  [NodeStatus.NEEDS_ADJUSTMENT]: "#F59E0B", // yellow
  [NodeStatus.ADJUSTED]: "#3B82F6", // blue
  [NodeMark.IMPORTANT]: "#8B5CF6", // purple
  [NodeMark.NORMAL]: "#6B7280", // gray
};

export default function StatisticsPage() {
  const [statistics, setStatistics] = useState<StatisticData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { filterTimeRange, setFilterTimeRange } = useDataStore();

  useEffect(() => {
    const loadStatistics = async () => {
      setIsLoading(true);
      try {
        const data = await fetchStatistics();
        setStatistics(data);
      } catch (error) {
        console.error("加载统计数据失败", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadStatistics();
  }, [filterTimeRange]);

  // 转换状态数据为图表格式
  const statusData = statistics
    ? Object.entries(statistics.statusCounts).map(([status, count]) => ({
        name: status,
        value: count,
      }))
    : [];

  // 转换标记数据为图表格式
  const markData = statistics
    ? Object.entries(statistics.markCounts).map(([mark, count]) => ({
        name: mark,
        value: count,
      }))
    : [];

  // 转换实体类型数据为图表格式
  const entityTypeData = statistics
    ? Object.entries(statistics.entityTypeCounts).map(([type, count]) => ({
        name: type,
        value: count,
      }))
    : [];

  if (isLoading) {
    return (
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-lg font-medium text-gray-900 mb-4">数据统计</h1>
        <div className="flex justify-center items-center h-64">
          <div className="text-gray-500">正在加载统计数据...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-lg font-medium text-gray-900">数据统计</h1>
        <div>
          <select
            className="block w-40 rounded-md border border-gray-300 py-2 pl-3 pr-10 text-base focus:border-blue-500 focus:outline-none focus:ring-blue-500"
            value={filterTimeRange}
            onChange={(e) => setFilterTimeRange(e.target.value as any)}
          >
            <option value="all">全部时间</option>
            <option value="day">最近一天</option>
            <option value="week">最近一周</option>
            <option value="month">最近一个月</option>
            <option value="threeMonths">最近三个月</option>
          </select>
        </div>
      </div>

      {statistics ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 状态分布 */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              状态分布
            </h2>
            <div className="h-72 flex justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    label={({ name, percent }) =>
                      `${name} ${(percent * 100).toFixed(0)}%`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[entry.name as NodeStatus] || "#ccc"}
                      />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} 个节点`, "数量"]} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 标记分布 */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              标记分布
            </h2>
            <div className="h-72 flex justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={markData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    label={({ name, percent }) =>
                      `${name} ${(percent * 100).toFixed(0)}%`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {markData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[entry.name as NodeMark] || "#ccc"}
                      />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} 个节点`, "数量"]} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 实体类型分布 */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              实体类型分布
            </h2>
            <div className="h-72 flex justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={entityTypeData}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 60, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" />
                  <Tooltip formatter={(value) => [`${value} 个节点`, "数量"]} />
                  <Legend />
                  <Bar dataKey="value" name="节点数量" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 时间分布 */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              抽检时间分布
            </h2>
            <div className="h-72 flex justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={statistics.timeDistribution}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} 次抽检`, "次数"]} />
                  <Legend />
                  <Bar dataKey="count" name="抽检次数" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 错误率最高的节点 */}
          <div className="bg-gray-50 rounded-lg p-4 col-span-1 md:col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              错误率最高的节点
            </h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      排名
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      节点ID
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      节点名称
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      错误次数
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {statistics.topErrorNodes.map((node, index) => (
                    <tr key={node.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {index + 1}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {node.id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {node.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {node.count}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-10 text-gray-500">
          无法加载统计数据，请稍后重试。
        </div>
      )}
    </div>
  );
}
