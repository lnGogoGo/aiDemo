"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Document } from "@/types/document";
import Link from "next/link";
import {
  requestDocumentPage,
  requestDeleteDocument,
  requestDownloadDocument,
} from "@/request/document";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { WrappedTable } from "@/components/ui/table";
import {
  showParseForm,
  showDocumentUploader,
} from "@/components/modals/documents";

const DocumentsPage = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [filename, setFilename] = useState("");
  const [loading, setLoading] = useState(false);

  // 获取文档列表
  const fetchDocuments = useCallback(
    async (page?: number) => {
      setLoading(true);
      try {
        const response = await requestDocumentPage({
          filename,
          current: page || current,
          size: 10,
        });

        if (response.data) {
          setDocuments(response.data.records || []);
          setTotal(response.data.total || 0);
        }
      } catch (error) {
        console.error("获取文档列表失败", error);
      } finally {
        setLoading(false);
      }
    },
    [filename, current]
  );

  // 删除文档
  const handleDelete = async (id: string) => {
    if (!confirm("确定要删除此文档吗？")) return;

    try {
      await requestDeleteDocument(id);
      fetchDocuments();
    } catch (error) {
      console.error("删除文档失败", error);
    }
  };

  // 下载文档
  const handleDownload = async (id: string, filename: string) => {
    try {
      const response = await requestDownloadDocument(id);
      // Check if the response is a blob already, otherwise extract the data
      const blob =
        response instanceof Blob
          ? response
          : new Blob([response.data || response]);

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("下载文档失败", error);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchDocuments(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchDocuments();
  };

  const openCreateTaskModal = (doc: Document) => {
    showParseForm(doc, () => {
      fetchDocuments();
    });
  };

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-4 text-lg font-medium text-gray-900">文档管理</h1>
      <div className="flex flex-nowrap gap-3 mb-4">
        <Input
          type="text"
          placeholder="文档名称"
          value={filename}
          className="w-72 bg-white"
          onChange={(e) => setFilename(e.target.value)}
        />
        <Button onClick={handleSearch}>搜索</Button>
        <div className="flex-1" />
        <Button
          onClick={() =>
            showDocumentUploader({ onUpload: () => fetchDocuments() })
          }
        >
          上传文档
        </Button>
      </div>
      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "filename", label: "文件名" },
            {
              key: "creatorName",
              label: "创建人",
              // dataRender: (doc: Document) => {
              //   return (
              //     <div className="flex flex-col gap-2">
              //       <span>{doc.creatorName || "未知"}</span>
              //       <span className="text-xs opacity-80">
              //         ID: {doc.creator || "未知"}
              //       </span>
              //     </div>
              //   );
              // },
            },
            { key: "createDate", label: "创建时间", className: "w-28" },
            {
              key: "operation",
              label: "操作",
              className: "w-48",
              dataRender: (doc: Document) => (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDownload(doc.id!, doc.filename!)}
                  >
                    下载
                  </Button>
                  {doc.hasParsed ? (
                    <Link href={`/parse-tasks/parse?docId=${doc.id}`}>
                      <Button size="sm" variant="outline">
                        查看解析任务
                      </Button>
                    </Link>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openCreateTaskModal(doc)}
                    >
                      解析
                    </Button>
                  )}

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(doc.id!)}
                  >
                    删除
                  </Button>
                </div>
              ),
            },
          ]}
          data={documents}
        />
      </div>
      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={10}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </div>
  );
};

export default DocumentsPage;
