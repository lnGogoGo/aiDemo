"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import {
  DocumentParseTask,
  DocumentParsePageResult,
  DocumentParseStatusLabel,
  DocumentParseStatus,
  ParseExpandTask,
  SnExpandTaskBatchVO,
} from "@/types/document";
import {
  requestGetTaskStatus,
  requestPageTaskResult,
  requestGetExpandTaskStatus,
  requestPageExpandTaskBatch,
} from "@/request/document";
import {
  showParseTaskPageResult,
  showParseTaskResumeModal,
} from "@/components/modals/documents/Parse";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { WrappedTable } from "@/components/ui/table";
import { showExpandTaskBatchResult } from "@/components/modals/documents/Extend";
import { toast } from "sonner";
import {
  showExpandTaskResumeModal,
  showParseTaskExpandModal,
} from "@/components/modals/documents/ExpandTask";
import { useIntervalWhenVisible } from "@/hooks/base";

const ParseTaskDetailPage = () => {
  const params = useParams();
  const taskId = params.id as string;
  const type = params.type as string;
  const isExtendTask = type === "extend";

  console.log("taskId", taskId);
  console.log("type", type);

  // 解析任务状态
  const [parseTask, setParseTask] = useState<DocumentParseTask | null>(null);
  const [parseResults, setParseResults] = useState<DocumentParsePageResult[]>(
    []
  );
  const [parseResultTotal, setParseResultTotal] = useState(0);
  const [parseResultPage, setParseResultPage] = useState(1);

  // 扩展任务状态
  const [extendTask, setExtendTask] = useState<ParseExpandTask | null>(null);
  const [extendBatches, setExtendBatches] = useState<SnExpandTaskBatchVO[]>([]);
  const [extendBatchTotal, setExtendBatchTotal] = useState(0);
  const [extendBatchPage, setExtendBatchPage] = useState(1);

  const [loading, setLoading] = useState(false);

  // 获取任务状态
  const fetchTaskStatus = async () => {
    try {
      if (isExtendTask) {
        const response = await requestGetExpandTaskStatus(taskId);

        if (response.data) {
          setExtendTask(response.data);
        }

        return response.data;
      } else {
        const response = await requestGetTaskStatus(taskId);
        if (response.data) {
          setParseTask(response.data);
        }

        return response.data;
      }
    } catch (error) {
      console.error("获取任务状态失败", error);
      toast.error("获取任务状态失败");

      return null;
    }
  };

  // 获取任务结果列表
  const fetchTaskResults = async (page?: number) => {
    setLoading(true);

    try {
      if (isExtendTask) {
        const response = await requestPageExpandTaskBatch({
          id: taskId,
          current: page || extendBatchPage,
          size: 10,
        });

        if (response) {
          setExtendBatches(response.data.records || []);
          setExtendBatchTotal(response.data.total || 0);
        }
      } else {
        const response = await requestPageTaskResult({
          id: taskId,
          current: page || parseResultPage,
          size: 10,
        });

        if (response.data) {
          setParseResults(response.data.records || []);
          setParseResultTotal(response.data.total || 0);
        }
      }
    } catch (error) {
      // console.log("获取任务结果列表失败", error);
      // toast.error("获取任务结果列表失败");
    } finally {
      setLoading(false);
    }
  };

  // 恢复任务
  const handleResumeTask = async () => {
    if (isExtendTask) {
      showExpandTaskResumeModal(taskId, () => {
        fetchTaskStatus();
      });
    } else {
      showParseTaskResumeModal(parseTask!, () => {
        fetchTaskStatus();
      });
    }
  };

  // 提交扩展任务
  const handleSubmitExpandTask = async (parserId: string) => {
    showParseTaskExpandModal(parserId);
  };

  // 结果分页变化
  const handleResultPageChange = (page: number) => {
    if (isExtendTask) {
      setExtendBatchPage(page);
      fetchTaskResults(page);
    } else {
      fetchTaskResults(page);
    }
  };

  useEffect(() => {
    if (taskId) {
      fetchTaskStatus();
      fetchTaskResults();
    }
  }, [taskId]);

  useIntervalWhenVisible(() => {
    fetchTaskStatus();
    fetchTaskResults();
  }, 10000);

  // 渲染解析任务详情
  const renderParseTaskDetail = () => {
    if (!parseTask) return null;

    const totalSteps = parseTask.totalSteps || parseTask.endPageNum;

    const progress =
      typeof parseTask.progress === "number"
        ? parseTask.progress
        : (parseTask.currentPage! / totalSteps) * 100;

    return (
      <>
        <div className="bg-white p-4 border rounded-lg mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center">
              <span className="text-black/60 w-18">文档名称：</span>
              <span className="text-black/80 font-medium">
                {parseTask.docFileName}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">分类类型：</span>
              <span className="text-black/80 font-medium">
                {parseTask.categoryTypeDesc}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">模型名称：</span>
              <span className="text-black/80 font-medium">
                {parseTask.modelName}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">来源类型：</span>
              <span className="text-black/80 font-medium">
                {parseTask.sourceTypeDesc}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">来源名称：</span>
              <span className="text-black/80 font-medium">
                {parseTask.sourceName}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">状态：</span>
              <span className="text-black/80 font-medium">
                {parseTask.statusDesc}
              </span>
              {parseTask.status === DocumentParseStatus.COMPLETED && (
                <Button
                  onClick={() => handleSubmitExpandTask(parseTask.id!)}
                  variant="outline"
                  size="xs"
                  className="ml-4"
                >
                  扩展
                </Button>
              )}
              {parseTask.status === DocumentParseStatus.FAILED && (
                <Button
                  onClick={handleResumeTask}
                  variant="outline"
                  size="xs"
                  className="ml-4"
                >
                  恢复
                </Button>
              )}
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">页码范围：</span>
              <span className="text-black/80 font-medium">
                {parseTask.startPageNum} - {parseTask.endPageNum}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">进度：</span>
              <span className="text-black/80 font-medium">
                {((progress || 0) * 100).toFixed(0)}%&ensp;
                <span className="text-gray-500 font-normal ml-1">
                  {parseTask.currentPage || 0}/{totalSteps || 0}
                </span>
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">创建时间：</span>
              <span className="text-black/80 font-medium">
                {parseTask.taskCreatedAt &&
                  new Date(parseTask.taskCreatedAt).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-18">更新时间：</span>
              <span className="text-black/80 font-medium">
                {parseTask.taskUpdatedAt &&
                  new Date(parseTask.taskUpdatedAt).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center flex-1 col-span-2">
              <span className="text-black/60 w-18">信息：</span>
              <span className="text-black/80 font-medium">
                {parseTask.errorMessage || "-"}
              </span>
            </div>
          </div>
        </div>

        <h2 className="text-md font-semibold mb-3">任务结果</h2>
        <div className="border rounded-lg overflow-hidden">
          <WrappedTable
            loading={loading}
            columns={[
              { key: "pageNum", className: "w-12", label: "页码" },
              { key: "statusDesc", className: "w-24", label: "状态" },
              {
                key: "message",
                label: "信息",
                dataRender: (record: DocumentParsePageResult) =>
                  record.errors?.join(",") || "-",
              },
              {
                key: "updateDate",
                label: "创建时间",
              },
              {
                key: "operations",
                className: "w-24",
                label: "操作",
                dataRender: (record: DocumentParsePageResult) => (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        showParseTaskPageResult(parseTask.id!, record, () => {
                          fetchTaskStatus();
                          fetchTaskResults();
                        });
                      }}
                    >
                      查看解析结果
                    </Button>
                  </div>
                ),
              },
            ]}
            data={parseResults}
          />
        </div>

        {parseResultTotal > 0 && (
          <div className="mt-4 flex justify-end">
            <Pagination
              current={parseResultPage}
              pageSize={10}
              total={parseResultTotal}
              onChange={handleResultPageChange}
            />
          </div>
        )}
      </>
    );
  };

  // 渲染扩展任务详情
  const renderExtendTaskDetail = () => {
    if (!extendTask) return null;

    const progress =
      typeof extendTask.progress === "number"
        ? extendTask.progress
        : (extendTask.currentStep! / extendTask.totalSteps!) * 100;

    return (
      <>
        <div className="bg-white p-4 border rounded-lg mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center">
              <span className="text-black/60 w-24">解析任务ID：</span>
              <span className="text-black/80 font-medium">
                <a
                  className="hover:underline"
                  href={`/parse-tasks/parse/${extendTask.parserId}`}
                >
                  {extendTask.parserId}
                </a>
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">节点类型：</span>
              <span className="text-black/80 font-medium">
                {extendTask.nodeTypeDesc}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">模型名称：</span>
              <span className="text-black/80 font-medium">
                {extendTask.modelName}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">状态：</span>
              <span className="text-black/80 font-medium">
                {extendTask.statusDesc}
              </span>
              {extendTask.status === "failed" && (
                <Button
                  onClick={handleResumeTask}
                  variant="outline"
                  size="xs"
                  className="ml-4"
                >
                  恢复任务
                </Button>
              )}
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">批处理大小：</span>
              <span className="text-black/80 font-medium">
                {extendTask.batchSize}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">进度：</span>
              <span className="text-black/80 font-medium">
                {((progress || 0) * 100).toFixed(0)}%&ensp;
                <span className="text-gray-500 font-normal ml-1">
                  {extendTask.currentStep || 0}/{extendTask.totalSteps || 0}
                </span>
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">创建时间：</span>
              <span className="text-black/80 font-medium">
                {extendTask.taskCreatedAt &&
                  new Date(extendTask.taskCreatedAt).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-black/60 w-24">更新时间：</span>
              <span className="text-black/80 font-medium">
                {extendTask.taskUpdatedAt &&
                  new Date(extendTask.taskUpdatedAt).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
        <h2 className="text-md font-semibold mb-3">批次结果</h2>
        <div className="border rounded-lg overflow-hidden">
          <WrappedTable
            loading={loading}
            columns={[
              { key: "batchNum", className: "w-12", label: "批次号" },
              { key: "status", className: "w-24", label: "状态" },
              {
                key: "message",
                label: "信息",
                dataRender: (record: SnExpandTaskBatchVO) =>
                  record.errors?.join(",") || "-",
              },
              {
                key: "processedTerms",
                label: "处理词",
                dataRender: (record: SnExpandTaskBatchVO) =>
                  record.processedTerms?.join(",") || "-",
              },
              {
                key: "taskCreatedAt",
                label: "创建时间",
                dataRender: (record: SnExpandTaskBatchVO) =>
                  record.taskCreatedAt
                    ? new Date(record.taskCreatedAt).toLocaleString()
                    : "-",
              },
              {
                key: "operations",
                className: "w-24",
                label: "操作",
                dataRender: (record: SnExpandTaskBatchVO) => (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        // 这里需要实现查看扩展结果的功能
                        console.log("查看扩展结果", record);
                        showExpandTaskBatchResult(record);
                        // 可以实现类似showParseTaskPageResult的函数
                      }}
                    >
                      扩展结果
                    </Button>
                  </div>
                ),
              },
            ]}
            data={extendBatches}
          />
        </div>

        {extendBatchTotal > 0 && (
          <div className="mt-4 flex justify-end">
            <Pagination
              current={extendBatchPage}
              pageSize={10}
              total={extendBatchTotal}
              onChange={handleResultPageChange}
            />
          </div>
        )}
      </>
    );
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="flex items-center mb-4 text-lg font-medium text-gray-900">
        <span className="mr-2">
          {isExtendTask ? "扩展任务详情" : "解析任务详情"}
        </span>
        <small className="text-gray-500 font-normal ml-1">
          ID: {isExtendTask ? extendTask?.id : parseTask?.id}
        </small>
      </h1>
      {isExtendTask ? renderExtendTaskDetail() : renderParseTaskDetail()}
    </div>
  );
};

export default ParseTaskDetailPage;
