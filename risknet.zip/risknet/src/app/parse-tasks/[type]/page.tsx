"use client";

import React, { useState, useEffect, useMemo } from "react";
import { DocumentParseTask } from "@/types/document";
import { requestPageTask } from "@/request/document";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { DocumentParseStatusLabel, DocumentParseStatus } from "@/types";
import {
  showExpandTaskResumeModal,
  showParseTaskExpandModal,
} from "@/components/modals/documents/ExpandTask";
import useConfigStore from "@/store/config";
import { WrappedTable } from "@/components/ui/table";
import { WrappedSelect } from "@/components/ui/select";
import Link from "next/link";
import { requestPageExpandTask } from "@/request/document";
import { ParseExpandTask } from "@/types/document";
import { toast } from "sonner";
import {
  requestExpandTaskConfig,
  requestGetTaskStatus,
  requestGetExpandTaskStatus,
} from "@/request/document";
import { useParams, useSearchParams } from "next/navigation";
import { useIntervalWhenVisible } from "@/hooks/base";
import { showParseTaskResumeModal } from "@/components/modals/documents";
import { showNetworkImportModal } from "@/components/modals/network/Import";
import { formatDate } from "@/lib/utils";
const pageSize = 10;

const fetchPendingParseTasksStatus = async (
  taskIds: string[],
  onStatusUpdate: (id: string, data: DocumentParseTask) => void
) => {
  for (const taskId of taskIds) {
    requestGetTaskStatus(taskId).then((response) => {
      if (response.data) {
        onStatusUpdate(taskId, response.data);
      }
    });
  }
};

const fetchPendingExtendTasksStatus = async (
  taskIds: string[],
  onStatusUpdate: (id: string, data: ParseExpandTask) => void
) => {
  for (const taskId of taskIds) {
    requestGetExpandTaskStatus(taskId).then((response) => {
      if (response.data) {
        onStatusUpdate(taskId, response.data);
      }
    });
  }
};

const ParseTasks = () => {
  const [tasks, setTasks] = useState<DocumentParseTask[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [categoryType, setCategoryType] = useState("0");
  const [loading, setLoading] = useState(false);
  const [docId, setDocId] = useState<string | undefined>(
    useSearchParams().get("docId") || ""
  );

  // 获取配置存储中的分类类型
  const { categoryTypes } = useConfigStore();

  // 创建分类类型选项
  const categoryTypeOptions = useMemo(() => {
    const options = Object.entries(categoryTypes || {}).map(([key, value]) => ({
      label: value,
      value: key,
    }));

    return [{ value: "0", label: "全部类型" }, ...options];
  }, [categoryTypes]);

  // 获取解析任务列表
  const fetchTasks = async () => {
    setLoading(true);
    try {
      const response = await requestPageTask({
        docId,
        categoryType: categoryType === "0" ? undefined : categoryType,
        current,
        size: pageSize,
      });

      if (response.data) {
        setTasks(response.data.records || []);
        setTotal(response.data.total || 0);

        const pendingTasks = response.data.records.filter(
          (task) =>
            task.status !== DocumentParseStatus.COMPLETED &&
            task.status !== DocumentParseStatus.FAILED
        );

        if (pendingTasks.length > 0) {
          fetchPendingParseTasksStatus(
            pendingTasks.map((task) => task.id!),
            (id, data) => {
              setTasks((prev) =>
                prev.map((task) => (task.id === id ? data : task))
              );
            }
          );
        }
      }
    } catch (error) {
      console.error("获取解析任务列表失败", error);
    } finally {
      setLoading(false);
    }
  };

  const handleImportTask = async (task: DocumentParseTask) => {
    showNetworkImportModal({
      initialTaskType: "parse",
      initialTaskData: task,
      onClose: () => {},
      onSubmit: () => {},
    });
  };

  const handleResumeTask = async (task: DocumentParseTask) => {
    console.log("handleResumeTask", task);
    showParseTaskResumeModal(task, () => {
      fetchTasks();
    });
  };

  const handleExtendTask = async (parserId: string) => {
    try {
      // 导入并使用新的弹窗组件
      showParseTaskExpandModal(parserId);
    } catch (error) {
      toast.error("打开扩展任务弹窗失败");
      console.error("打开扩展任务弹窗失败", error);
    }
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchTasks();
  };

  useIntervalWhenVisible(fetchTasks, 10000);

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <>
      <div className="flex flex-nowrap gap-4 mb-4">
        <Input
          type="text"
          placeholder="文档ID"
          className="w-48 bg-white"
          value={docId}
          onChange={(e) => setDocId(e.target.value)}
        />

        <WrappedSelect
          value={categoryType}
          options={categoryTypeOptions}
          onChange={setCategoryType}
          className="w-36 bg-white"
        />
        <Button onClick={handleSearch}>搜索</Button>
        <div className="flex-1" />
      </div>

      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "任务ID" },
            { key: "categoryTypeDesc", label: "类型" },
            {
              key: "startPageNum",
              label: "页码范围",
              dataRender: (record) =>
                `${record.startPageNum} - ${record.endPageNum}`,
            },
            {
              key: "currentPage",
              label: "进度",
              dataRender: (record: DocumentParseTask) =>
                `${Math.round(
                  ((record.currentPage || 0) / record.totalSteps) * 100
                )}% (${record.currentPage}/${record.totalSteps})`,
            },
            // { key: "totalPages", label: "总页数" },
            {
              key: "statusDesc",
              label: "状态",
              dataRender: (record: DocumentParseTask) =>
                DocumentParseStatusLabel[record.status!] || "-",
            },
            {
              key: "taskCreatedAt",
              label: "创建时间",
              dataRender: (record: DocumentParseTask) =>
                formatDate(record.taskCreatedAt),
            },
            {
              key: "operation",
              label: "操作",
              dataRender: (record) => {
                return (
                  <div className="flex gap-2">
                    <Link href={`/parse-tasks/parse/${record.id}`}>
                      <Button size="sm" variant="outline">
                        查看
                      </Button>
                    </Link>
                    {record.status == DocumentParseStatus.COMPLETED && (
                      <Button
                        size="sm"
                        onClick={() => handleExtendTask(record.id)}
                        variant="outline"
                      >
                        扩展
                      </Button>
                    )}
                    {record.status == DocumentParseStatus.COMPLETED && (
                      <Button
                        size="sm"
                        onClick={() => handleImportTask(record)}
                        variant="outline"
                      >
                        导入
                      </Button>
                    )}
                    {record.status == DocumentParseStatus.FAILED && (
                      <Button
                        size="sm"
                        onClick={() => handleResumeTask(record)}
                        variant="outline"
                      >
                        恢复
                      </Button>
                    )}
                  </div>
                );
              },
            },
          ]}
          data={tasks}
        />
      </div>

      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={pageSize}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </>
  );
};

const ExtendTasks = () => {
  const [tasks, setTasks] = useState<ParseExpandTask[]>([]);
  const [total, setTotal] = useState(0);
  const [current, setCurrent] = useState(1);
  const [parserId, setParserId] = useState("");
  const [nodeType, setNodeType] = useState("");
  const [status, setStatus] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [nodeTypeOptions, setNodeTypeOptions] = useState<
    { label: string; value: string }[]
  >([]);

  // 获取扩展任务列表
  const fetchTasks = async (page?: number) => {
    setLoading(true);
    try {
      const response = await requestPageExpandTask({
        parserId,
        nodeType,
        status,
        current: page || current,
        size: pageSize,
      });

      if (response.data) {
        setTasks(response.data.records || []);
        setTotal(response.data.total || 0);

        const pendingTasks = response.data.records.filter(
          (task) =>
            task.status !== DocumentParseStatus.COMPLETED &&
            task.status !== DocumentParseStatus.FAILED
        );

        if (pendingTasks.length > 0) {
          fetchPendingExtendTasksStatus(
            pendingTasks.map((task) => task.id!),
            (id, data) => {
              setTasks((prev) =>
                prev.map((task) => (task.id === id ? data : task))
              );
            }
          );
        }
      }
    } catch (error) {
      console.error("获取扩展任务列表失败", error);
    } finally {
      setLoading(false);
    }
  };

  // 获取节点类型选项
  const fetchNodeTypeOptions = async () => {
    try {
      const response = await requestExpandTaskConfig();

      console.log("fetchNodeTypeOptions", response);
      if (response?.data.nodeTypes) {
        const options = Object.entries(response.data.nodeTypes).map(
          ([key, value]) => ({
            value: key,
            label: value,
          })
        );

        console.log(options);
        setNodeTypeOptions([{ value: "0", label: "全部类型" }, ...options]);
      }
    } catch (error) {
      console.error("获取节点类型选项失败", error);
    }
  };

  const handleResumeTask = async (task: ParseExpandTask) => {
    showExpandTaskResumeModal(task.id!, () => {
      fetchTasks();
    });
  };

  const handleImportTask = async (task: ParseExpandTask) => {
    showNetworkImportModal({
      initialTaskType: "extend",
      initialTaskData: task,
      onClose: () => {},
      onSubmit: () => {},
    });
  };

  // 分页变化
  const handlePageChange = (page: number) => {
    setCurrent(page);
    fetchTasks(page);
  };

  // 搜索
  const handleSearch = () => {
    setCurrent(1);
    fetchTasks();
  };

  useIntervalWhenVisible(fetchTasks, 10000);

  useEffect(() => {
    fetchNodeTypeOptions();
    fetchTasks();
  }, []);

  // 状态选项
  const statusOptions = [
    { value: "0", label: "全部状态" },
    { value: "processing", label: "处理中" },
    { value: "completed", label: "已完成" },
    { value: "failed", label: "失败" },
  ];

  return (
    <>
      <div className="flex flex-nowrap gap-4 mb-4">
        <Input
          type="text"
          placeholder="任务ID"
          className="w-48 bg-white"
          value={parserId}
          onChange={(e) => setParserId(e.target.value)}
        />
        <WrappedSelect
          value={nodeType}
          options={nodeTypeOptions}
          onChange={setNodeType}
          className="w-36 bg-white"
          // placeholder="节点类型"
        />

        {/* <WrappedSelect
          value={status}
          options={statusOptions}
          className="w-32 bg-white"
          onChange={setStatus}
          // placeholder="状态"
        /> */}

        <Button onClick={handleSearch}>搜索</Button>
        <div className="flex-1" />
      </div>

      <div className="border rounded-lg overflow-hidden">
        <WrappedTable
          loading={loading}
          columns={[
            { key: "id", label: "任务ID" },
            { key: "parserId", label: "解析任务ID" },
            // { key: "creatorName", label: "创建人" },
            { key: "nodeTypeDesc", label: "节点类型" },
            {
              key: "currentPage",
              label: "进度",
              dataRender: (record: DocumentParseTask) =>
                `${Math.round(
                  ((record.currentStep || 0) / record.totalSteps) * 100
                )}% (${record.currentStep}/${record.totalSteps})`,
            },
            {
              key: "statusDesc",
              label: "状态",
            },
            {
              key: "taskCreatedAt",
              label: "创建时间",
              dataRender: (record: ParseExpandTask) =>
                formatDate(record.taskCreatedAt),
            },
            {
              key: "operation",
              label: "操作",
              dataRender: (record) => (
                <div className="flex gap-2">
                  <Link href={`/parse-tasks/extend/${record.id}`}>
                    <Button size="sm" variant="outline">
                      查看
                    </Button>
                  </Link>
                  {record.status == "failed" && (
                    <Button
                      size="sm"
                      onClick={() => handleResumeTask(record)}
                      variant="outline"
                    >
                      恢复
                    </Button>
                  )}
                  {record.status == "completed" && (
                    <Button
                      size="sm"
                      onClick={() => handleImportTask(record)}
                      variant="outline"
                    >
                      导入
                    </Button>
                  )}
                </div>
              ),
            },
          ]}
          data={tasks}
        />
      </div>

      {total > 0 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            current={current}
            pageSize={pageSize}
            total={total}
            onChange={handlePageChange}
          />
        </div>
      )}
    </>
  );
};

const titleMap = {
  parse: "文档解析任务",
  extend: "节点扩展任务",
};

const PageTasks = () => {
  const params = useParams();
  const { type } = params;

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-4 text-lg font-medium text-gray-900">
        {titleMap[type as keyof typeof titleMap]}
      </h1>
      {type === "parse" && <ParseTasks />}
      {type === "extend" && <ExtendTasks />}
    </div>
  );
};

export default PageTasks;
