"use client";

import React from "react";
import { Form, Input, Select, Modal } from "antd";
import { useMessage } from "@/hooks/useMessage";
import { usePageData } from "@/hooks/usePageData";
import { useEntityCrud } from "@/hooks/useEntityCrud";
import { businessSystemApi } from "@/request/businessSystem";
import { RaBusinessSystemVO } from "@/types/businessSystem";
import {
  createColumn,
  createTooltipColumn,
  createSwitchColumn,
  createStatusColumn,
  createDateTimeColumn,
  createActionColumn,
} from "@/utils/tableColumns";
import {
  createAddButton,
  createRefreshButton,
} from "@/components/common/ToolbarButtons";
import PageContainer from "@/components/common/PageContainer";
import TableActions from "@/components/common/TableActions";
import BusinessSystemModal from "./components/BusinessSystemModal";
import BusinessSystemDetailDrawer from "./components/BusinessSystemDetailDrawer";

/**
 * 业务系统管理页面
 */
export default function BusinessSystemsPage() {
  const [form] = Form.useForm();
  const { showMessage, contextHolder } = useMessage();

  // 使用分页数据hook处理分页和搜索
  const {
    data,
    total,
    current,
    loading,
    handleSearch,
    handleReset,
    handlePageChange,
    refresh,
  } = usePageData<RaBusinessSystemVO, any>(form, {
    pageApi: businessSystemApi.page,
    pageSize: 10,
    showMessage,
  });

  // 使用实体CRUD hook处理添加、编辑、查看和删除
  const {
    selectedRecord,
    modalVisible,
    drawerVisible,
    deleteModalVisible,
    deleteLoading,
    recordToDelete,
    deleteConfirmTitle,
    deleteConfirmContent,
    confirmDelete,
    cancelDelete,
    handleAdd,
    handleEdit,
    handleView,
    handleDelete,
    handleStatusChange,
    handleModalSuccess,
    closeModal,
    closeDrawer,
  } = useEntityCrud<RaBusinessSystemVO>({
    deleteApi: businessSystemApi.delete,
    enableApi: businessSystemApi.enable,
    disableApi: businessSystemApi.disable,
    onSuccess: refresh,
    deleteConfirmContent: (record) => `删除此业务系统后不可恢复，是否确认?`,
    showMessage,
  });

  // 表单字段配置
  const formFields = [
    {
      name: "codeOrName",
      label: "业务系统名称/代码",
      component: <Input placeholder="请输入" allowClear />,
    },
    {
      name: "hasActive",
      label: "状态",
      component: (
        <Select placeholder="请选择" allowClear>
          <Select.Option value={true}>已生效</Select.Option>
          <Select.Option value={false}>未生效</Select.Option>
        </Select>
      ),
    },
  ];

  // 工具栏按钮配置
  const toolbarButtons = [
    createAddButton(handleAdd, "新建"),
    createRefreshButton(refresh),
  ];

  // 表格列配置
  const columns = [
    createColumn("业务系统名称", "name"),
    createColumn("业务系统ID", "id"),
    createColumn("业务系统代码", "code"),
    createColumn("联系人", "contactPerson"),
    createColumn("联系邮箱", "contactEmail"),
    createTooltipColumn("描述", "description"),
    createSwitchColumn("激活状态", "hasActive", handleStatusChange),
    createStatusColumn("状态", "hasActive"),
    createColumn("创建人", "creatorName"),
    createDateTimeColumn("创建时间", "createdAt"),
    createDateTimeColumn("更新时间", "updatedAt"),
    createActionColumn((record: RaBusinessSystemVO) => (
      <TableActions
        record={record}
        actions={[
          { key: "view", text: "查看", onClick: handleView },
          { key: "edit", text: "编辑", onClick: handleEdit },
          { key: "delete", text: "删除", onClick: handleDelete, danger: true },
        ]}
      />
    )),
  ];

  return (
    <>
      {contextHolder}
      <PageContainer
        title="业务系统管理"
        form={form}
        formFields={formFields}
        onSearch={handleSearch}
        onReset={handleReset}
        toolbarButtons={toolbarButtons}
        columns={columns}
        data={data}
        loading={loading}
        current={current}
        pageSize={10}
        total={total}
        onPageChange={handlePageChange}
      >
        {/* 编辑弹窗 */}
        <BusinessSystemModal
          visible={modalVisible}
          showMessage={showMessage}
          initialValues={selectedRecord}
          onClose={closeModal}
          onSuccess={handleModalSuccess}
        />

        {/* 详情抽屉 */}
        <BusinessSystemDetailDrawer
          open={drawerVisible}
          onClose={closeDrawer}
          data={selectedRecord}
          onStatusChange={handleStatusChange}
        />
        
        {/* 删除确认弹窗 */}
        <Modal
          title={deleteConfirmTitle}
          open={deleteModalVisible}
          onOk={confirmDelete}
          onCancel={cancelDelete}
          okText="确认"
          cancelText="取消"
          confirmLoading={deleteLoading}
          maskClosable={false}
          destroyOnHidden
        >
          {recordToDelete && deleteConfirmContent(recordToDelete)}
        </Modal>
      </PageContainer>
    </>
  );
}
