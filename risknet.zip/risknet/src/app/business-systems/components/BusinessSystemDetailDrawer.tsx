"use client";

import { Drawer, Button, Space } from "antd";
import { RaBusinessSystemVO } from "@/types/businessSystem";
import dayjs from "dayjs";
import "dayjs/locale/zh-cn";

dayjs.locale("zh-cn");

const formatDate = (date: string | Date | undefined) => {
  return date ? dayjs(date).format("YYYY-MM-DD HH:mm:ss") : "-";
};

interface BusinessSystemDetailDrawerProps {
  open: boolean;
  onClose: () => void;
  data?: RaBusinessSystemVO | null;
  onStatusChange?: (
    record: RaBusinessSystemVO,
    checked: boolean
  ) => Promise<void>;
}

const BusinessSystemDetailDrawer: React.FC<BusinessSystemDetailDrawerProps> = ({
  open,
  onClose,
  data,
  onStatusChange,
}) => {
  if (!data) return null;

  const handleStatusToggle = async () => {
    if (onStatusChange && data) {
      await onStatusChange(data, !data.hasActive);
    }
  };

  return (
    <Drawer
      title="查看业务系统详情"
      open={open}
      onClose={onClose}
      width={700}
      footer={
        <div style={{ textAlign: "right" }}>
          <Space>
            
            <Button onClick={onClose} type="primary">
              关闭
            </Button>
          </Space>
        </div>
      }
    >
      <div className="grid grid-cols-24 gap-y-4">
        <div className="col-span-4 text-gray-500">业务系统名称：</div>
        <div className="col-span-20">{data.name}</div>

        <div className="col-span-4 text-gray-500">业务系统ID：</div>
        <div className="col-span-20">{data.id}</div>

        <div className="col-span-4 text-gray-500">业务系统代码：</div>
        <div className="col-span-20">{data.code}</div>

        <div className="col-span-4 text-gray-500">联系人：</div>
        <div className="col-span-20">{data.contactPerson || "-"}</div>

        <div className="col-span-4 text-gray-500">联系邮箱：</div>
        <div className="col-span-20">{data.contactEmail || "-"}</div>

        <div className="col-span-4 text-gray-500">描述：</div>
        <div className="col-span-20">{data.description || "-"}</div>

        <div className="col-span-4 text-gray-500">状态：</div>
        <div className="col-span-20">
          <span style={{ color: "#1677ff", marginRight: 8 }}>●</span>
          {data.hasActive ? "已生效" : "未生效"}
        </div>

        <div className="col-span-4 text-gray-500">创建人：</div>
        <div className="col-span-20">{data.creatorName || "-"}</div>

        <div className="col-span-4 text-gray-500">创建时间：</div>
        <div className="col-span-20">{formatDate(data.createdAt)}</div>

        <div className="col-span-4 text-gray-500">更新人：</div>
        <div className="col-span-20">{data.updatedAt || "-"}</div>
        
        <div className="col-span-4 text-gray-500">修改时间：</div>
        <div className="col-span-20">{formatDate(data.updatedAt)}</div>
      </div>
    </Drawer>
  );
};

export default BusinessSystemDetailDrawer;
