"use client";

import { useEffect, useMemo } from "react";
import { Modal, Form, Input} from "antd";
import {
  RaBusinessSystemVO,
  RaBusinessSystemQuery,
} from "@/types/businessSystem";
import { businessSystemApi } from "@/request/businessSystem";
import { NoticeType } from "antd/es/message/interface";

const { TextArea } = Input;

interface BusinessSystemModalProps {
  visible: boolean;
  initialValues?: RaBusinessSystemVO | null;
  onClose: () => void;
  onSuccess: (msg: string) => void;
  showMessage: (type: NoticeType, messgae: string) => void;

}

const formItemStyle = { marginBottom: 20 };

const BusinessSystemModal: React.FC<BusinessSystemModalProps> = ({
  visible,
  initialValues,
  onClose,
  onSuccess,
  showMessage,
}) => {
  const [form] = Form.useForm();
  const isEdit = !!initialValues?.id;

  useEffect(() => {
    if (visible) {
      form.resetFields();
      if (initialValues) {
        form.setFieldsValue(initialValues);
      }
    }
  }, [visible, initialValues, form]);

  const title = useMemo(
    () => (isEdit ? "编辑业务系统" : "新建业务系统"),
    [isEdit]
  );

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      const data: RaBusinessSystemQuery = {
        id: initialValues?.id || "",
        ...values,
        hasActive:
          values.hasActive !== undefined
            ? values.hasActive
            : initialValues?.hasActive ?? true, // Use form value if present
      };
      await businessSystemApi[isEdit ? "update" : "create"](data);
      onSuccess(`${title}成功`);
      onClose();
    } catch (e: any) {
      showMessage("error", e.message || `${title}}失败`);
    }
  };

  return (
    <Modal
      title={title}
      open={visible}
      onCancel={onClose}
      onOk={handleOk}
      width={720}
      classNames={{
        content: "p-[20]!",
        body: "h-[450] p-[0] overflow-y-auto",
      }}
      centered
      okText={isEdit ? "保存" : "确定"}
      cancelText="取消"
      destroyOnHidden
      maskClosable={false}
    >
      <Form
        form={form}
        layout="horizontal"
        labelAlign="left"
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 20 }}
        initialValues={initialValues || undefined}
      >
        <Form.Item
          label="业务系统名称"
          name="name"
          style={formItemStyle}
          rules={[
            { required: true, message: "不能为空，名称长度为1-63个字符" },
            { max: 63, message: "名称最长为63个字符" },
          ]} // Assuming max length based on risk levels
        >
          <Input placeholder="请输入业务系统名称" maxLength={63} />
        </Form.Item>
        <Form.Item
          label="业务系统代码"
          name="code"
          style={formItemStyle}
          rules={[{ required: true, message: "请输入业务系统代码" }]}
        >
          <Input placeholder="请输入业务系统代码" />
        </Form.Item>
        <Form.Item label="联系人" name="contactPerson" style={formItemStyle}>
          <Input placeholder="请输入联系人" />
        </Form.Item>
        <Form.Item label="联系邮箱" name="contactEmail" style={formItemStyle}>
          <Input placeholder="请输入联系邮箱" />
        </Form.Item>
        <Form.Item
          label="描述"
          name="description"
          style={formItemStyle}
          rules={[{ max: 255, message: "不超过255个字符" }]}
        >
          <TextArea rows={2} placeholder="请输入描述信息" maxLength={255} />
        </Form.Item>
        
      </Form>
    </Modal>
  );
};

export default BusinessSystemModal;
