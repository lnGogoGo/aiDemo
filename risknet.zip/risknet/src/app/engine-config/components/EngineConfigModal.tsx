"use client";

import { useEffect, useMemo, useState } from "react";
import { Modal, Form, Input, Select, Button, InputNumber, Switch } from "antd";
import { RaEngineConfigVO, RaEngineConfigQuery } from "@/types/engineConfig";
import { businessSystemApi } from "@/request/businessSystem";
import { engineConfigApi } from "@/request/engineConfig";
import { RaBusinessSystemVO } from "@/types/businessSystem";
// Assuming an API to fetch available rule names or IDs
import { ruleApi } from "@/request/rule";
import { RaRuleVO } from "@/types/rule";
import { useDataFetching } from "@/hooks/useDataFetching";
import { NoticeType } from "antd/es/message/interface";
import { riskLevelApi } from "@/request/riskLevel";
import { RaRiskLevelVO } from "@/types/riskLevel";
import { metadataApi } from "@/request/metadata";
import { LlmModel } from "@/types/metadata";
// Assuming an API to fetch available model names or IDs
// import { metadataApi } from "@/request/metadata";

const { TextArea } = Input;
const { Option } = Select;

interface EngineConfigModalProps {
  visible: boolean;
  initialValues?: RaEngineConfigVO | null;
  onClose: () => void;
  onSuccess: (msg: string) => void;
  showMessage: (type: NoticeType, content: string) => void;
  // Add models prop if needed
}

const formItemStyle = { marginBottom: 20 };

const EngineConfigModal: React.FC<EngineConfigModalProps> = ({
  visible,
  initialValues,
  onClose,
  onSuccess,
  showMessage,
}) => {
  const [form] = Form.useForm();
  const isEdit = !!initialValues?.id;

  // 获取业务系统列表
  const { data: systemsList = [] } = useDataFetching<RaBusinessSystemVO>({
    fetchApi: businessSystemApi.listAllActive,
    errorMessage: "",
    showMessage
  });

  // 获取规则列表
  const { data: rulesList = [] } = useDataFetching<RaRuleVO>({
    fetchApi: ruleApi.listAllActive,
    errorMessage: "",
    showMessage
  });

  const { data: riskList = [] } = useDataFetching<RaRiskLevelVO>({
    fetchApi: riskLevelApi.listAllActive,
    errorMessage: "",
    showMessage
  });

  const {data: modelsList = []} = useDataFetching<LlmModel>({
    fetchApi: metadataApi.getLlmModels,
    errorMessage: "",
    showMessage
  });

  useEffect(() => {
    if (visible) {
      form.resetFields();
      if (initialValues) {
        form.setFieldsValue(initialValues);
      }
    }
  }, [visible, initialValues, form]);

  const title = useMemo(
    () => (isEdit ? "编辑引擎配置" : "新建引擎配置"),
    [isEdit]
  );

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      const data: RaEngineConfigQuery = {
        id: initialValues?.id || "",
        ...values,
        hasActive:
          values.hasActive !== undefined
            ? values.hasActive
            : initialValues?.hasActive ?? true, // Use form value if present
        // Map rule names/ids if necessary based on API requirements
        // Map model names/ids if necessary based on API requirements
      };
      await engineConfigApi[isEdit ? "update" : "create"](data);
      onSuccess(`${title}成功`);
      onClose();
    } catch (e) {
      // 错误处理可扩展
      console.error("Engine config save error:", e);
      showMessage('error', `${title}失败: ${(e as Error).message || `${title}失败`}`);
    }
  };

  return (
    <Modal
      title={title}
      open={visible}
      onCancel={onClose}
      onOk={handleOk}
      width={720}
      classNames={{
        content: "p-[20]!",
        body: "h-[450] p-[0] overflow-y-auto",
      }}
      centered
      okText={isEdit ? "保存" : "确定"}
      cancelText="取消"
      destroyOnHidden
      maskClosable={false}
    >
      <Form
        form={form}
        layout="horizontal"
        labelAlign="left"
        labelCol={{ span: 6 }}
        wrapperCol={{ span: 18 }}
        initialValues={initialValues || undefined}
      >
        {isEdit && (
          <Form.Item label="配置ID" name="id" style={formItemStyle}>
            <Input disabled />
          </Form.Item>
        )}
        <Form.Item
          label="配置名称"
          name="name"
          style={formItemStyle}
          rules={[
            { required: true, message: "请输入配置名称" },
            { max: 63, message: "名称最长为63个字符" },
          ]} // Assuming max length
        >
          <Input placeholder="请输入配置名称" maxLength={63} />
        </Form.Item>
        <Form.Item
          label="业务系统"
          name="businessSystemId"
          style={formItemStyle}
          rules={[{ required: true, message: "请选择业务系统" }]}
        >
          <Select placeholder="请选择业务系统">
            {systemsList.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label="规则引擎权重"
          name="ruleWeight"
          style={formItemStyle}
          rules={[{ required: true, message: "请输入规则引擎权重" }]}
        >
          <InputNumber
            min={0}
            style={{ width: "100%" }}
            placeholder="请输入规则引擎数量"
          />
        </Form.Item>
        <Form.Item
          label="关联引擎权重"
          name="modelWeight"
          style={formItemStyle}
          rules={[{ required: true, message: "请输入关联引擎权重" }]}
        >
          <InputNumber
            min={0}
            style={{ width: "100%" }}
            placeholder="请输入关联引擎权重"
          />
        </Form.Item>
        <Form.Item
          label="使用的模型名称"
          name="modelName"
          style={formItemStyle}
          rules={[{ required: true, message: "请选择使用的模型名称" }]}
        >
          <Select placeholder="请选择使用的模型名称">
            {modelsList.map(option => (
               <Option key={option.value} value={option.value}>{option.label}</Option>
             ))}
            {/* Placeholder options */}
          </Select>
        </Form.Item>
        <Form.Item
          label="规则列表"
          name="ruleIds"
          style={formItemStyle}
          rules={[{ required: true, message: "请选择" }]}
        >
          <Select mode="multiple" placeholder="请选择">
            {rulesList.map((rule) => (
              <Option key={rule.id} value={rule.id}>
                {rule.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label="riskLevelIds"
          name="风险级别ID列表"
          style={formItemStyle}
          rules={[{ required: true, message: "请选择" }]}
        >
          <Select mode="multiple" placeholder="请选择">
            {riskList.map((rule) => (
              <Option key={rule.id} value={rule.id}>
                {rule.name}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label="优先级"
          name="priority"
          style={formItemStyle}
          rules={[{ required: true, message: "请输入优先级" }]}
        >
          <InputNumber
            min={0}
            style={{ width: "100%" }}
            placeholder="请输入优先级"
          />
        </Form.Item>
        <Form.Item
          label="配置版本"
          name="version"
          style={formItemStyle}
          rules={[{ required: true, message: "请输入配置版本" }]}
        >
          <Input placeholder="请输入配置版本" />
        </Form.Item>
        <Form.Item
          label="描述"
          name="description"
          style={formItemStyle}
          rules={[{ max: 255, message: "不超过255个字符" }]}
        >
          <TextArea rows={2} placeholder="请输入描述信息" maxLength={255} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EngineConfigModal;
