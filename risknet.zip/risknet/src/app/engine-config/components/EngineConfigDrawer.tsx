"use client";

import { Drawer, Button, Space } from "antd";
import { RaEngineConfigVO } from "@/types/engineConfig";
import dayjs from "dayjs";

interface EngineConfigDrawerProps {
  visible: boolean;
  record: RaEngineConfigVO | null;
  onClose: () => void;
  onStatusChange?: (
    record: RaEngineConfigVO,
    checked: boolean
  ) => Promise<void>;
}

const formatDate = (date: string | undefined) => {
  return date ? dayjs(date).format("YYYY-MM-DD HH:mm:ss") : "-";
};

const EngineConfigDrawer: React.FC<EngineConfigDrawerProps> = ({
  visible,
  record,
  onClose,
  onStatusChange,
}) => {
  if (!record) return null;
  
  const handleStatusToggle = async () => {
    if (onStatusChange && record) {
      await onStatusChange(record, !record.hasActive);
    }
  };

  return (
    <Drawer
      title="引擎配置详情"
      placement="right"
      onClose={onClose}
      open={visible}
      width={700}
      footer={
        <div style={{ textAlign: "right" }}>
          <Space>
            <Button onClick={onClose} type="primary">
              关闭
            </Button>
          </Space>
        </div>
      }
    >
      <div className="grid grid-cols-24 gap-y-4">
        <div className="col-span-4 text-gray-500">配置ID：</div>
        <div className="col-span-20">{record.id}</div>
        
        <div className="col-span-4 text-gray-500">配置名称：</div>
        <div className="col-span-20">{record.name}</div>
        
        <div className="col-span-4 text-gray-500">业务系统：</div>
        <div className="col-span-20">{record.businessSystemName}</div>
        
        <div className="col-span-4 text-gray-500">规则权重：</div>
        <div className="col-span-20">{record.ruleWeight}</div>
        
        <div className="col-span-4 text-gray-500">模型权重：</div>
        <div className="col-span-20">{record.modelWeight}</div>
        
        <div className="col-span-4 text-gray-500">使用的模型：</div>
        <div className="col-span-20">{record.modelName || '-'}</div>
        
        <div className="col-span-4 text-gray-500">规则列表：</div>
        <div className="col-span-20">
          {record.ruleIds?.map((ruleId) => (
            <span 
              key={ruleId} 
              className="inline-block px-2 py-1 mr-2 mb-1 bg-blue-100 text-blue-800 rounded-md text-xs"
            >
              {ruleId}
            </span>
          )) || '-'}
        </div>
        
        <div className="col-span-4 text-gray-500">优先级：</div>
        <div className="col-span-20">{record.priority}</div>
        
        <div className="col-span-4 text-gray-500">配置版本：</div>
        <div className="col-span-20">{record.version}</div>
        
        <div className="col-span-4 text-gray-500">状态：</div>
        <div className="col-span-20">
          <span style={{ color: "#1677ff", marginRight: 8 }}>●</span>
          {record.hasActive ? "已生效" : "未生效"}
        </div>
        
        <div className="col-span-4 text-gray-500">描述：</div>
        <div className="col-span-20">{record.description || '-'}</div>
        
        <div className="col-span-4 text-gray-500">创建人：</div>
        <div className="col-span-20">{record.creatorName || '-'}</div>
        
        <div className="col-span-4 text-gray-500">创建时间：</div>
        <div className="col-span-20">{formatDate(record.createdAt)}</div>
      </div>
    </Drawer>
  );
};

export default EngineConfigDrawer;
