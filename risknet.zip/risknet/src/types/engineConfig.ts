export interface ApiResponse<T> { 
  code: string; 
  msg: string; 
  data: T; 
}

export interface PaginatedResponse<T> { 
  records: T[]; 
  total: number; 
  size: number; 
  current: number; 
  pages?: number; 
}

export interface RaEngineConfigQuery {
  id: string;
  businessSystemId: string;
  ruleIds: string[];
  riskLevelIds: string[];
  name: string;
  description?: string;
  ruleWeight: number;
  modelWeight: number;
  modelName?: string;
  hasActive: boolean;
  version?: string;
  priority: number;
}

export interface RaEngineConfigPageQuery {
  name?: string;
  hasActive?: boolean;
  current?: number;
  size?: number;
}

export interface RaEngineConfigVO {
  id: string;
  businessSystemId: string;
  businessSystemName?: string;
  ruleIds: string[];
  riskLevelIds: string[];
  name: string;
  description?: string;
  ruleWeight: number;
  modelWeight: number;
  modelName?: string;
  hasActive: boolean;
  version?: string;
  priority: number;
  creator?: string;
  creatorName?: string;
  createdAt?: string;
  updatedAt?: string;
} 