export interface RString {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  /**
   * 响应数据
   */
  data?: string;
}

export interface OrderItem {
  column?: string;
  asc?: boolean;
}

export const InspectionMethodLabelMap: Record<string, string> = {
  random: "随机抽检",
  exact: "精确匹配",
  fuzzy: "模糊匹配",
};

export const InspectionStatusLabelMap: Record<number, string> = {
  1: "抽检中",
  2: "审核中",
  3: "已完成",
  4: "获取任务失败",
};

/**
 * 语义网络抽检任务提交参数
 */
export interface SnInspectionTaskSubmitQuery {
  /**
   * 抽检方式，可选值：random: 随机抽检；keyword: 关键词匹配
   */
  method: string;
  /**
   * 关键词，在 method 为 keyword 时使用
   */
  keyword?: string;
  /**
   * 节点类型，可选值：industry: 行业节点；career: 职业节点
   */
  nodeType: string;
  /**
   * 数据版本号，格式为 x.y.z
   */
  version: string;
  /**
   * 抽检数量，范围 1-100
   */
  count?: number;
}

/**
 * 语义网络抽检任务分页查询参数
 */
export interface SnInspectionTaskPageQuery {
  /**
   * 当前页码
   * @default 1
   */
  current?: number;
  /**
   * 每页大小
   * @default 10
   */
  size?: number;
}

/**
 * 语义网络抽检任务VO
 */
export interface SnInspectionTaskVO {
  /**
   * id
   */
  id?: string;
  /**
   * 抽检方式，可选值：random: 随机抽检；keyword: 关键词匹配
   */
  method?: string;
  /**
   * 关键词，在 method 为 keyword 时使用
   */
  keyword?: string;
  /**
   * 节点类型，可选值：industry: 行业节点；career: 职业节点
   */
  nodeType?: string;
  /**
   * 数据版本号，格式为 x.y.z
   */
  version?: string;
  /**
   * 审核数量
   */
  auditCount?: number;
  /**
   * 抽检数量，范围 1-100
   */
  count?: number;
  /**
   * 任务状态，1 数据获取中，此时不能查看详情 需要轮询调用 getStatus，2 进行中，3 已完成，4 获取任务失败
   */
  status?: number;
  /**
   * 错误信息
   */
  errorMessage?: string;
  /**
   * 当前处理步骤
   */
  currentStep?: string;
  /**
   * 总步骤数
   */
  totalSteps?: number;
  /**
   * 已处理的步骤列表
   */
  processedSteps?: string[];
  /**
   * 已处理的节点列表
   */
  processedNodes?: string[];
  /**
   * 任务进度
   */
  progress?: number;
  /**
   * 服务返回的任务创建时间
   */
  taskCreatedAt?: string;
  /**
   * 服务返回的任务更新时间
   */
  taskUpdatedAt?: string;
}

/**
 * 响应数据
 */
export interface PageSnInspectionTaskVO {
  records?: SnInspectionTaskVO[]; // Adjusted to use SnInspectionTaskVO based on typical patterns
  total?: number;
  size?: number;
  current?: number;
  orders?: OrderItem[];
  optimizeCountSql?: PageSnInspectionTaskVO;
  searchCount?: PageSnInspectionTaskVO;
  optimizeJoinOfCountSql?: boolean;
  maxLimit?: number;
  countId?: string;
  pages?: number;
}

/**
 * 响应
 */
export interface RPageSnInspectionTaskVO {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  data?: PageSnInspectionTaskVO;
}

/**
 * 语义网络抽检节点分页查询参数
 */
export interface SnInspectionNodePageQuery {
  /**
   * 抽检任务ID
   */
  inspectionId: string;
  /**
   * 当前页码
   * @default 1
   */
  current?: number;
  /**
   * 每页大小
   * @default 10
   */
  size?: number;
}

export interface RelationshipDTO {
  relationshipId?: string;
  relationType?: string;
  sourceNodeId?: string;
  sourceNodeName?: string;
  sourceNodeType?: string;
  targetNodeId?: string;
  targetNodeName?: string;
  targetNodeType?: string;
  weight?: number;
  createdAt?: string;
  updatedAt?: string;
}

export const AuditStatusLabelMap: Record<string, string> = {
  correct: "正确",
  incorrect: "错误",
  need_adjustment: "需要调整",
};

/**
 * 语义网络抽检节点VO
 */
export interface SnInspectionNodeVO {
  /**
   * id
   */
  id?: string;
  /**
   * 抽检任务id
   */
  inspectionId?: string;
  /**
   * 审核状态：correct/incorrect/need_adjustment，如果为 null 则为待审核
   */
  auditStatus?: string;
  /**
   * 错误类型
   */
  auditErrorType?: string;
  /**
   * 调整建议
   */
  auditSuggestion?: string;
  sexpansionType?: string;
  sparentCode?: string;
  soriginCode?: string;
  sid?: string;
  ssimilarityScore?: string;
  ssourceType?: string;
  srelationships?: RelationshipDTO[];
  sversion?: string;
  sdescription?: string;
  snodeType?: string;
  sname?: string;
  scode?: string;
  ssource?: string;
  snodeId?: string;
  slevel?: number;
}

/**
 * 响应数据
 */
export interface PageSnInspectionNodeVO {
  records?: SnInspectionNodeVO[]; // Adjusted to use SnInspectionNodeVO
  total?: number;
  size?: number;
  current?: number;
  orders?: OrderItem[];
  optimizeCountSql?: PageSnInspectionNodeVO;
  searchCount?: PageSnInspectionNodeVO;
  optimizeJoinOfCountSql?: boolean;
  maxLimit?: number;
  countId?: string;
  pages?: number;
}

/**
 * 响应
 */
export interface RPageSnInspectionNodeVO {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  data?: PageSnInspectionNodeVO;
}

/**
 * 语义网络抽检节点审核参数
 */
export interface SnInspectionNodeAuditQuery {
  /**
   * 要审核的节点ID，注意这里对应 id 字段，不是 sid 也不是 snodeId
   */
  inspection_node_id: string;
  /**
   * 审核状态：correct/incorrect/need_adjustment
   */
  auditStatus: string;
  /**
   * 错误类型，当审核状态为incorrect时必填
   */
  auditErrorType?: string;
  /**
   * 调整建议，当审核状态为need_adjustment时必填
   */
  auditSuggestion?: string;
}

/**
 * 响应
 */
export interface RSnInspectionTaskVO {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  data?: SnInspectionTaskVO; // Assuming this should be SnInspectionTaskVO
}

/**
 * 语义网络抽检任务统计数据VO
 */
export interface SnInspectionTaskStatsVO {
  /**
   * id
   */
  id?: string;
  /**
   * 总抽检节点个数
   */
  count?: number;
  /**
   * 正确个数
   */
  correctCount?: number;
  /**
   * 错误个数
   */
  incorrectCount?: number;
  /**
   * 需要调整个数
   */
  needAdjustmentCount?: number;
}

/**
 * 响应
 */
export interface RSnInspectionTaskStatsVO {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  data?: SnInspectionTaskStatsVO;
}
