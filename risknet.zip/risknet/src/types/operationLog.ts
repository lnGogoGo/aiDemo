// 操作日志相关类型

/**
 * 操作日志分页查询参数
 */
export interface SnOperationLogPageQuery {
  userId?: string;
  operationType?: string;
  startTime?: string; // ISO 日期字符串
  endTime?: string;   // ISO 日期字符串
  current?: number;
  size?: number;
}

/**
 * 单条操作日志VO
 */
export interface SnOperationLogVO {
  id?: string;
  userId?: string;
  userName?: string;
  operationTime?: string;
  operationType?: string;
  moduleName?: string;
  operationName?: string;
  operationCount?: number;
  targetType?: string;
  targetId?: string;
  operationIp?: string;
  errorMessage?: string;
  createDate?: string;
}

/**
 * 分页响应数据
 */
export interface PageSnOperationLogVO {
  records: SnOperationLogVO[];
  total: number;
  size: number;
  current: number;
  orders?: OrderItem[];
  optimizeCountSql?: boolean;
  searchCount?: boolean;
  optimizeJoinOfCountSql?: boolean;
  maxLimit?: number;
  countId?: string;
  pages?: number;
}

/**
 * 排序项
 */
export interface OrderItem {
  column: string;
  asc: boolean;
}

/**
 * 分页响应封装
 */
export interface RPageSnOperationLogVO {
  code: string;
  msg: string;
  data: PageSnOperationLogVO;
}

/**
 * 操作类型列表响应
 */
export interface RMapStringString {
  code: string;
  msg: string;
  data: Record<string, string>;
} 