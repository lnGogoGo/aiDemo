/**
 * 响应
 */
export interface RString {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  /**
   * 响应数据
   */
  data?: string;
}

/**
 * 版本号展示 VO
 */
export interface SnVersionVO {
  /**
   * id
   */
  id?: string;
  /**
   * 版本号
   */
  version?: string;
  /**
   * 主版本号
   */
  major?: number;
  /**
   * 次版本号
   */
  minor?: number;
  /**
   * 修订号
   */
  patch?: number;
  /**
   * 描述
   */
  description?: string;
}

/**
 * 响应
 */
export interface RListSnVersionVO {
  /**
   * 编码：一般 00000 表示成功、其他表示失败
   */
  code?: string;
  /**
   * 消息内容
   */
  msg?: string;
  /**
   * 响应数据
   */
  data?: SnVersionVO[];
} 