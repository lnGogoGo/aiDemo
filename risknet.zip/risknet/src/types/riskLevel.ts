export interface ApiResponse<T> { 
  code: string; 
  msg: string; 
  data: T; 
}

export interface PaginatedResponse<T> { 
  records: T[]; 
  total: number; 
  size: number; 
  current: number; 
  pages?: number; 
}

export interface RaRiskLevelQuery {
  id: string;
  businessSystemId: string;
  name: string;
  description?: string;
  minScore: number;
  maxScore: number;
  colorCode?: string;
  treatmentAdvice?: string;
  priority: number;
  hasActive: boolean;
}

export interface RaRiskLevelPageQuery {
  name?: string;
  businessSystemId?: string;
  hasActive?: boolean;
  current?: number;
  size?: number;
}

export interface RaRiskLevelVO {
  id: string;
  businessSystemId: string;
  businessSystemName: string;
  name: string;
  description?: string;
  minScore: number;
  maxScore: number;
  colorCode?: string;
  treatmentAdvice?: string;
  priority: number;
  hasActive: boolean;
  creator?: string;
  creatorName?: string;
  createdAt?: string;
  updatedAt?: string;
} 