export interface DocumentParseTask {
  /**
   * 分类类型
   */
  categoryType?: string;
  /**
   * 创建时间
   */
  taskCreatedAt?: string;
  /**
   * 更新时间
   */
  taskUpdatedAt?: string;
  /**
   * 当前处理页数
   */
  currentPage?: number;
  /**
   * 结束页码
   */
  endPageNum?: number;
  /**
   * id
   */
  id?: string;
  /**
   * 已处理页码列表
   */
  processedPages?: number[];
  /**
   * 起始页码
   */
  startPageNum?: number;
  /**
   * 任务状态，1 processing, 2 completed,  3 failed
   */
  status?: DocumentParseStatus;
  /**
   * 解析服务返回的任务id
   */
  taskId?: string;
  /**
   * 总页数
   */
  totalPages?: number;
  /**
   * 更新时间
   */
  updateDate?: string;
  /**
   * 文档名称
   */
  docFileName?: string;
  [property: string]: any;
}

export interface DocumentParseConfig {
  /**
   * 可选解析类型，key 为参数，value 为展示值
   */
  categoryTypes?: { [key: string]: string };
  /**
   * 可选多模态大模型，key 为参数，value 为展示值
   */
  multimodalModels?: { [key: string]: string };
  /**
   * 可选来源类型，key 为参数，value 为展示值
   */
  sourceTypes?: { [key: string]: string };
  /**
   * 可用的任务状态，key 为参数，value 为展示值
   */
  taskStatus?: { [key: string]: string };
}

export interface DocumentParsePageResult {
  /**
   * 创建时间 yyyy-MM-dd HH:mm:ss
   */
  taskCreatedAt?: Date;
  /**
   * 更新时间 yyyy-MM-dd HH:mm:ss
   */
  taskUpdatedAt?: Date;
  /**
   * 当前页的错误信息
   */
  errors?: string[];
  /**
   * id
   */
  id?: string;
  /**
   * 当前页码
   */
  pageNum: number;
  /**
   * 解析结果
   */
  results?: { [key: string]: string }[];
  /**
   * 原始结果
   */
  originalResponse?: { [key: string]: string };
  /**
   * 该页的处理状态
   */
  status?: string;
  /**
   * 解析服务返回的任务id
   */
  taskId: string;
  /**
   * 更新时间 yyyy-MM-dd HH:mm:ss
   */
  updateDate?: Date;
}

export interface Document {
  /**
   * 创建时间
   */
  createDate?: string;
  /**
   * 创建者
   */
  creator?: string;
  /**
   * 创建者名称
   */
  creatorName?: string;
  /**
   * 文件名
   */
  filename?: string;
  /**
   * 文件路径
   */
  filepath?: string;
  /**
   * ID
   */
  id?: string;
  /**
   * 解析任务ID
   */
  parserTaskId?: string;
  /**
   * 排序
   */
  sortId?: number;
  /**
   * 更新时间
   */
  updateDate?: string;
  /**
   * 更新者
   */
  updater?: string;
  [property: string]: any;
}

// 任务状态，1 processing, 2 completed, 3 failed
export enum DocumentParseStatus {
  COMPLETED = "completed",
  FAILED = "failed",
  NOT_STARTED = "not_started",
  PROCESSING = "processing",
  UPDATED = "updated",
}

export const DocumentParseStatusLabel = {
  [DocumentParseStatus.NOT_STARTED]: "未开始",
  [DocumentParseStatus.PROCESSING]: "处理中",
  [DocumentParseStatus.COMPLETED]: "已完成",
  [DocumentParseStatus.FAILED]: "失败",
  [DocumentParseStatus.UPDATED]: "已更新",
};

export interface ExpandTaskConfigVO {
  nodeTypes: Record<string, string>;
  taskStatus: Record<string, string>;
  languageModels: Record<string, string>;
}

export interface ParseExpandTask {
  id?: string;
  parserId?: string;
  nodeType?: string;
  nodeTypeDesc?: string;
  status?: string;
  statusDesc?: string;
  batchSize?: number;
  currentStep?: number;
  processedSteps?: number[];
  processedTerms?: string[];
  taskCreatedAt?: string;
  taskUpdatedAt?: string;
  modelName?: string;
  progress?: number;
  totalSteps?: number;
}

export interface SnExpandTaskBatchVO {
  id?: string;
  expandId?: string;
  batchNum?: number;
  status?: string;
  results?: Array<{
    code: string;
    name: string;
    aliases?: Array<{ name: string; reason: string }>;
    metaphors?: Array<{ name: string; reason: string }>;
    slang?: Array<{ name: string; reason: string }>;
    locations?: Array<{ name: string; reason: string }>;
    description?: string;
  }>;
  processedTerms?: string[];
  errors?: string[];
  taskCreatedAt?: string;
  taskUpdatedAt?: string;
}

// 导入任务相关类型
export interface ImportTaskConfigVO {
  nodeTypes: Record<string, string>;
  sourceTypes: Record<string, string>;
  taskStatus: Record<string, string>;
}
export interface SnImportTaskVO {
  /**
   * 当前处理步骤
   */
  currentStep?: string;
  /**
   * 错误信息
   */
  errorMessage?: string;
  /**
   * id
   */
  id?: string;
  /**
   * 节点类型
   */
  nodeType?: string;
  /**
   * 已处理的节点列表
   */
  processedNodes?: string[];
  /**
   * 已处理的步骤列表
   */
  processedSteps?: string[];
  /**
   * 任务进度
   */
  progress?: number;
  /**
   * 任务ID
   */
  sourceId?: string;
  /**
   * 任务状态
   */
  status?: string;
  /**
   * 服务返回的任务创建时间
   */
  taskCreatedAt?: string;
  /**
   * 远程任务id
   */
  taskId?: string;
  /**
   * 服务返回的任务更新时间
   */
  taskUpdatedAt?: string;
  /**
   * 总步骤数
   */
  totalSteps?: number;
  /**
   * 导入任务类型，1: 解析任务；2: 扩展任务
   */
  type?: number;
  /**
   * 版本号
   */
  version?: string;
  [property: string]: any;
}
