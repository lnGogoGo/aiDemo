export interface ApiResponse<T> { 
  code: string; 
  msg: string; 
  data: T; 
}

export interface RuleType { 
  value: string; 
  label: string; 
}

export interface Operator { 
  value: string; 
  label: string; 
}

export interface LlmModel { 
  value: string; 
  label: string; 
  provider?: string; 
}

export interface ConditionLogic { 
  value: string; 
  label: string; 
}

export interface ConditionField { 
  value: string; 
  label: string; 
  fieldType?: string; 
  fieldTypeLabel?: string; 
} 