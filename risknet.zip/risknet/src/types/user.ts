
// 登录请求参数
export interface LoginParams {
  uuid: string;
  username: string;
  password: string;
  captcha: string
}

// 用户信息类型
export interface UserInfo {
  id: number;
  username: string;
  realName: string;
  roleId: number;
  permissions: string[];
  superAdmin: boolean;
  avatar?: string;
  email?: string;
  lastLoginTime?: string;
}

// 创建/更新用户参数
export interface UserParams {
  id?: number;
  username: string;
  password?: string;
  realName: string;
  roleId: number;
  superAdmin: boolean;
  email?: string;
}

// 修改密码参数
export interface ChangePasswordParams {
  password: string;
  newPassword: string;
}
