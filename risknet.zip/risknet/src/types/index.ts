// 基本类型定义

export * from "./document";
export * from "./operationLog";

// 实体类型枚举
export enum EntityType {
  INDUSTRY = "行业",
  POPULATION = "人群",
  RISK_TYPE = "风险类型",
  LOCATION = "位置",
}

export const EntityTypeKey = {
  [EntityType.INDUSTRY]: "industry",
  [EntityType.POPULATION]: "population",
  [EntityType.RISK_TYPE]: "riskType",
  [EntityType.LOCATION]: "location",
} as const;

export const EntityTypeOptions = [
  {
    value: "0",
    label: "全部实体类型",
  },
].concat(
  Object.values(EntityType).map((type) => ({
    value: EntityTypeKey[type],
    label: type,
  }))
);

// 节点状态枚举
export enum NodeStatus {
  CORRECT = "正确",
  INCORRECT = "错误",
  NEEDS_ADJUSTMENT = "需调整",
  ADJUSTED = "已调整",
}

// 节点标记枚举
export enum NodeMark {
  IMPORTANT = "重要",
  NORMAL = "普通",
}

// 抽检方式枚举
export enum InspectionMethod {
  RANDOM = "随机抽检",
  EXACT_MATCH = "精准匹配抽检",
  FUZZY_MATCH = "模糊匹配抽检",
}

// 初始化任务状态枚举
export enum InitTaskStatus {
  NOT_STARTED = "未开始",
  IN_PROGRESS = "进行中",
  COMPLETED = "已完成",
}

// 节点接口
export interface Node {
  id: string;
  name: string;
  description: string;
  entityType: EntityType;
  createdAt: string;
  updatedAt: string;
  status?: NodeStatus;
  mark?: NodeMark;
  feedback?: string;
}

// 版本接口
export interface Version {
  id: string;
  number: string;
  createdAt: string;
  description: string;
}

// 抽检记录接口
export interface InspectionRecord {
  id: string;
  nodeId: string;
  operator: string;
  time: string;
  status: NodeStatus;
  mark: NodeMark;
  feedback?: string;
}

// 更新记录接口
export interface UpdateRecord {
  id: string;
  nodeId: string;
  operator: string;
  updatedAt: string;
  beforeContent: string;
  afterContent: string;
}

export interface StatisticData {
  statusCounts: { [key in NodeStatus]?: number };
  markCounts: { [key in NodeMark]?: number };
  entityTypeCounts: { [key: string]: number };
  timeDistribution: { date: string; count: number }[];
  topErrorNodes: { id: string; name: string; count: number }[];
}
