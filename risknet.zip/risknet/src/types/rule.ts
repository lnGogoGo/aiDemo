export interface ApiResponse<T> { 
  code: string; 
  msg: string; 
  data: T; 
}

export interface PaginatedResponse<T> { 
  records: T[]; 
  total: number; 
  size: number; 
  current: number; 
  pages?: number; 
}

export interface RuleCondition {
  id: string;
  type: string;
  field?: string;
  fieldDesc?: string;
  fieldType?: string;
  operator?: string;
  operatorDesc?: string;
  value?: string;
  weight?: number;
  content?: string;
}

export interface RaRuleQuery {
  id: string;
  businessSystemId: string;
  type: string;
  name: string;
  description?: string;
  conditionLogic?: string;
  conditions?: RuleCondition[];
  modelName?: string;
  weight?: number;
  version?: string;
  hasActive: boolean;
}

export interface RaRulePageQuery {
  name?: string;
  type?: string;
  businessSystemId?: string;
  hasActive?: boolean;
  current?: number;
  size?: number;
}

export interface RaRuleVO {
  id: string;
  businessSystemId: string;
  businessSystemName: string;
  type: string;
  typeDesc?: string;
  name: string;
  description?: string;
  conditionLogic?: string;
  conditionLogicDesc?: string;
  conditions?: RuleCondition[];
  modelName?: string;
  modelNameDesc?: string;
  weight?: number;
  version?: string;
  hasActive: boolean;
  creator?: string;
  creatorName?: string;
  createdAt?: string;
  updatedAt?: string;
} 