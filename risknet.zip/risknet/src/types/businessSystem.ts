export interface ApiResponse<T> {
  code: string;
  msg: string;
  data: T;
}

export interface PaginatedResponse<T> {
  records: T[];
  total: number;
  size: number;
  current: number;
  pages?: number;
}

export interface RaBusinessSystemQuery {
  id: string;
  code: string;
  name: string;
  description?: string;
  contactPerson?: string;
  contactEmail?: string;
  hasActive: boolean;
}

export interface RaBusinessSystemPageQuery {
  current?: number;
  size?: number;
  codeOrName?: string;
  hasActive?: boolean;
}

export interface RaBusinessSystemVO {
  id: string;
  code: string;
  name: string;
  description?: string;
  contactPerson?: string;
  contactEmail?: string;
  hasActive: boolean;
  creator?: string;
  creatorName?: string;
  createdAt?: string;
  updatedAt?: string;
} 