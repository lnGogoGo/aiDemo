import React, { useState, useEffect, useCallback } from "react";
import { createRoot } from "react-dom/client";
import Modal, { ModalProps } from "@/components/ui/modal";

interface ModalOptions
  extends Omit<ModalProps, "isOpen" | "onClose" | "children"> {
  content: React.ReactNode | ((closeModal: () => void) => React.ReactNode);
}

const ModalService = {
  showModal: (options: ModalOptions): Promise<void> => {
    return new Promise((resolve) => {
      const modalRoot = document.createElement("div");
      document.body.appendChild(modalRoot);

      const root = createRoot(modalRoot);

      const ModalContainer = () => {
        const [isOpen, setIsOpen] = useState(true);

        const closeModal = useCallback(() => {
          setIsOpen(false);
        }, []);

        useEffect(() => {
          return () => {
            document.body.removeChild(modalRoot);
          };
        }, []);

        useEffect(() => {
          if (!isOpen) {
            // Wait for animation to complete
            const timer = setTimeout(() => {
              root.unmount();
              resolve();
            }, 300);

            return () => clearTimeout(timer);
          }
        }, [isOpen]);

        const content =
          typeof options.content === "function"
            ? options.content(closeModal)
            : options.content;

        return (
          <Modal
            isOpen={isOpen}
            onClose={closeModal}
            title={options.title}
            isFullScreen={options.isFullScreen}
            maxWidth={options.maxWidth}
          >
            {content}
          </Modal>
        );
      };

      root.render(<ModalContainer />);
    });
  },
};

export default ModalService;

// Helper hook for component-based usage
export const useModal = () => {
  const [isOpen, setIsOpen] = useState(false);

  const openModal = useCallback(() => {
    setIsOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsOpen(false);
  }, []);

  return {
    isOpen,
    openModal,
    closeModal,
  };
};
