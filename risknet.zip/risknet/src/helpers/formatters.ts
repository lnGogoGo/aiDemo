import { Node, NodeStatus, NodeMark } from "@/types";

// 格式化日期时间
export const formatDateTime = (dateTimeString: string): string => {
  const date = new Date(dateTimeString);
  return date.toLocaleString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

// 格式化节点状态样式
export const getStatusStyle = (
  status: NodeStatus
): { color: string; bgColor: string } => {
  switch (status) {
    case NodeStatus.CORRECT:
      return { color: "text-green-700", bgColor: "bg-green-100" };
    case NodeStatus.INCORRECT:
      return { color: "text-red-700", bgColor: "bg-red-100" };
    case NodeStatus.NEEDS_ADJUSTMENT:
      return { color: "text-yellow-700", bgColor: "bg-yellow-100" };
    case NodeStatus.ADJUSTED:
      return { color: "text-blue-700", bgColor: "bg-blue-100" };
    default:
      return { color: "text-gray-700", bgColor: "bg-gray-100" };
  }
};

// 格式化标记样式
export const getMarkStyle = (
  mark: NodeMark
): { color: string; bgColor: string } => {
  switch (mark) {
    case NodeMark.IMPORTANT:
      return { color: "text-purple-700", bgColor: "bg-purple-100" };
    case NodeMark.NORMAL:
      return { color: "text-gray-700", bgColor: "bg-gray-100" };
    default:
      return { color: "text-gray-700", bgColor: "bg-gray-100" };
  }
};

// 将节点格式化为 JSON 字符串
export const formatNodeToJson = (node: Node): string => {
  return JSON.stringify(node, null, 2);
};

// 将节点列表格式化为 JSON 字符串
export const formatNodesToJson = (nodes: Node[]): string => {
  return JSON.stringify(nodes, null, 2);
};

// 从 JSON 解析节点数据
export const parseNodesFromJson = (json: string): Node[] => {
  try {
    return JSON.parse(json);
  } catch (error) {
    console.error("解析 JSON 出错:", error);
    return [];
  }
};
