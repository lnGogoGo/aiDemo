import { Node, EntityType } from "@/types";

// 验证文件类型
export const validateFileType = (
  file: File,
  acceptedTypes: string[]
): boolean => {
  const fileType = file.type;
  return acceptedTypes.includes(fileType);
};

// 验证页码范围
export const validatePageRange = (
  startPage: number,
  endPage: number
): boolean => {
  if (startPage <= 0 || endPage <= 0) {
    return false;
  }

  if (startPage > endPage) {
    return false;
  }

  return true;
};

// 验证抽检比例
export const validateSampleRatio = (ratio: number): boolean => {
  return ratio > 0 && ratio <= 1;
};

// 验证节点数据格式
export const validateNodeData = (node: any): boolean => {
  // 检查必要的字段是否存在
  if (!node.id || !node.name || !node.entityType) {
    return false;
  }

  // 验证 entityType 是否为有效值
  if (!Object.values(EntityType).includes(node.entityType)) {
    return false;
  }

  return true;
};

// 验证导入的 JSON 格式
export const validateImportJson = (json: string): boolean => {
  try {
    const data = JSON.parse(json);

    // 检查是否为数组
    if (!Array.isArray(data)) {
      return false;
    }

    // 验证每个节点
    for (const node of data) {
      if (!validateNodeData(node)) {
        return false;
      }
    }

    return true;
  } catch (error) {
    return false;
  }
};
