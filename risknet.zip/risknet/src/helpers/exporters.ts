import { Node, InspectionRecord } from "@/types";

// 导出为 JSON 文件
export const exportToJson = (
  data: any,
  fileName: string = "export.json"
): void => {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  downloadBlob(blob, fileName);
};

// 导出为 CSV 文件
export const exportToCsv = (
  data: Node[] | InspectionRecord[],
  fileName: string = "export.csv"
): void => {
  // 获取表头（使用第一个对象的所有属性）
  if (data.length === 0) {
    return;
  }

  const headers = Object.keys(data[0]);
  const csvRows = [
    // 表头行
    headers.join(","),
    // 数据行
    ...data.map((item) =>
      headers
        .map((header) => {
          const value = (item as any)[header];
          // 处理包含逗号、双引号或换行符的字段
          const formatted =
            typeof value === "string"
              ? `"${value.replace(/"/g, '""')}"`
              : String(value);
          return formatted;
        })
        .join(",")
    ),
  ];

  const csvContent = csvRows.join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  downloadBlob(blob, fileName);
};

// 导出为 Excel 文件（实际上是 CSV，但作为 Excel 打开）
export const exportToExcel = (
  data: Node[] | InspectionRecord[],
  fileName: string = "export.xlsx"
): void => {
  exportToCsv(data, fileName);
};

// 下载 Blob
const downloadBlob = (blob: Blob, fileName: string): void => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
