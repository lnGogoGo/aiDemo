interface CookieOptions {
  path?: string;
  expires?: Date;
  secure?: boolean;
  sameSite?: "strict" | "lax" | "none";
}

export const getCookie = (name: string) => {
  if (typeof window === "undefined") {
    return null;
  }

  return window.document.cookie
    .split("; ")
    .find((row) => row.startsWith(`${name}=`))
    ?.split("=")[1];
};

export const setCookie = (
  name: string,
  value: string,
  options: CookieOptions
) => {
  if (typeof window === "undefined") {
    return;
  }

  window.document.cookie = `${name}=${value}; ${options.toString()}`;
};

export const removeCookie = (name: string) => {
  if (typeof window === "undefined") {
    return;
  }

  window.document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
};
