// 模拟 API 请求，实际项目中应该替换为真实的 API 调用

import {
  EntityType,
  Node,
  Version,
  InspectionRecord,
  UpdateRecord,
  NodeStatus,
  NodeMark,
  StatisticData,
} from "@/types";

// 获取版本列表
export const fetchVersions = async (): Promise<Version[]> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 500));

  return [
    {
      id: "1",
      number: "v1.0.0",
      createdAt: "2023-01-01T00:00:00Z",
      description: "初始版本",
    },
    {
      id: "2",
      number: "v1.1.0",
      createdAt: "2023-02-01T00:00:00Z",
      description: "第二版本",
    },
    {
      id: "3",
      number: "v1.2.0",
      createdAt: "2023-03-01T00:00:00Z",
      description: "最新版本",
    },
  ];
};

// 获取节点数据
export const fetchNodes = async (entityType?: EntityType): Promise<Node[]> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 700));

  const allNodes: Node[] = [
    {
      id: "1",
      name: "制造业",
      description: "包括各种产品的生产和加工",
      entityType: EntityType.INDUSTRY,
      createdAt: "2023-01-01T00:00:00Z",
      updatedAt: "2023-01-01T00:00:00Z",
    },
    {
      id: "2",
      name: "建筑业",
      description: "负责各类建筑物的建造和维护",
      entityType: EntityType.INDUSTRY,
      createdAt: "2023-01-01T00:00:00Z",
      updatedAt: "2023-01-01T00:00:00Z",
    },
    {
      id: "3",
      name: "农民工",
      description: "从农村进入城市务工的劳动者",
      entityType: EntityType.POPULATION,
      createdAt: "2023-01-02T00:00:00Z",
      updatedAt: "2023-01-02T00:00:00Z",
    },
    {
      id: "4",
      name: "高空坠落",
      description: "从高处跌落导致的伤害",
      entityType: EntityType.RISK_TYPE,
      createdAt: "2023-01-03T00:00:00Z",
      updatedAt: "2023-01-03T00:00:00Z",
    },
    {
      id: "5",
      name: "北京市",
      description: "中国首都",
      entityType: EntityType.LOCATION,
      createdAt: "2023-01-04T00:00:00Z",
      updatedAt: "2023-01-04T00:00:00Z",
    },
  ];

  if (entityType) {
    return allNodes.filter((node) => node.entityType === entityType);
  }

  return allNodes;
};

// 随机抽检节点
export const randomSampleNodes = async (
  entityType: EntityType | null,
  ratio: number
): Promise<Node[]> => {
  const nodes = await fetchNodes(entityType || undefined);
  const sampleSize = Math.max(1, Math.floor(nodes.length * ratio));
  const shuffled = [...nodes].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, sampleSize);
};

// 精准匹配抽检
export const exactMatchNodes = async (
  entityType: EntityType | null,
  name: string
): Promise<Node[]> => {
  const nodes = await fetchNodes(entityType || undefined);
  return nodes.filter((node) => node.name === name);
};

// 模糊匹配抽检
export const fuzzyMatchNodes = async (
  entityType: EntityType | null,
  name: string
): Promise<Node[]> => {
  const nodes = await fetchNodes(entityType || undefined);
  return nodes.filter((node) => node.name.includes(name));
};

// 提交节点反馈
export const submitNodeFeedback = async (
  nodeId: string,
  status: NodeStatus,
  mark: NodeMark,
  feedback?: string
): Promise<boolean> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 600));

  console.log("提交节点反馈", { nodeId, status, mark, feedback });
  return true;
};

// 获取抽检记录
export const fetchInspectionRecords = async (): Promise<InspectionRecord[]> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 500));

  return [
    {
      id: "1",
      nodeId: "1",
      operator: "张三",
      time: "2023-03-10T10:30:00Z",
      status: NodeStatus.CORRECT,
      mark: NodeMark.NORMAL,
    },
    {
      id: "2",
      nodeId: "2",
      operator: "李四",
      time: "2023-03-11T11:20:00Z",
      status: NodeStatus.INCORRECT,
      mark: NodeMark.IMPORTANT,
      feedback: "分类错误，应归为服务业",
    },
    {
      id: "3",
      nodeId: "3",
      operator: "王五",
      time: "2023-03-12T09:15:00Z",
      status: NodeStatus.NEEDS_ADJUSTMENT,
      mark: NodeMark.IMPORTANT,
      feedback: "描述不够准确，需补充详细信息",
    },
  ];
};

export const fetchStatistics = async (): Promise<StatisticData> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 500));

  return {
    statusCounts: {
      [NodeStatus.CORRECT]: 800,
      [NodeStatus.INCORRECT]: 200,
      [NodeStatus.NEEDS_ADJUSTMENT]: 100,
    },
    markCounts: {
      [NodeMark.NORMAL]: 800,
      [NodeMark.IMPORTANT]: 200,
    },
    entityTypeCounts: {
      [EntityType.INDUSTRY]: 500,
      [EntityType.POPULATION]: 300,
      [EntityType.RISK_TYPE]: 200,
    },
    timeDistribution: [
      { date: "2023-01-01", count: 100 },
      { date: "2023-01-02", count: 200 },
      { date: "2023-01-03", count: 300 },
    ],
    topErrorNodes: [
      { id: "2", name: "建筑业", count: 100 },
      { id: "3", name: "农民工", count: 80 },
      { id: "4", name: "高空坠落", count: 70 },
    ],
  };
};

// 获取更新记录
export const fetchUpdateRecords = async (): Promise<UpdateRecord[]> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 500));

  return [
    {
      id: "1",
      nodeId: "2",
      operator: "李四",
      updatedAt: "2023-03-15T14:30:00Z",
      beforeContent: JSON.stringify({
        name: "建筑业",
        description: "负责各类建筑物的建造和维护",
      }),
      afterContent: JSON.stringify({
        name: "服务业",
        description: "提供各类服务的行业",
      }),
    },
    {
      id: "2",
      nodeId: "3",
      operator: "王五",
      updatedAt: "2023-03-16T10:45:00Z",
      beforeContent: JSON.stringify({
        description: "从农村进入城市务工的劳动者",
      }),
      afterContent: JSON.stringify({
        description:
          "从农村地区进入城市地区工作的劳动者群体，通常从事建筑、制造等行业",
      }),
    },
  ];
};

// 上传文档
export const uploadDocument = async (file: File): Promise<boolean> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 1000));

  console.log("上传文档", file.name);
  return true;
};

// 初始化语义网络
export const initializeNetwork = async (
  entityTypes: EntityType[],
  pageRange: { start: number; end: number }
): Promise<boolean> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 2000));

  console.log("初始化语义网络", { entityTypes, pageRange });
  return true;
};

// 导入节点数据
export const importNodeData = async (file: File): Promise<boolean> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 1000));

  console.log("导入节点数据", file.name);
  return true;
};

// 更新语义网络
export const updateNetwork = async (): Promise<boolean> => {
  // 模拟 API 请求延迟
  await new Promise((resolve) => setTimeout(resolve, 1500));

  console.log("更新语义网络");
  return true;
};
