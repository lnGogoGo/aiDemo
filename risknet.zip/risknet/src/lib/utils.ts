import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format } from "date-fns";
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date?: string, formatStr = "yyyy-MM-dd HH:mm:ss") {
  if (!date) return "-";
  return format(new Date(date), formatStr);
}

export function pickLocalFile(
  accept: string = "application/json, text/csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
) {
  return new Promise<File>((resolve, reject) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = accept;
    input.click();

    input.onchange = () => {
      const file = input.files?.[0];
      if (file) {
        resolve(file);
      }
    };
  });
}
