# 劳动风险语义网络人工抽检和反馈优化模块 - 项目结构说明

## 项目概述
本项目是劳动风险语义网络的人工抽检和反馈优化系统，基于Next.js 15和Tailwind CSS构建。
系统支持语义网络的初始化、节点抽检、审核反馈、数据导出导入和统计分析等功能。

## 目录结构

src/
├── app/
│ ├── page.tsx (首页)
│ ├── layout.tsx (全局布局)
│ ├── initialize/ (初始化功能区)
│ │ ├── page.tsx
│ │ └── layout.tsx
│ ├── inspect/ (抽检区)
│ │ ├── page.tsx
│ │ └── layout.tsx
│ ├── nodes/ (节点展示区)
│ │ ├── page.tsx
│ │ └── layout.tsx
│ ├── data/ (数据导出/导入)
│ │ ├── page.tsx
│ │ └── layout.tsx
│ ├── inspects/ (抽检任务区)
│ │ ├── page.tsx
│ │ └── layout.tsx
│ └── statistics/ (数据统计区)
│ ├── page.tsx
│ └── layout.tsx
├── components/
│ ├── ui/ (基础 UI 组件)
│ ├── layout/ (布局组件)
│ ├── initialize/ (初始化相关组件)
│ ├── inspect/ (抽检相关组件)
│ ├── nodes/ (节点展示相关组件)
│ ├── data/ (数据导出/导入相关组件)
│ └── statistics/ (统计相关组件)
├── store/
│ ├── network.ts (语义网络状态管理)
│ ├── inspect.ts (抽检状态管理)
│ ├── node.ts (节点状态管理)
│ └── data.ts (数据导出/导入状态管理)
├── helpers/
│ ├── api.ts (API 请求相关)
│ ├── formatters.ts (数据格式化相关)
│ ├── validators.ts (数据验证相关)
│ └── exporters.ts (数据导出相关)
└── types/
└── index.ts (类型定义)

## 模块说明

### 页面模块 (src/app)
- **首页 (page.tsx)**: 系统概览和仪表盘
- **初始化功能区 (initialize/)**: 语义网络初始化功能
- **抽检区 (inspect/)**: 节点抽检功能
- **节点展示区 (nodes/)**: 节点信息展示和审核
- **抽检任务区 (inspects/)**: 抽检记录和状态管理
- **数据统计区 (statistics/)**: 审核统计和进度分析

### 组件模块 (src/components)
- **UI组件**: 基础界面元素
- **布局组件**: 页面布局结构
- **功能组件**: 按照不同功能区域划分的专用组件

### 状态管理 (src/store)
使用zustand实现状态管理，按功能模块划分:
- **网络状态**: 管理语义网络的整体状态
- **抽检状态**: 管理抽检过程和结果
- **节点状态**: 管理节点数据和审核状态
- **版本状态**: 管理版本历史和切换
- **统计状态**: 管理统计数据

### 辅助工具 (src/helpers)
- **API工具**: 封装后端接口调用
- **格式化工具**: 处理数据展示格式
- **验证工具**: 表单和数据验证
- **导入导出工具**: 处理文件的导入导出
