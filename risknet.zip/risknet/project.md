这是一个基于nextjs的web项目，下面是主要目录：
src
- app
- components
  - ui  shadcn ui组件
- lib
- request
  - 一些请求函数
- store
  - 一些全局状态
- types
  - 一些类型定义文件